# Handoff template: the builder's section

Append the section below the line to `docs/work/<slug>/handoff-Mx.md`, after the test author's section if there is one. On a `Tests: builder` milestone, start the file with `# Handoff Mx: <slug>`. Delete the guidance in *italics*, but keep every heading and field, writing "none" where one is empty. The reviewer reads this only after its own pass over the plan and the diff, so state facts, not a sales pitch.

---

## Build (builder) · <YYYY-MM-DD> · "<session name>" (<vendor> <model>)

Plan: v<N>, covers AC-…
Commits:
- Acceptance tests: `<base>..<hash>` *(test author's, or yours on a `builder` milestone)*
- Build: `<start>..<build head>` *(start = `HEAD` when you began building)*

Checks: the full run at the build head, saved as `runs/<file>` *(report exactly what it shows: the reviewer checks it)*
- `<test command>` → *<N passed, M failed (TD-1)>*
- `<lint command>` → *<result>*
- `<type-check command>` → *<result>*

### Acceptance criteria

| AC | Acceptance tests | Result |
|---|---|---|
| AC-4 | test_ac4_reimport_adds_nothing | pass |
| AC-5 | test_ac5_same_id_two_accounts | fail: TD-1 |

### Implementation tests added

- *`tests/unit/test_x.py`: what they cover*

### Changes to acceptance tests

*`builder` milestones: every change to an acceptance test you wrote after its commit, with the reason. `independent` milestones: only changes made under an ESC decision, a TD ruling or a reopen, with that reference.*

- none

### Weakened tests

*Loosened assertions, wider tolerances, skips, xfails, or mocks of the code under test, each with its reason.*

- none

### TEST DISPUTES

*`independent` milestones only. One block per disputed test. The test stays failing and untouched.*

**TD-1:** `test_ac5_same_id_two_accounts`, AC-5
- Why I think it's wrong: *…*
- Evidence: *plan line, requirement quote, or hand calculation*

### Deviations from the plan

*Each one is also in plan.md under Surprises and deviations.*

- none

### Calls I made

- *Choices you made that the user didn't.*

### Not done or not verified

- *What you didn't check, couldn't run, or left for later, and why.*

Open: *TD-1, ESC-n, … or "none"*
Next: `dev-review <slug> Mx`
