---
name: dev-test
description: "Test-author role in the dev-* workflow. For one milestone marked independent, writes failing acceptance tests and interface stubs from the accepted plan alone, before any implementation exists. Use only when the user invokes it by name, in a fresh session."
argument-hint: "<slug> <milestone>"
disable-model-invocation: true
---

# dev-test: the test author

For one milestone, you turn the plan's acceptance criteria into executable tests, before the builder starts. Your tests are the evidence that the code does what the user asked, so they must come from the plan, not from any idea of how the code will work. You don't implement the feature. Your step is `Mx test`.

## Work out your job

The invocation gives the slug and the milestone, for example `csv-import M2`.

1. **The user gave a decision:** record it ([Every step](#every-step)), then carry on.
2. **`handoff-Mx.md` already has an "Acceptance tests" section**, with its commit in the log: you're done. Print the baton again.
3. **Check the preconditions.** Stop and tell the user if:
   - `plan.md` has no `Accepted:` version. Tests are written against an accepted plan only.
   - The milestone is marked `Tests: builder`. On those, the builder writes the acceptance tests: the baton is `dev-build <slug> Mx`.
   - This milestone's implementation already exists beyond stubs. Tests written now wouldn't be independent.
4. **Otherwise:** write the tests, as below.

## Read

- `requirement.md`, and in `plan.md`:
  - this milestone's block;
  - the acceptance criteria it covers, with their worked examples;
  - the interface;
  - Risks and edge cases, with each one's mark (`test`, `raises` or `check at`);
  - the facts the plan relies on (units, signs, dates, keys), so your test data follows them;
  - the Decision log.
- The existing tests, fixtures and helpers, so that your tests follow the project's conventions.
- Code from earlier, accepted milestones, but only as far as you need it to call the interface.

Don't read another session's reasoning, or anything about how this milestone will be built.

## Write the tests

1. **Stubs.** Where the plan's interface doesn't exist yet, create it with the plan's exact signatures, and bodies that raise `NotImplementedError`. A result type the interface names gets the fields the plan gives it. Put nothing else in production files.
2. **Acceptance tests.** Put them in `tests/acceptance/`, unless the plan's Test strategy says otherwise. Test only through the public interface. Name each test after its criterion, for example `test_ac3_window_excludes_current_bar`. Cover:
   - every worked example in the plan, with the values copied exactly;
   - the Risks marked `test` that apply to this milestone: the quiet money and data risks, such as signs, units and scale, rounding, time zones, as-of dates, off-by-one windows, look-ahead, duplicate or missing keys, and running twice. A risk marked `raises` gets no test. If an older plan marks nothing, test only the risks that would give a wrong number quietly;
   - each error the interface names, with one test per error, not one per bad value;
   - invariants where they fit. For example: changing data after time t doesn't change the result at t; running twice gives the same result; totals reconcile;
   - for numerical logic, consider a deliberately simple reference implementation inside the test file (a plain loop, slow and obviously correct), compared with the real one on small generated inputs.
3. **Say where each expected value came from**, in a short comment: `# plan AC-3 example 2`, `# hand-computed: (101 - 100) / 100`, `# invariant`, or `# reference implementation`. Never get an expected value by running the code under test, and never copy a formula you expect the implementation to use.
4. **Tolerances.** Compare exactly where the plan's values are exact. Otherwise use the tightest tolerance the plan justifies, and say why in a comment.
5. **Safe to run in parallel.** Each test sets up and cleans up its own state, so the suite can run in parallel and stay fast enough for every gate:
   - files go in a temporary directory (`tmp_path` in pytest, `os.tmpdir()` in Node), never a fixed path in the repo or the home folder;
   - no shared database, port or global setting is left changed;
   - no test relies on another having run first;
   - anything a test creates gets a unique name.

   Shared fixtures that are only read are fine.

**Keep it small.** Every test is code the user maintains for good, so the suite should be about the model, not about turning inputs away. A few tests per AC is normal. Parametrize over the worked examples, not over lists of bad values. Don't test inputs that would fail loudly anyway (wrong types, impossible dates, overflow, typos in the user's own config), and don't repeat a test across modes or layers that run the same check.

Test the behavior the plan specifies, not the internals. Don't test private helpers, call order or log output, unless an acceptance criterion asks for it.

## When the plan isn't enough

If you can't turn a criterion into a test without guessing (a missing interface detail, an ambiguous rule, or no expected value on a money path), don't guess silently:

1. Add an `ESC-n` with the possible readings and the one you'd pick.
2. Write the test for your pick, with a comment `# ESC-n: assumes <pick>`.
3. List it in the handoff.

The user decides before the build, and if they choose differently, the builder changes the test to match their decision.

## Red run

Run your new acceptance tests, plus the quick checks for the files your stubs touch. The full checks aren't needed here: the builder runs them once at the end of the build.

- Every new acceptance test must fail for the right reason: `NotImplementedError` from a stub, or an assertion. An import, collection or fixture error doesn't count, so fix it.
- If a new test passes against the stubs, it isn't testing this milestone's behavior. Fix it, or explain in the handoff why it passes.
- The existing tests in your quick checks must still pass, apart from the plan's known baseline failures. The builder's full run covers the rest of the suite.

## Finish

Follow [Every step](#every-step), with these details:

1. Commit only the tests, fixtures and stubs, as `<slug> Mx: acceptance tests`.
2. Create `docs/work/<slug>/handoff-Mx.md`:

   ```
   # Handoff Mx: <slug>

   ## Acceptance tests (test author) · <date> · "<session name>" (<vendor> <model>)
   Plan: v<N>, covers AC-…
   Tests commit: <base>..<hash>
   Stubs: <file: signature>, …

   | AC | Tests | Expected values from |
   |---|---|---|
   | AC-4 | test_ac4_reimport_adds_nothing | plan AC-4 example 1 |

   Red run: <command> → <N> new tests failing as expected; quick checks: <command> → <M> passing
   Ambiguities: ESC-n: <readings>; the tests assume <pick>. Or "none".
   Not covered by acceptance tests, and why: …
   Calls I made: …
   ```

3. In `plan.md`, set this milestone's Progress row to `tests written`. That's the only change you make to the plan, apart from recording the user's decisions.
4. The baton is `dev-build <slug> Mx`, in a new session, ideally from the other vendor than yours. If there are open ESC IDs, the baton says the user must decide them first. They can add the decisions to the build line, for example `/dev-build csv-import M2 ESC-3: keep both rows`.

Your session is finished after this. Nobody comes back to it. If one of your tests turns out to be wrong, the reviewer or the user states the corrected expectation, and the builder applies it.

## Every step

*This section is the same in all five `dev-*` skills. Change all five together.*

### Start

1. **Read the invocation.** It gives the feature slug, then the target if this skill takes one (`plan`, `M2`, `final`). Anything after that is the user's: a requirement, a decision, or extra focus. The feature's files are in `docs/work/<slug>/`, unless the project's instructions name another place.
2. **Find the checks** in the "Checks" section of `plan.md`. `dev-plan` works them out from the project's own files when it drafts the plan. If the plan has no such section (it predates it), use the commands that the latest saved run or handoff used, so that every step runs the same ones. If there are none yet, work them out the way `dev-plan` does (`dev-status` only reads them), and note them under "Calls I made". Either way, suggest adding the section with `dev-plan <slug> add a Checks section to the plan`. Follow the project's instructions (`AGENTS.md`, `CLAUDE.md`, a README) where they exist, but never require them. If a command won't run on this machine (it's missing, not failing), stop and ask the user.
3. **Check git.** The project must be a git repository.
   - Work on branch `work/<slug>`. Only `dev-plan` creates it. If you're on another branch and the tree is clean, switch to it. If `HEAD` is detached, an output comparison stopped partway or is still running in another session: `dev-status` only reports it; any other step asks the user, and switches back to `work/<slug>` once they confirm nothing is running.
   - Run `git status --porcelain`. If there are uncommitted changes you didn't make in this session, never stash, commit or discard them yourself. (`dev-status` only reports them.)
     - **If they look like an interrupted run of your own step** (the files your step writes, for the same target, and no `log.md` row for that run yet): show the user `git status` and a short summary of the diff, and ask whether to carry on from them. If they agree, adopt them and say so under "Calls I made". If they don't, stop.
     - **Otherwise:** stop, and tell the user which step the changes seem to come from. Rerunning that step, in a fresh session if need be, will offer to carry on from them. Or the user can commit or discard them.
4. **Read `log.md`** in the feature folder, if it exists. Its last row is where things stand.
5. **Name the session**, if nothing else has been done in it yet. Use the name from the table below. If you have a tool that renames the current session (in the Claude desktop app, `set_session_title` with session id `self`), use it. Then file the session under the sidebar group named `<slug>`: list the groups first, and create the group only if it's missing. If you have no such tool, skip this step, because the user names the session.

| Step | Session name |
|---|---|
| `dev-plan` | `<slug> plan` |
| `dev-review plan` | `<slug> plan-review` |
| `dev-test Mx` | `<slug> Mx test` |
| `dev-build Mx` | `<slug> Mx build` |
| `dev-review Mx` | `<slug> Mx review` |
| `dev-review final` | `<slug> final-review` |
| `dev-build final` | `<slug> final-fix` |
| `dev-status` | `<slug> status` |

### While you work

- **One role.** You may use subagents for your own work, such as searching the code or probing several risks at once. Never start another role, either as a subagent or by messaging another session. Each role starts from a line the user pastes.
- **The user's decisions.** The user may give one in the invocation, or type it later in plain words: "approve the plan", "ESC-2: option B", "accept M2", "defer F4 to M3", "allow one more round on M2". Record it straight away:
  - add `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")` to the Decision log in `plan.md`;
  - approving the plan also sets its `Accepted:` line, and accepting a milestone or the feature also updates Progress (`dev-plan` and `dev-status` give the details, and `dev-review` follows `dev-status` when the user accepts at its gate baton);
  - mention it in your next `log.md` row, and commit it with your step. If you've already finished (for example, the user typed it after your baton), add a row with step `decision` and commit straight away, as `<slug>: decision <ref>`, or with the message your role gives for that decision (such as `<slug> Mx: accepted`).

  Then act on the decision only as far as your role allows.
- **What a review covers.** A review covers the code and tests at its `Reviewed:` head, and the plan version it names. If a round names no plan version, use the `Version:` line of `plan.md` at its `Reviewed:` head (`git show <head>:<path to plan.md>`). Later commits that touch only the feature folder's records leave it valid. Any other change (code, tests, configuration), or a new plan version, makes it stale, and it must be reviewed again before a gate relies on it. One exception: a version that only adds a Checks section to a plan that had none, keeping the commands that earlier runs used, leaves milestone and final reviews valid. To check, run `git diff --name-only <reviewed head> HEAD` and compare the plan's `Version:` line.
- **Escalations.** Their IDs run `ESC-1`, `ESC-2`, … across the whole feature: take the number after the highest `ESC-` anywhere in the feature folder. Each one states the question, the options and your recommendation. It stays open until the Decision log has an entry for it.
- **Your own calls.** Every choice you make that the user didn't goes under "Calls I made" in your handoff, response or review. Examples: picking one reading of an ambiguity, a small deviation from the plan.
- **Quick and full checks.** The *full checks* are every command in the plan's Checks section. The *quick checks* are the test files that cover what you changed, plus the quick command in Checks if it names one. Use quick checks while you work. A gate always rests on a full run, either run or cited, so quick checks never replace one.
  - **Run once, and save the output.** Run the full checks where your role says so, after your last change to code or tests. Save the output to `runs/<YYYY-MM-DD-HHMM>-<step>-<short hash>.txt` in the feature folder. Start with the commit, each command, how long it took and its result, then the runner's output; if that's very long, keep its summary and every failure in full. Commit the file with your records, and name it in your handoff, response or review, and in your `log.md` row. When the full checks take more than a couple of minutes, start them in the background if your tool allows, and keep reading while they run.
  - **Cite instead of rerunning** when a saved run exists whose commit differs from `HEAD` only in records, meaning `git diff --name-only <its commit> HEAD` lists only files in the feature folder. Open the file and check its commit, commands and result yourself; never take a summary's word for them. Run again if the file is missing, its commit or commands differ, or anything else has changed: code, tests, configuration, dependencies or test data. An `M0` that writes only findings usually needs no run of its own.
- **Output comparison.** A milestone's `Compare:` line in the plan gives a command that runs real input through the code and leaves its outputs in `{out}`, plus how to compare them. If Surprises and deviations records a newer input or command for it, use that. To run it:
  1. Commit anything you've changed, so that the tree is clean apart from your own `runs/` files. Records go in a `<slug> <step>: records` commit; another one at Finish is fine.
  2. Make two new, empty temporary folders outside the repository. Run the command at `HEAD` into the first.
  3. `git switch --detach <base>`, run the command (or its `at base:` form) into the second, and `git switch work/<slug>`. The base is the commit before the milestone's first commit: the `<base>` of the milestone's first range in `log.md`, or, for a builder making that first commit, `HEAD` before it. For a milestone reopened after later milestones were built, it's `HEAD` before the reopen's first commit, and only what the reopen's decision names may differ.
  4. After each run, check `git status --porcelain`. If the run changed anything, restore it before going on, and don't use that run: the `Compare:` line is wrong, because it must write nothing inside the repository, caches included. The builder fixes the command, as a small plan change under Surprises and deviations; a reviewer raises a P2 against the `Compare:` line.

  Compare the two as the line says. Save the result to `runs/<YYYY-MM-DD-HHMM>-<step>-compare-<short hash>.txt`: both commits, the command, the input, and either "identical" or the number of differences with the first 10. Name it wherever you name your full run. Never switch while a full run of yours is still going.

### Finish

1. **Checks.** Run the checks your role names, if any, and note each command and its result. Run the full checks on committed code: make the first commit of step 2 (your work) before you run them, so that a saved run names a commit holding exactly what was tested. If they fail and you fix something, commit again and rerun.
2. **Commit.** Commit your work first, with the message your role gives. Then update your records (handoff, review, `plan.md`, `log.md`) citing that commit, and commit them as `<slug> <step>: records`. When your step writes only records, one commit is enough. Never push, amend, rebase or merge. The tree must be clean when you stop.
3. **Log.** Append one row to `log.md`. If the file is missing, create it with the heading `# Log: <slug>` and this table header:

   ```
   | When | Session | Step | Result | Next |
   |---|---|---|---|---|
   ```

   - **When:** local time, as `YYYY-MM-DD HH:MM`.
   - **Session:** `<session name> (<vendor> <model>)`, for example `csv-import M2 review (Claude Opus 5.5)`. Your vendor is Claude when you run in Claude Code, and Codex when you run in Codex. Add `, same vendor` when a check ran on the same vendor as the work it checks:
     - plan-review against plan;
     - Mx test against Mx build (the builder adds it);
     - Mx review against Mx build;
     - final-review against the vendor that built most milestones.
   - **Step:** the skill and target, for example `dev-review M2` or `dev-build M2 (answers r1)`.
   - **Result:** the commit or commit range, the test result, the verdict, counts, and any new ESC IDs.
   - **Next:** the paste line or lines from your baton.
4. **Reply** in at most 8 lines, then end with the baton:

   ```
   Done: <slug> <step>. <commit, tests, verdict, what's open>.
   Next: <what>, in <a new session | the "<session name>" session> (<vendor>: <why>). Paste:
     <line or lines>
   ```

   | The next session is | Claude | Codex |
   |---|---|---|
   | New | `/dev-x <args>`. In a terminal: `claude -n "<session name>" "/dev-x <args>"` | `/rename <session name>`, then `$dev-x <args>` |
   | Already open | `/dev-x <args>` | `$dev-x <args>` |

   **Which vendor to suggest.** For a check (plan-review, Mx test, Mx review, final-review), suggest the vendor that didn't write what it checks, using `log.md`. Add "or a fresh `<same vendor>` session if `<other vendor>` has no capacity". For Mx test the builder isn't known yet, so say "the vendor that won't build Mx". For a writing step, suggest the vendor the user last used for that kind of step. The user can always override the suggestion.

   When the next step is the user's (a gate, or an escalation to decide), the baton says what to read or decide, and what to type in which session.

**Restarted?** If the files show your step has already finished, for example after a crash, don't redo it. Print the baton again.
