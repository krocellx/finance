---
name: dev-status
description: "The user's console in the dev-* workflow. Shows where a feature stands and what needs the user, from the feature's files and git; records the user's decisions, including accepting a milestone (gate 2) or the feature (gate 3). Use only when the user invokes it by name."
argument-hint: "[slug] [decision]"
disable-model-invocation: true
---

# dev-status: the user's console

You show the user where a feature stands, and what needs them, using only the files and git. You never change code, tests or reviews. You run no checks. You write only the user's decisions. Your step is `status`.

## Work out your job

- **No slug:** list each folder in `docs/work/`, one line each: the slug, and the last row of its `log.md`. Stop.
- **A slug:** show the [status](#the-status). If the user gave a decision in the invocation or types one afterwards, [record it](#decisions). If the tree isn't clean, show the status, but don't record decisions until it is.

## The status

Read `log.md`, `plan.md`, every `review-*.md` and `handoff-*.md` in the feature folder, and git (the branch, `git status --porcelain`, `HEAD`, and whether the commits in `log.md` exist). Keep the whole reply to about 25 lines:

```
<slug> · plan v<N>, accepted <date> (or "draft") · work/<slug> @ <short hash>, clean
| Milestone | Tests | State | Latest |
|---|---|---|---|
| M1 | builder | accepted 10-09 | |
| M2 | independent | CHANGES REQUIRED, recheck 1 of 2 | F2 (P1) open |
| M3 | independent | planned | |

Needs you:
1. ESC-3 (review-M2.md, F3): <the question>. Options A and B; recommended: B.
2. Same vendor: the M2 review was Claude, checking Claude's build.

Next: <the last log row's Next>
```

Under "Needs you", list everything that waits on the user. Write "nothing" if there's none.

- Open escalations: an `ESC-n` anywhere in the folder with no Decision log entry.
- A gate that's ready (below).
- Checks that ran on the same vendor as the work they checked (the log marks them), apart from reviews of auto-accepted milestones. Those appear under "Worth a glance" in the review and at gate 3.
- REVIEW INCOMPLETE verdicts.
- Problems with the record: a dirty tree, the wrong branch, a commit named in `log.md` that git doesn't have, a Progress state that disagrees with the latest review. Report them; don't fix them.

## Gate views

When a gate is ready, add its gate view below the status. First check that the READY round still covers the current state ([Every step](#every-step), "What a review covers"). If it's stale, say what changed, show no gate view, and make the baton the same `dev-review` line again.

**Gate 1, the plan.** The plan isn't accepted yet, and either its latest review is READY or it's a medium plan (which has no review). List:

- the Goal and Non-goals;
- each AC with its worked examples, marking those that came from the planner and need confirming;
- the milestones, with each `Tests:` mark and its reason, and the `Compare:` line where there is one;
- the Risks on money or data paths marked `raises` or `check at`, one line each;
- the facts the plan relies on that are still `unverified`, each with how the plan settles it;
- the Checks section: the full and quick commands, how long the full checks took, and any known baseline failures;
- the open escalations.

Then: type `approve the plan`, in the `<slug> plan` session or here.

**Gate 2, a milestone.** Its latest review is READY, and Progress says `READY` (the reviewer didn't auto-accept it). Don't hand the user a reading list. Show the "For the user" section of the READY round. If the round has none (reviews written before this section existed), build it yourself from the handoff and the reviews, using three tiers. Something the user already approved, in the plan or the Decision log, isn't news: name the plan line or decision that covers it, and put it in the third tier.

1. **Needs your call**, *same list as in `dev-review`; change both together*:
   - an open escalation;
   - a TEST DISPUTE ruling that changed the test author's expected value;
   - a finding on a money or data path that was WITHDRAWN, or that the user DEFERRED;
   - a change to an acceptance test, or a weakened test, that neither the plan, the Decision log, nor a VERIFIED reviewer finding names.

   For each one, write one or two sentences: what happened, what it risks, and the question.
2. **Worth a glance:** at most 3 one-liners, each ending with what it costs if wrong: deviations from the plan, files touched outside the milestone's list, same-vendor checks.
3. **Matches the plan:** one line with the AC trace result (for example, "AC-1, 2, 4 pass"), the test counts, the output comparison if there is one (for example, "same output on the 2024 10-K"), and the planned changes with their plan reference (for example, "6 converter tests deleted, as cut in B5").

On `independent` milestones, also list the acceptance test names, one per line, under "The spec, as tested". They're the one thing worth a quick read, because they say what was pinned down.

Quote what matters inline; the user shouldn't have to open a file. When a source helps, cite the file and its section heading (`handoff-M3.md`, "Weakened tests"), never a line number.

End with a verdict line:
- tier 1 empty: `Nothing needs your judgment. Type accept Mx here.`
- otherwise: `Answer the N item(s) above, then type accept Mx here, or say what's wrong.`

**Gate 3, the feature.** `review-final.md` is READY, or, on a medium plan (which has no final review), every milestone is accepted. List:

- the commands it gives for one normal case and one failure case, for the user to run (on a medium plan, write them yourself from the plan's ACs);
- each auto-accepted milestone, with the "Worth a glance" lines from its READY round (or "nothing"). This is the user's one look at the calls made on those milestones;
- anything still deferred;
- everything under "Found outside this change" in the handoffs and reviews, one line per defect even when several rounds note it (or "nothing"). These are defects in code the feature didn't change. They don't block the merge; any of them can become its own piece of work, started with `dev-plan`;
- **how the process went**, in about 4 lines, counted from the review files, the handoffs, `plan.md` and `log.md`:
  - rounds per target, counted as the round budget counts them (REVIEW INCOMPLETE rounds don't count), for example `plan 3, M1 1, M2 2, final 1`, plus any hand-offs;
  - P0–P2 findings by how they ended: VERIFIED, WITHDRAWN, DOWNGRADED, DEFERRED, ESCALATED, or still open when the user accepted over them; and the number of P3 notes;
  - test disputes, and how each was ruled: the test was wrong, the code was wrong, or escalated;
  - milestones auto-accepted, accepted milestones later reopened, and checks that ran on the same vendor.

  These are the numbers that decide, after the pilot, which steps earn their place.

Then: type `accept the feature` here.

## Decisions

Record each decision as [Every step](#every-step) says, with these additions:

- **`accept Mx`:**
  - If the latest review of Mx isn't READY, or its READY is stale, say what's open or what changed, and ask the user once to confirm, with a reason that goes in the Decision log.
  - Set the milestone's Progress row to `accepted <date>`, and commit as `<slug> Mx: accepted`.
  - The baton is the next milestone in the plan:
    - an `independent` milestone: `dev-test <slug> M<next>`, in a new session from the vendor that won't build it;
    - a `builder` milestone: `dev-build <slug> M<next>`, in a new session.
  - After the last milestone, the baton is `dev-review <slug> final`, in a new session, ideally from the vendor that built least. A medium plan has no final review, so the user goes straight to gate 3: show its gate view (below) right away, then they type `accept the feature`.
  - Remind the user they can archive the `Mx build`, `Mx test` and `Mx review` sessions.
- **`approve the plan`:**
  - If the latest plan review isn't READY or is for an older plan version (on a full plan), an escalation is still open, or a `(planner; confirm at gate 1)` example hasn't been confirmed, list it, and ask the user once to confirm, with a reason.
  - Set `Accepted: v<N> <date>` at the top of `plan.md`, and every Progress row to `planned`. Commit as `<slug>: plan v<N> accepted`.
  - The baton is the first milestone, as for `accept Mx` above.
- **`accept the feature`:**
  - If `review-final.md` isn't READY, or its READY is stale, ask the user once to confirm, with a reason. A medium plan has no final review, and needs none.
  - Add a Progress row `Feature | accepted | <date>`, and commit as `<slug>: feature accepted`. The `log.md` row's Result gives the "how the process went" counts on one line, so they can be compared across features.
  - The baton gives the merge commands for the user to run themselves, for example `git switch <base branch>` and then `git merge --no-ff work/<slug>`, and reminds them to archive the remaining sessions. Never merge or push yourself.
- **`reopen Mx: <what's wrong>`** (usually on an auto-accepted milestone, but any accepted one counts):
  - Set the milestone's Progress row to `reopened (<date>, you)`, and commit with the decision.
  - If what's wrong changes an AC, an interface or the design, the baton is `dev-plan <slug>` to amend the plan; it reopens the affected milestones itself.
  - Otherwise, the baton is `dev-build <slug> Mx`, in a new session. Then the reviewer rechecks it, and it won't be auto-accepted again.
  - If a later milestone was already built on top of it, say so: that milestone may need reopening too.
- **`stop at Mx`** or **`stop at every gate`:** record it. The reviewer then won't auto-accept that milestone, or any milestone.
- **Anything else** ("ESC-2: option B", "defer F4 to M3", "allow one more round on M2"): record it. The baton is whatever was next before the decision, unless the decision changes that. For example, a decision that changes an AC sends the user to `dev-plan <slug>` to amend the plan.

## Every step

*This section is the same in all five `dev-*` skills. Change all five together.*

### Start

1. **Read the invocation.** It gives the feature slug, then the target if this skill takes one (`plan`, `M2`, `final`). Anything after that is the user's: a requirement, a decision, or extra focus. The feature's files are in `docs/work/<slug>/`, unless the project's instructions name another place.
2. **Find the checks** in the "Checks" section of `plan.md`. `dev-plan` works them out from the project's own files when it drafts the plan. If the plan has no such section (it predates it), use the commands that the latest saved run or handoff used, so that every step runs the same ones. If there are none yet, work them out the way `dev-plan` does (`dev-status` only reads them), and note them under "Calls I made". Either way, suggest adding the section with `dev-plan <slug> add a Checks section to the plan`. Follow the project's instructions (`AGENTS.md`, `CLAUDE.md`, a README) where they exist, but never require them. If a command won't run on this machine (it's missing, not failing), stop and ask the user.
3. **Check git.** The project must be a git repository.
   - Work on branch `work/<slug>`. Only `dev-plan` creates it. If you're on another branch and the tree is clean, switch to it. If `HEAD` is detached, an output comparison stopped partway or is still running in another session: `dev-status` only reports it; any other step asks the user, and switches back to `work/<slug>` once they confirm nothing is running.
   - Run `git status --porcelain`. If there are uncommitted changes you didn't make in this session, never stash, commit or discard them yourself. (`dev-status` only reports them.)
     - **If they look like an interrupted run of your own step** (the files your step writes, for the same target, and no `log.md` row for that run yet): show the user `git status` and a short summary of the diff, and ask whether to carry on from them. If they agree, adopt them and say so under "Calls I made". If they don't, stop.
     - **Otherwise:** stop, and tell the user which step the changes seem to come from. Rerunning that step, in a fresh session if need be, will offer to carry on from them. Or the user can commit or discard them.
4. **Read `log.md`** in the feature folder, if it exists. Its last row is where things stand.
5. **Name the session**, if nothing else has been done in it yet. Use the name from the table below. If you have a tool that renames the current session (in the Claude desktop app, `set_session_title` with session id `self`), use it. Then file the session under the sidebar group named `<slug>`: list the groups first, and create the group only if it's missing. If you have no such tool, skip this step, because the user names the session.

| Step | Session name |
|---|---|
| `dev-plan` | `<slug> plan` |
| `dev-review plan` | `<slug> plan-review` |
| `dev-test Mx` | `<slug> Mx test` |
| `dev-build Mx` | `<slug> Mx build` |
| `dev-review Mx` | `<slug> Mx review` |
| `dev-review final` | `<slug> final-review` |
| `dev-build final` | `<slug> final-fix` |
| `dev-status` | `<slug> status` |

### While you work

- **One role.** You may use subagents for your own work, such as searching the code or probing several risks at once. Never start another role, either as a subagent or by messaging another session. Each role starts from a line the user pastes.
- **The user's decisions.** The user may give one in the invocation, or type it later in plain words: "approve the plan", "ESC-2: option B", "accept M2", "defer F4 to M3", "allow one more round on M2". Record it straight away:
  - add `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")` to the Decision log in `plan.md`;
  - approving the plan also sets its `Accepted:` line, and accepting a milestone or the feature also updates Progress (`dev-plan` and `dev-status` give the details, and `dev-review` follows `dev-status` when the user accepts at its gate baton);
  - mention it in your next `log.md` row, and commit it with your step. If you've already finished (for example, the user typed it after your baton), add a row with step `decision` and commit straight away, as `<slug>: decision <ref>`, or with the message your role gives for that decision (such as `<slug> Mx: accepted`).

  Then act on the decision only as far as your role allows.
- **What a review covers.** A review covers the code and tests at its `Reviewed:` head, and the plan version it names. If a round names no plan version, use the `Version:` line of `plan.md` at its `Reviewed:` head (`git show <head>:<path to plan.md>`). Later commits that touch only the feature folder's records leave it valid. Any other change (code, tests, configuration), or a new plan version, makes it stale, and it must be reviewed again before a gate relies on it. One exception: a version that only adds a Checks section to a plan that had none, keeping the commands that earlier runs used, leaves milestone and final reviews valid. To check, run `git diff --name-only <reviewed head> HEAD` and compare the plan's `Version:` line.
- **Escalations.** Their IDs run `ESC-1`, `ESC-2`, … across the whole feature: take the number after the highest `ESC-` anywhere in the feature folder. Each one states the question, the options and your recommendation. It stays open until the Decision log has an entry for it.
- **Your own calls.** Every choice you make that the user didn't goes under "Calls I made" in your handoff, response or review. Examples: picking one reading of an ambiguity, a small deviation from the plan.
- **Quick and full checks.** The *full checks* are every command in the plan's Checks section. The *quick checks* are the test files that cover what you changed, plus the quick command in Checks if it names one. Use quick checks while you work. A gate always rests on a full run, either run or cited, so quick checks never replace one.
  - **Run once, and save the output.** Run the full checks where your role says so, after your last change to code or tests. Save the output to `runs/<YYYY-MM-DD-HHMM>-<step>-<short hash>.txt` in the feature folder. Start with the commit, each command, how long it took and its result, then the runner's output; if that's very long, keep its summary and every failure in full. Commit the file with your records, and name it in your handoff, response or review, and in your `log.md` row. When the full checks take more than a couple of minutes, start them in the background if your tool allows, and keep reading while they run.
  - **Cite instead of rerunning** when a saved run exists whose commit differs from `HEAD` only in records, meaning `git diff --name-only <its commit> HEAD` lists only files in the feature folder. Open the file and check its commit, commands and result yourself; never take a summary's word for them. Run again if the file is missing, its commit or commands differ, or anything else has changed: code, tests, configuration, dependencies or test data. An `M0` that writes only findings usually needs no run of its own.
- **Output comparison.** A milestone's `Compare:` line in the plan gives a command that runs real input through the code and leaves its outputs in `{out}`, plus how to compare them. If Surprises and deviations records a newer input or command for it, use that. To run it:
  1. Commit anything you've changed, so that the tree is clean apart from your own `runs/` files. Records go in a `<slug> <step>: records` commit; another one at Finish is fine.
  2. Make two new, empty temporary folders outside the repository. Run the command at `HEAD` into the first.
  3. `git switch --detach <base>`, run the command (or its `at base:` form) into the second, and `git switch work/<slug>`. The base is the commit before the milestone's first commit: the `<base>` of the milestone's first range in `log.md`, or, for a builder making that first commit, `HEAD` before it. For a milestone reopened after later milestones were built, it's `HEAD` before the reopen's first commit, and only what the reopen's decision names may differ.
  4. After each run, check `git status --porcelain`. If the run changed anything, restore it before going on, and don't use that run: the `Compare:` line is wrong, because it must write nothing inside the repository, caches included. The builder fixes the command, as a small plan change under Surprises and deviations; a reviewer raises a P2 against the `Compare:` line.

  Compare the two as the line says. Save the result to `runs/<YYYY-MM-DD-HHMM>-<step>-compare-<short hash>.txt`: both commits, the command, the input, and either "identical" or the number of differences with the first 10. Name it wherever you name your full run. Never switch while a full run of yours is still going.

### Finish

1. **Checks.** Run the checks your role names, if any, and note each command and its result. Run the full checks on committed code: make the first commit of step 2 (your work) before you run them, so that a saved run names a commit holding exactly what was tested. If they fail and you fix something, commit again and rerun.
2. **Commit.** Commit your work first, with the message your role gives. Then update your records (handoff, review, `plan.md`, `log.md`) citing that commit, and commit them as `<slug> <step>: records`. When your step writes only records, one commit is enough. Never push, amend, rebase or merge. The tree must be clean when you stop.
3. **Log.** Append one row to `log.md`. If the file is missing, create it with the heading `# Log: <slug>` and this table header:

   ```
   | When | Session | Step | Result | Next |
   |---|---|---|---|---|
   ```

   - **When:** local time, as `YYYY-MM-DD HH:MM`.
   - **Session:** `<session name> (<vendor> <model>)`, for example `csv-import M2 review (Claude Opus 5.5)`. Your vendor is Claude when you run in Claude Code, and Codex when you run in Codex. Add `, same vendor` when a check ran on the same vendor as the work it checks:
     - plan-review against plan;
     - Mx test against Mx build (the builder adds it);
     - Mx review against Mx build;
     - final-review against the vendor that built most milestones.
   - **Step:** the skill and target, for example `dev-review M2` or `dev-build M2 (answers r1)`.
   - **Result:** the commit or commit range, the test result, the verdict, counts, and any new ESC IDs.
   - **Next:** the paste line or lines from your baton.
4. **Reply** in at most 8 lines, then end with the baton:

   ```
   Done: <slug> <step>. <commit, tests, verdict, what's open>.
   Next: <what>, in <a new session | the "<session name>" session> (<vendor>: <why>). Paste:
     <line or lines>
   ```

   | The next session is | Claude | Codex |
   |---|---|---|
   | New | `/dev-x <args>`. In a terminal: `claude -n "<session name>" "/dev-x <args>"` | `/rename <session name>`, then `$dev-x <args>` |
   | Already open | `/dev-x <args>` | `$dev-x <args>` |

   **Which vendor to suggest.** For a check (plan-review, Mx test, Mx review, final-review), suggest the vendor that didn't write what it checks, using `log.md`. Add "or a fresh `<same vendor>` session if `<other vendor>` has no capacity". For Mx test the builder isn't known yet, so say "the vendor that won't build Mx". For a writing step, suggest the vendor the user last used for that kind of step. The user can always override the suggestion.

   When the next step is the user's (a gate, or an escalation to decide), the baton says what to read or decide, and what to type in which session.

**Restarted?** If the files show your step has already finished, for example after a crash, don't redo it. Print the baton again.
