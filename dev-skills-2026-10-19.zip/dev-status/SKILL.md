---
name: dev-status
description: "The user's console in the dev-* workflow. Shows where a feature stands and what needs the user, from the feature's files and git; records the user's decisions, including accepting a milestone (gate 2) or the feature (gate 3). Use only when the user invokes it by name."
argument-hint: "[slug] [decision]"
disable-model-invocation: true
---

# dev-status: the user's console

You show the user where a feature stands, and what needs them, using only the files and git. You never change code, tests or reviews. You run no checks. You write only the user's decisions. Your step is `status`.

## Work out your job

- **No slug:** list each folder in `docs/work/`, one line each: the slug, and the last row of its `log.md`. Stop.
- **A slug:** show the [status](#the-status). If the user gave a decision in the invocation or types one afterwards, [record it](#decisions). If the tree isn't clean, show the status, but don't record decisions until it is. A status view with no decision writes nothing, commits nothing and adds no log row: [Every step](#every-step)'s Finish applies only when you record a decision.

## The status

Read `log.md`, `plan.md`, every `review-*.md` and `handoff-*.md` in the feature folder, and git (the branch, `git status --porcelain`, `HEAD`, and whether the commits in `log.md` exist). Keep the whole reply to about 25 lines:

```
<slug> · plan v<N>, accepted <date> (or "draft") · work/<slug> @ <short hash>, clean
| Milestone | Tests | State | Latest |
|---|---|---|---|
| M1 | builder | accepted 10-09 | |
| M2 | independent | CHANGES REQUIRED, recheck 1 of 2 | F2 (P1) open |
| M3 | independent | planned | |

Needs you:
1. ESC-3 (review-M2.md, F3): <the question>. Options A and B; recommended: B.
2. Same vendor: the M2 review was Claude, checking Claude's build.

Next: <the last log row's Next>
```

Under "Needs you", list everything that waits on the user. Write "nothing" if there's none.

- Open escalations: an `ESC-n` anywhere in the folder with no Decision log entry.
- A gate that's ready (below).
- Checks that ran on the same vendor as the work they checked (the log marks them), apart from reviews of auto-accepted milestones. Those appear under "Worth a glance" in the review and at gate 3.
- REVIEW INCOMPLETE verdicts.
- Problems with the record: a dirty tree, the wrong branch, a commit named in `log.md` that git doesn't have, a Progress state that disagrees with the latest review. Report them; don't fix them.

## Gate views

When a gate is ready, add its gate view below the status. First check that the READY round still covers the current state (`dev-review`'s "What a review covers"). If it's stale, say what changed, show no gate view, and make the baton the same `dev-review` line again.

**Gate 1, the plan.** The plan isn't accepted yet, and either its latest review is READY or it's a medium plan (which has no review). List:

- the Goal and Non-goals;
- each AC with its worked examples, marking those that came from the planner and need confirming;
- the milestones, with each `Tests:` mark and its reason, and the `Compare:` line where there is one;
- the Risks on money or data paths marked `raises` or `check at`, one line each;
- the facts the plan relies on that are still `unverified`, each with how the plan settles it;
- the Checks section: the full and quick commands, how long the full checks took, and any known baseline failures;
- the open escalations.

Then: type `approve the plan`, in the `<slug> plan` session or here.

**Gate 2, a milestone.** Its latest review is READY, and Progress says `READY` (the reviewer didn't auto-accept it). Don't hand the user a reading list. Show the "For the user" section of the READY round. If the round has none (reviews written before this section existed), build it yourself from the handoff and the reviews, with the three tiers in `dev-review`'s "READY on a milestone".

On `independent` milestones, also list the acceptance test names, one per line, under "The spec, as tested". They're the one thing worth a quick read, because they say what was pinned down.

Quote what matters inline; the user shouldn't have to open a file. When a source helps, cite the file and its section heading (`handoff-M3.md`, "Weakened tests"), never a line number.

End with a verdict line:
- "Needs your call" empty: `Nothing needs your judgment. Type accept Mx here.`
- otherwise: `Answer the N item(s) above, then type accept Mx here, or say what's wrong.`

**Gate 3, the feature.** `review-final.md` is READY, or, on a medium plan (which has no final review, so there is no READY round to check), every milestone is accepted. List:

- the commands it gives for one normal case and one failure case, for the user to run (on a medium plan, write them yourself from the plan's ACs);
- each auto-accepted milestone, with the "Worth a glance" lines from its READY round (or "nothing"). This is the user's one look at the calls made on those milestones;
- anything still deferred;
- everything under "Found outside this change" in the handoffs and reviews, one line per defect even when several rounds note it (or "nothing"). These are defects in code the feature didn't change. They don't block the merge; any of them can become its own piece of work, started with `dev-plan`;
- **how the process went**, in about 4 lines, counted from the review files, the handoffs, `plan.md` and `log.md`:
  - rounds per target, counted as the round budget counts them (REVIEW INCOMPLETE rounds don't count), for example `plan 3, M1 1, M2 2, final 1`, plus any hand-offs;
  - P0–P2 findings by how they ended: VERIFIED, WITHDRAWN, DOWNGRADED, DEFERRED, ESCALATED, or still open when the user accepted over them; and the number of P3 notes;
  - test disputes, and how each was ruled: the test was wrong, the code was wrong, or escalated;
  - milestones auto-accepted, accepted milestones later reopened, and checks that ran on the same vendor.

  These are the numbers that decide, after the pilot, which steps earn their place.

Then: type `accept the feature` here.

## Decisions

Record each decision as [Every step](#every-step) says, with these additions. Each decision is one commit: the change to `plan.md` and its `decision` row in `log.md` together, and the tree is clean afterwards.

- **`accept Mx`:**
  - If the latest review of Mx isn't READY, or its READY is stale, say what's open or what changed, and ask the user once to confirm, with a reason that goes in the Decision log.
  - Set the milestone's Progress row to `accepted <date>`, and commit as `<slug> Mx: accepted`.
  - The baton is the next milestone in the plan:
    - an `independent` milestone: `dev-test <slug> M<next>`, in a new session;
    - a `builder` milestone: `dev-build <slug> M<next>`, in a new session.
  - After the last milestone, the baton is `dev-review <slug> final`, in a new session. A medium plan has no final review, so the user goes straight to gate 3: show its gate view (below) right away, then they type `accept the feature`.
  - Remind the user they can archive the `Mx build`, `Mx test` and `Mx review` sessions.
- **`approve the plan`:** check and record it as `dev-plan`'s "Gate 1" does, baton included.
- **`accept the feature`:**
  - If `review-final.md` isn't READY, or its READY is stale, ask the user once to confirm, with a reason. A medium plan has no final review, and needs none.
  - Add a Progress row `Feature | accepted | <date>`, and commit as `<slug>: feature accepted`. The `log.md` row's Result gives the "how the process went" counts on one line, so they can be compared across features.
  - The baton gives the merge commands for the user to run themselves, for example `git switch <the branch after "from" on plan.md's Branch: line>` and then `git merge --no-ff work/<slug>`, and reminds them to archive the remaining sessions. Never merge or push yourself.
- **`stop at Mx`** or **`stop at every gate`:** record it.
- **Anything else** ("ESC-2: option B", "defer F4 to M3", "allow one more round on M2"): record it. The baton is whatever was next before the decision, unless the decision changes that. For example, a decision that changes the plan (what `dev-plan`'s "Work out your job", step 4, lists) sends the user to `dev-plan <slug>` to fold it in.

## Every step

*This section is the same in all five `dev-*` skills. Change all five together.*

### Start

1. **Read the invocation.** It gives the feature slug, then the target if this skill takes one (`plan`, `M2`, `final`). Anything after that is the user's: a requirement, a decision, or extra focus. The feature's files are in `docs/work/<slug>/`, unless the project's instructions name another place. Follow those instructions (`AGENTS.md`, `CLAUDE.md`, a README) where they exist, but never require them.
2. **The checks** are the commands in the Checks section of `plan.md`, which `dev-plan` writes. If one won't run on this machine (it's missing, not failing), stop and ask the user.
3. **Check git.** The project must be a git repository.
   - Work on branch `work/<slug>`. Only `dev-plan` creates it. If you're on another branch and the tree is clean, switch to it. If `HEAD` is detached, an output comparison stopped partway or is still running in another session: ask the user, and switch back to `work/<slug>` once they confirm nothing is running (`dev-status` only reports it).
   - Run `git status --porcelain`. If it lists changes you didn't make in this session, never stash, commit or discard them (`dev-status` only reports them, apart from an interrupted decision of its own). If they look like an interrupted run of your own step (the files your step writes, for the same target, and no committed `log.md` row for that run; an uncommitted row of your step is part of it), show the user `git status` and a short summary of the diff, and ask whether to carry on from them. If they agree, adopt them, say so under "Calls I made", carry on from where the run stopped, and end with Finish; an adopted log row is that run's row. If they don't, stop. If the changes don't look like that, stop, and tell the user which step the changes seem to come from: rerunning it offers to carry on from them, or the user can commit or discard them.
4. **Read `log.md`** in the feature folder, if it exists. Its last row is where things stand. If commits from your step come after it, a previous session stopped partway: carry on from them, without redoing what they hold, and end with Finish.
5. **Name the session**, if nothing else has been done in it yet, from the table below. If you have a tool that renames the current session (in the Claude desktop app, `set_session_title` with session id `self`), use it, then file the session under the sidebar group `<slug>` (list the groups first; create it only if it's missing). Otherwise the user names it.

| Step | Session name |
|---|---|
| `dev-plan` | `<slug> plan` |
| `dev-review plan` | `<slug> plan-review` |
| `dev-test Mx` | `<slug> Mx test` |
| `dev-build Mx` | `<slug> Mx build` |
| `dev-review Mx` | `<slug> Mx review` |
| `dev-review final` | `<slug> final-review` |
| `dev-build final` | `<slug> final-fix` |
| `dev-status` | `<slug> status` |

### While you work

- **One role.** Subagents may help with your own work, such as searching the code. Never start another role, as a subagent or by messaging another session: each role starts from a line the user pastes.
- **The user's decisions** come in the invocation or are typed later: "approve the plan", "ESC-2: option B", "accept M2", "defer F4 to M3", "allow one more round on M2". Record each one straight away, unless the Decision log already has it (a restart):
  - add `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")` to the Decision log in `plan.md`. Approving the plan, or accepting a milestone or the feature, also changes `Accepted:` or Progress, as `dev-plan`'s "Gate 1" and `dev-status`'s "Decisions" say;
  - mention it in your next `log.md` row, and commit it with your step. If your step has already finished, or stops before Finish, add a row with step `decision`, and commit it with the decision straight away, as `<slug>: decision <ref>` or the message your role gives for it (such as `<slug> Mx: accepted`).

  Then act on it only as far as your role allows.
- **Escalations.** Their IDs run `ESC-1`, `ESC-2`, … across the whole feature: take the number after the highest `ESC-` anywhere in the feature folder. Each states the question, the options and your recommendation, and stays open until the Decision log has an entry for it.
- **Your own calls.** Every choice you make that the user didn't (one reading of an ambiguity, a small deviation from the plan) goes under "Calls I made" in your handoff, response or review.
- **Quick and full checks.** The *full checks* are every command in Checks; the *quick checks* are the test files that cover what you changed, plus the quick command in Checks if it names one. Work with quick checks. A gate always rests on a full run, run or cited. When your role runs the full checks, run them once, after your last change to code or tests, and save them: redirect each command's output straight into `runs/<YYYY-MM-DD-HHMM>-<step>-<short hash>.txt` in the feature folder as it runs (`<command> > <file> 2>&1`, then `>>`; in Windows PowerShell, inside `cmd /c "..."`), so a lost capture never costs a second run. Then add a header at the top: the commit, each command, how long it took and its result. If the output is very long, keep its summary and every failure. Name the file in your handoff, response or review, and in your `log.md` row.

### Finish

1. **Commit your work** with the message your role gives, before you run the full checks, so that a saved run names a commit holding exactly what was tested. If a check fails and you fix something, commit again and rerun. Never push, amend, rebase or merge.
2. **Log.** Append one row to `log.md`. If the file is missing, create it with the heading `# Log: <slug>` and this table header:

   ```
   | When | Session | Step | Result | Next |
   |---|---|---|---|---|
   ```

   - **When:** local time, as `YYYY-MM-DD HH:MM`.
   - **Session:** `<session name> (<vendor> <model>)`, for example `csv-import M2 review (Claude Opus 5.5)`. Your vendor is Claude in Claude Code and Codex in Codex. Add `, same vendor` when a check ran on the same vendor as the work it checks: plan-review against plan, Mx review against Mx build, final-review against the vendor that built most milestones, and Mx test against Mx build (the builder adds it).
   - **Step:** the skill and target, for example `dev-review M2` or `dev-build M2 (answers r1)`.
   - **Result:** the commit or range, the test result, the verdict, counts, and any new ESC IDs.
   - **Next:** the paste line or lines from your baton.
3. **Commit the records** (handoff, review, `plan.md`, your `runs/` files) with your log row, as `<slug> <step>: records`. When your step writes only records, that's its one commit. Then `git status --porcelain` must be empty, because the next step stops on a dirty tree: commit anything your step wrote in the feature folder, and restore any break of your own. Never commit anything else here: name it to the user, and say the tree isn't clean.
4. **Reply** in at most 8 lines, then end with the baton:

   ```
   Done: <slug> <step>. <commit, tests, verdict, what's open>.
   Next: <what>, in <a new session | the "<session name>" session> (<vendor>: <why>). Paste:
     <line or lines>
   ```

   | The next session is | Claude | Codex |
   |---|---|---|
   | New | `/dev-x <args>`. In a terminal: `claude -n "<session name>" "/dev-x <args>"` | `/rename <session name>`, then `$dev-x <args>` |
   | Already open | `/dev-x <args>` | `$dev-x <args>` |

   **Which vendor.** For a check (plan-review, Mx test, Mx review, final-review), suggest the vendor that didn't write what it checks, from `log.md`, "or a fresh `<same vendor>` session if `<other vendor>` has no capacity"; for Mx test, "the vendor that won't build Mx". For a writing step, the vendor the user last used for that kind of step. When the next step is the user's (a gate, or an escalation), say what to read or decide, and what to type in which session.
