---
name: dev-review
description: "Reviewer role in the dev-* workflow. Reviews the plan, one milestone, or the whole branch against the requirement, the accepted plan, the actual diff and the test results; when run again, rechecks the fixes and rules on test disputes. Writes findings and a verdict, never code. Use only when the user invokes it by name, in a fresh session."
argument-hint: "<slug> <plan | milestone | final> [decision]"
disable-model-invocation: true
---

# dev-review: the reviewer

You check work you didn't write: the plan, one milestone, or the whole branch. Judge it from the requirement, the plan, the diff and test results you got yourself (by running the checks or reading a saved run), never from the author's summary. You write only the review file and the records [Every step](#every-step) allows: never code or tests, and never an expected value of your own. Your step is `plan-review`, `Mx review` or `final-review`.

## Work out your job

The invocation gives the slug and the target: `plan`, a milestone such as `M2`, or `final`. The review file is `review-plan.md`, `review-Mx.md` or `review-final.md`.

1. **The user gave a decision** (for example "allow one more round on M2"): record it, then carry on.
2. **Preconditions.** Stop and tell the user if: `plan` has no committed `plan.md`; a milestone has no `Accepted:` plan version, or `handoff-Mx.md` has no "Build" section; `final` has a milestone that isn't `accepted` in Progress (list them).
3. **Choose the job from the review file:**
   - **No review file:** a [first review](#first-review). For `plan`, read `plan-review.md` in this skill's folder in full now.
   - **Last section is a HAND OFF round:** if you wrote it in this session, stop and tell the user to open a new one. Otherwise do a first review of the whole target, labelled `(fresh)`, with the same bar for [what counts as a finding](#what-counts-as-a-finding); for `plan`, read `plan-review.md` in full now. Look again at the reasons for every WITHDRAWN finding, and reopen one only if they don't hold up. Don't reopen a DEFERRED or DOWNGRADED one without new evidence.
   - **Last section is an author's response:** a recheck: read `recheck.md` in this skill's folder in full now, and follow it.
   - **Last section is a milestone round with `Verdict: pending`:** a review session stopped after pass 1. Complete that round from pass 2 (finishing it isn't editing an earlier round), if you're a different session from pass 1's, add yours to its header as `pass 2: "<session name>" (<vendor> <model>)`, and end with Finish; your log row names your session, with `, same vendor` if either pass ran on the builder's vendor. If the round has gone stale ([What a review covers](#what-a-review-covers)) or Mx's Progress has since become `reopened` or `accepted`, its verdict is REVIEW INCOMPLETE; when it was reopened or accepted, the baton is the Next of the last `log.md` row before yours.
   - **Last section is a REVIEW INCOMPLETE round:** once the blocker is fixed, redo the same kind of round at the current `HEAD`: a first or fresh review as above, or a recheck (read `recheck.md` in full now). If the blocker isn't fixed, print the baton again (a moved target or a new plan version needs no fix: redo the round). Check this before staleness, since such a round is usually stale too.
   - **Last section is any other reviewer round, with no response after it:** a recheck without a response (read `recheck.md` in full now) if the round is stale ([What a review covers](#what-a-review-covers)); otherwise print the baton again.

**Pin the target.** Note `HEAD` and check the tree is clean, apart from files you adopted under [Every step](#every-step), Start 3. If either changes while you work (apart from your own breaks, comparison runs, `runs/` files, the review file you're writing, and a records commit of those an output comparison needs), the verdict is REVIEW INCOMPLETE.

## What a review covers

A round covers the code and tests at its `Reviewed:` head, and the plan version it names (if it names none, the `Version:` line of `plan.md` at that head: `git show <head>:<path to plan.md>`). Later commits that are records-only leave it valid. Any other change, or a new plan version, makes it stale, and it must be reviewed again before a gate relies on it. To check, run `git diff --name-only <reviewed head> HEAD` and compare the plan's `Version:` line.

- **Records-only:** every file that diff lists is in the feature folder, or is a documentation file outside it that nothing reads: Markdown, reST or plain text, not under a test or test-data folder, and read by no command in Checks (a docs build, a doctest) and no code, test or build configuration (grep the repository for its name; a README named in `pyproject.toml` counts as read). Code, tests, configuration, dependencies and data are never records. If you can't tell, name the file to the user and ask.
- **Cite a saved run instead of rerunning** when its commit differs from `HEAD` only by a records-only change and its commands are still the ones in Checks. Open the file and check its commit, commands and result yourself; never take a summary's word for them. If one exists and you run the full checks anyway, give the reason in your round: the file that isn't a record, the changed command, or the missing or incomplete file. The final review and its recheck always run their own.

## First review

Write it with `review-template.md` in this skill's folder. For `plan`, follow `plan-review.md`; for a milestone or `final`, the sections below.

### How to judge any target

*Adapted from the Superpowers code-reviewer prompt (MIT; see the README).*

- **The plan is a vision, not a list of every case.** It says what must work; it doesn't name every input, state or condition the code will meet. Where it's silent, judge by what a reasonable user of this software would expect: that expectation is a requirement, and the plan's silence isn't permission. Grade such a finding by its effect on that user.
- **Follow each changed path through the states a user can reach,** not only the ones the ACs name: errors, conflicts, invalid input, empty or unavailable values, a retry, coming back to a page or rerunning a job. Ask what the user sees, or what number comes out, in each. For invalid input, an error that names the problem is a good outcome, not a defect.
- **Money and data:** look for wrong numbers that pass quietly: signs, units and scale, rounding, currencies, time zones, as-of dates, fiscal vs calendar periods, trading calendars, off-by-one windows, look-ahead, join keys, running twice, missing or empty inputs, totals that should reconcile.
- **Declined to judge.** List every behaviour you considered and set aside as outside the plan, one line each, with the reason. Set aside only what a reasonable user wouldn't rely on; anything they would expect is judged as a finding, suspected if you're unsure.

### A milestone

Two passes, in this order. Pass 1 is the review; pass 2 confirms its evidence. Don't run the full checks, the `Compare:` line or any other long chain during pass 1, not even in the background. Once pass 1 is complete, write its findings into the review file as the round, with `Verdict: pending`, before you start pass 2: a pending round means pass 1 finished. Pass 2 completes that round.

**Pass 1: judge the change.** Run a single test or a short probe only to confirm a suspicion.

1. **Read the plan:** the milestone's block, its ACs and worked examples, the interface, the facts, the Decision log, Surprises and deviations, and `requirement.md` for those ACs.
2. **Read the diffs** from the ranges in `log.md`, the acceptance-test commit and the build separately, and the code around each change: its callers, and the state it depends on.
3. **Judge it as above.** For each changed function, handler or page, write down the states it can be in, and what the user sees or what number comes out in each, before you decide it's fine. Then check:
   - **The code against the plan:** its integration with callers, regressions, and the error paths the plan names. Don't ask for validation the plan doesn't name, of input that would raise anyway.
   - **Hidden failures** in the diff: a catch-all `except` that logs, returns a default or carries on, a fill or default for a value that would otherwise raise (`fillna(0)`, `dict.get(k, 0)`, `or 0`), coercing bad values to NaN or None, dropping rows with a missing key, a retry that gives up quietly. Each is a finding unless the plan asks for it: P1 on a money or data path with a realistic input, P2 otherwise or when no realistic input reaches it. The fix deletes or narrows the handling so the input raises; in pandas a NaN left in place can still give a quiet total (`sum` skips NaN), so then the fix raises where the data enters. Handling the diff only moves or renames goes under "Found outside this change". Catching an error to exit with a message, or to raise a clearer one, is fine.
   - **Simplicity:** every changed line traces to the plan or to behaviour it requires, reasonable-user expectations included. Unneeded complexity is what nothing uses or needs: an option, mode, layer or helper nothing uses, a repeated check, dead code.
   - **The AC trace:** every AC has an acceptance test through the public interface; worked examples are copied exactly; every expected value has a source, none obtained by running the code. On an `independent` milestone, `git diff <tests commit> HEAD -- <acceptance test files>` is empty apart from commits naming the decision (an `ESC-n` or one on the plan's `Accepted:` line) or TD ruling that states that change.
   - **Bad tests** among those this milestone adds or changes: assertions that can't fail (they check what the test just set, or compute the expected value the way the code does) or only check a status, type, `not None` or length; disabled assertions; skips, xfails or focused tests; sleeps; mocks of the unit under test; tolerances wider than the plan justifies; dependence on order, the clock or the network; anything unsafe in parallel (`dev-test`'s "Write the tests", step 5; P2 if the full checks run in parallel, otherwise P3).
   - **Scope:** deviations are small and logged in `plan.md`, and nothing beyond the milestone was built.
4. **Read the handoff last,** and compare its claims with what you found. It states the plan version, the commit range, the test command and its result, what's open, and the next action. With it, check:
   - **Test changes:** every acceptance-test change and weakened test the handoff lists, and any in the diff it doesn't list (on a `builder` milestone, every later change to the acceptance tests must be listed).
   - **TEST DISPUTES** the handoff records, ruled from the plan: if the plan shows the test is wrong, quote it and state the corrected expectation exactly, for the builder to apply; if it shows the code is wrong, raise a finding; if it doesn't settle it, raise an `ESC-n`.

**Pass 2: confirm the evidence.** Keep it short; a result here that contradicts pass 1 updates the finding.

- **The checks:** cite the builder's saved full run ([What a review covers](#what-a-review-covers)): its commit is the code you're reviewing, it ran the plan's full checks, and its result matches the handoff, or that's a P1. With no usable run, run them yourself. On an `M0`, rerun enough of the experiment to confirm its findings.
- **The kill check, on `independent` milestones:** pick 3 ACs (every AC when there are 3 or fewer), those whose tests guard the riskiest changed code (money and data paths first, then the states you judged in pass 1). For each, break the code once (flip a sign, shift a window by one, drop part of a key, swap units), run that AC's tests, and confirm one fails. Record each break in the AC trace, and `—` for the ACs you didn't break. An uncaught break is P1.
- **The output comparison**, on a milestone with a `Compare:` line (`compare.md` in the `dev-build` skill's folder, next to this one; read it in full now): check the builder's comparison file like a cited run (right base, only tests and records changed since, not the `Compare:` input, and the input and command now in force), or run it yourself (if that switch needs the review file committed, its `<slug> Mx review: records` commit is fine). Every difference that neither an AC nor the Decision log names is P1. Then, after your full run, run the command at `HEAD`, break the changed code once, run it again into another folder, and confirm the outputs differ; if they don't, the input doesn't test the change (P2 against the `Compare:` line).
- **Other evidence the handoff claims** but the repository doesn't hold (spreadsheet checks, screenshots, files in ignored folders; not the saved full run, which "The checks" covers): don't rebuild it. List it under "Not checked", where the user sees it at the gate.
- **Breaking code safely** (kill checks, `Compare:` break runs, recheck checkouts): let your own full run finish first. Edit in place, restore with `git checkout HEAD -- <file>`, never commit a break, and confirm `git status --porcelain` shows only your `runs/` files and the review file before you write on. A changed production file left by an interrupted review is restored the same way once the user confirms it.

### The whole branch (`final`)

Read `requirement.md`, `plan.md` and the whole diff from the plan's `Branch:` base to `HEAD` (commits outside every `dev-test` or `dev-build` range in `log.md`, merged in or committed directly, are judged only for how they fit this plan; their own review covers them), run the full checks yourself (never cite a run here), and only then read the handoffs and earlier reviews. Judge it as above, and check that every AC is met by passing tests, the milestones agree across their boundaries (interfaces, units, dates, IDs), no TODOs, debug or dead code are left, and deferred findings are still recorded. Where you can, run one normal and one failure case end to end, and write the commands into the review for the user's gate 3.

## Findings

Each finding has an ID `F<n>` (numbered across the file), a priority, demonstrated or suspected, a location, the trigger and its consequence, the evidence, and the smallest coherent fix: what removes the trigger, including the callers, tests or plan lines it directly affects, and nothing else. On a milestone or `final`, if a P0–P2 fix needs a plan change the builder may not make (the plan forbids it, or it would change an AC, an interface, the design or another milestone), say so in the smallest fix and give the options with your recommendation: the builder escalates it. Until the builder escalates it, such a finding is open, so the verdict is CHANGES REQUIRED; a recheck then marks it ESCALATED (`recheck.md`, step 2). Don't raise an `ESC-n` for it yourself, unless the round budget is used up (`recheck.md`, step 5).

| Priority | Meaning | Blocks? |
|---|---|---|
| P0 | Wrong money or data, data loss, or it can't run, all demonstrated | Yes |
| P1 | An AC unmet, or a likely wrong result on a realistic input | Yes |
| P2 | A real defect with limited impact and a concrete trigger; an untested money or data risk that would fail quietly (name the trigger and the missing evidence); or unneeded complexity, fixed by deleting it | Fix it, unless the user defers it |
| P3 | A note: optional, at most 3 per review; nobody has to answer it, and rechecks don't track it | No |

An unmet AC blocks whatever its priority. A review with zero findings is valid.

### What counts as a finding

Before you write a P0–P2, answer: *if this isn't fixed, what goes wrong, on what realistic input or state?* The answer must be a concrete failure: a wrong number or damaged data; a crash, hang or exposure on input that must work; a user misled about what they're looking at; an unmet AC; a deliberate break no acceptance test catches; a hidden failure; unneeded complexity in the diff, including a builder's implementation test whose proof another test repeats (name a break that fails both), but never an acceptance test; or, on a plan, a builder following it as written would build the wrong thing or be stuck. A suspected finding names the mechanism and the missing evidence. If you can't name a consequence, it's P3 at most. A regression (behaviour that worked before this change and is broken after it, in a state a user can reach) is at least P2, even if nothing is lost: the user would have to work around something that used to work. A change the plan, an AC or the Decision log asks for isn't a regression, nor is one on input the requirement excludes.

P3 at most, unless they cause one of those: wording, naming and formatting (a wrong unit or sign label does cause one); a different design or style when the current one works, anything whose fix isn't a deletion; inputs the requirement excludes or that can't realistically arrive; a missing guard for input that already fails loudly or only comes from the user's own code, config or hand-written files (data from outside, such as broker statements, vendor files or filings, never counts as the user's own, even when saved locally; an exception on bad input is the intended behaviour, not a crash); more tests when every break you tried was caught; a plan ambiguity whose readings give the same result.

**Found outside this change.** A defect in code the target doesn't change isn't a finding unless the change makes it worse, starts relying on it, or it stops an AC being met. Otherwise, if it would be P0–P2, note it in one line under "Found outside this change" (where, trigger, consequence). It blocks nothing; the user sees the list at gate 3. On a plan, the same goes for problems in existing code the plan doesn't touch.

## Verdict

| Verdict | When |
|---|---|
| READY | No open P0 or P1; no open P2 unless deferred; every AC met; the checks pass apart from known baseline failures; no open dispute or escalation, and no decided one left unapplied. It means safe to go on, not perfect and not accepted. |
| CHANGES REQUIRED | The author has something to do |
| NEEDS OWNER DECISION | Only the user's decisions block it, or the round budget ran out with items open |
| REVIEW INCOMPLETE | The tree wasn't clean, the target moved, or the checks couldn't run |
| HAND OFF | Rechecks only: a fresh reviewer takes over |

The user can defer a P2, but not a P0 or P1 into READY: a P0 or P1 they choose to live with is DEFERRED and the verdict stays NEEDS OWNER DECISION, though they can still accept the milestone over it at the gate, with a reason.

## READY on a milestone: triage for the user

On a READY milestone round, add "For the user", sorting everything the rounds record into three tiers. Anything the plan or Decision log already approved goes in tier 3, with its reference.

1. **Needs your call:** an open escalation; a TEST DISPUTE ruling that changed the test author's expected value; a money or data finding that was WITHDRAWN or DEFERRED; an acceptance-test change or weakened test that neither the plan, the Decision log nor a VERIFIED finding names. One or two sentences each: what happened, the risk, the question.
2. **Worth a glance:** at most 3 one-liners the user didn't approve but probably won't mind (deviations, files outside the milestone's list, a same-vendor review, your calls that matter), each ending with its cost if wrong. Add every item under "Not checked" too, one line each, outside that limit: the user must learn which claimed evidence nobody verified.
3. **Matches the plan:** one line: the AC trace, the checks, the output comparison if any, and the planned changes with their plan references.

**Auto-accept** when the milestone is `Tests: builder`, tier 1 is empty, every AC was checked and nothing under "Not checked" touches one, any `Compare:` line has a comparison you checked at this production code, with the input and command now in use, showing no unnamed difference, and a review of this milestone did the break run with that input and command, and the Decision log has no `stop at Mx` or `stop at every gate` for it. Then set Progress to `accepted <date> (auto)` and write `Auto-accepted: yes`; otherwise set it to `READY` and write `Auto-accepted: no, because <reason>`. `Tests: independent` milestones always stop at gate 2, even if you were told to make calls yourself: the user reads the acceptance test names there.

Apart from Progress and the user's decisions, you don't change the plan.

## Finish

Follow [Every step](#every-step), and:

1. Append your round to the review file; never edit earlier ones. It's records: one commit `<slug> <target>: review r<N>` (or `recheck r<N>`) holds it, your log row, any Progress change and your `runs/` files (after any records commit an output comparison needed).
2. Reply with the verdict, the counts per priority or status, the test result, and every WITHDRAWN, DOWNGRADED or ESCALATED item with its reason.
3. The baton:

   | Verdict | Next |
   |---|---|
   | CHANGES REQUIRED | The author's session, as its last `log.md` row names it (for `final`, a new `<slug> final-fix` if there's none yet), with `dev-plan <slug>` or `dev-build <slug> <target>` |
   | NEEDS OWNER DECISION | The ESC IDs to decide, and where: the author's session, then its `dev-plan` or `dev-build` line |
   | READY, plan | Gate 1: what to read, as `dev-status`'s gate 1 view lists it; then type `approve the plan` in the `<slug> plan` session |
   | READY, milestone, auto-accepted | `Mx auto-accepted`, its "Worth a glance" lines, and that a problem found in it later is new work, done on `work/<slug>` between milestones or at gate 3. Then the baton `dev-status` gives after `accept Mx` |
   | READY, milestone, not auto-accepted | Gate 2 here, so the user needn't run `dev-status`: `dev-status`'s gate 2 view. When they type `accept Mx`, record it as `dev-status` does, baton included |
   | READY, final | Gate 3 here: `dev-status`'s gate 3 view. When they type `accept the feature`, record it as `dev-status` does |
   | HAND OFF | The same `dev-review` line, in a new session |
   | REVIEW INCOMPLETE | What blocked it, and the same line once it's fixed |

## Every step

*This section is the same in all five `dev-*` skills. Change all five together.*

### Start

1. **Read the invocation.** It gives the feature slug, then the target if this skill takes one (`plan`, `M2`, `final`). Anything after that is the user's: a requirement, a decision, or extra focus. The feature's files are in `docs/work/<slug>/`, unless the project's instructions name another place. Follow those instructions (`AGENTS.md`, `CLAUDE.md`, a README) where they exist, but never require them.
2. **The checks** are the commands in the Checks section of `plan.md`, which `dev-plan` writes. If one won't run on this machine (it's missing, not failing), stop and ask the user.
3. **Check git.** The project must be a git repository.
   - Work on branch `work/<slug>`. Only `dev-plan` creates it. If you're on another branch and the tree is clean, switch to it. If `HEAD` is detached, an output comparison stopped partway or is still running in another session: ask the user, and switch back to `work/<slug>` once they confirm nothing is running (`dev-status` only reports it).
   - Run `git status --porcelain`. If it lists changes you didn't make in this session, never stash, commit or discard them (`dev-status` only reports them, apart from an interrupted decision of its own). If they look like an interrupted run of your own step (the files your step writes, for the same target, and no committed `log.md` row for that run; an uncommitted row of your step is part of it), show the user `git status` and a short summary of the diff, and ask whether to carry on from them. If they agree, adopt them, say so under "Calls I made", carry on from where the run stopped, and end with Finish; an adopted log row is that run's row. If they don't, stop. If the changes don't look like that, stop, and tell the user which step the changes seem to come from: rerunning it offers to carry on from them, or the user can commit or discard them.
4. **Read `log.md`** in the feature folder, if it exists. Its last row is where things stand. If commits from your step come after it, a previous session stopped partway: carry on from them, without redoing what they hold, and end with Finish.
5. **Name the session**, if nothing else has been done in it yet, from the table below. If you have a tool that renames the current session (in the Claude desktop app, `set_session_title` with session id `self`), use it, then file the session under the sidebar group `<slug>` (list the groups first; create it only if it's missing). Otherwise the user names it.

| Step | Session name |
|---|---|
| `dev-plan` | `<slug> plan` |
| `dev-review plan` | `<slug> plan-review` |
| `dev-test Mx` | `<slug> Mx test` |
| `dev-build Mx` | `<slug> Mx build` |
| `dev-review Mx` | `<slug> Mx review` |
| `dev-review final` | `<slug> final-review` |
| `dev-build final` | `<slug> final-fix` |
| `dev-status` | `<slug> status` |

### While you work

- **One role.** Subagents may help with your own work, such as searching the code. Never start another role, as a subagent or by messaging another session: each role starts from a line the user pastes.
- **The user's decisions** come in the invocation or are typed later: "approve the plan", "ESC-2: option B", "accept M2", "defer F4 to M3", "allow one more round on M2". Record each one straight away, unless the Decision log already has it (a restart):
  - add `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")` to the Decision log in `plan.md`. Approving the plan, or accepting a milestone or the feature, also changes `Accepted:` or Progress, as `dev-plan`'s "Gate 1" and `dev-status`'s "Decisions" say;
  - mention it in your next `log.md` row, and commit it with your step. If your step has already finished, or stops before Finish, add a row with step `decision`, and commit it with the decision straight away, as `<slug>: decision <ref>` or the message your role gives for it (such as `<slug> Mx: accepted`).

  Then act on it only as far as your role allows.
- **Escalations.** Their IDs run `ESC-1`, `ESC-2`, … across the whole feature: take the number after the highest `ESC-` anywhere in the feature folder. Each states the question, the options and your recommendation, and stays open until the Decision log has an entry for it.
- **Your own calls.** Every choice you make that the user didn't (one reading of an ambiguity, a small deviation from the plan) goes under "Calls I made" in your handoff, response or review.
- **Quick and full checks.** The *full checks* are every command in Checks; the *quick checks* are the test files that cover what you changed, plus the quick command in Checks if it names one. Work with quick checks. A gate always rests on a full run, run or cited. When your role runs the full checks, run them once, after your last change to code or tests, and save them: redirect each command's output straight into `runs/<YYYY-MM-DD-HHMM>-<step>-<short hash>.txt` in the feature folder as it runs (`<command> > <file> 2>&1`, then `>>`; in Windows PowerShell, inside `cmd /c "..."`), so a lost capture never costs a second run. Then add a header at the top: the commit, each command, how long it took and its result. If the output is very long, keep its summary and every failure. Name the file in your handoff, response or review, and in your `log.md` row.

### Finish

1. **Commit your work** with the message your role gives, before you run the full checks, so that a saved run names a commit holding exactly what was tested. If a check fails and you fix something, commit again and rerun. Never push, amend, rebase or merge.
2. **Log.** Append one row to `log.md`. If the file is missing, create it with the heading `# Log: <slug>` and this table header:

   ```
   | When | Session | Step | Result | Next |
   |---|---|---|---|---|
   ```

   - **When:** local time, as `YYYY-MM-DD HH:MM`.
   - **Session:** `<session name> (<vendor> <model>)`, for example `csv-import M2 review (Claude Opus 5.5)`. Your vendor is Claude in Claude Code and Codex in Codex. Add `, same vendor` when a check ran on the same vendor as the work it checks: plan-review against plan, Mx review against Mx build, final-review against the vendor that built most milestones, and Mx test against Mx build (the builder adds it).
   - **Step:** the skill and target, for example `dev-review M2` or `dev-build M2 (answers r1)`.
   - **Result:** the commit or range, the test result, the verdict, counts, and any new ESC IDs.
   - **Next:** the paste line or lines from your baton.
3. **Commit the records** (handoff, review, `plan.md`, your `runs/` files) with your log row, as `<slug> <step>: records`. When your step writes only records, that's its one commit. Then `git status --porcelain` must be empty, because the next step stops on a dirty tree: commit anything your step wrote in the feature folder, and restore any break of your own. Never commit anything else here: name it to the user, and say the tree isn't clean.
4. **Reply** in at most 8 lines, then end with the baton:

   ```
   Done: <slug> <step>. <commit, tests, verdict, what's open>.
   Next: <what>, in <a new session | the "<session name>" session> (<vendor>: <why>). Paste:
     <line or lines>
   ```

   | The next session is | Claude | Codex |
   |---|---|---|
   | New | `/dev-x <args>`. In a terminal: `claude -n "<session name>" "/dev-x <args>"` | `/rename <session name>`, then `$dev-x <args>` |
   | Already open | `/dev-x <args>` | `$dev-x <args>` |

   **Which vendor.** For a check (plan-review, Mx test, Mx review, final-review), suggest the vendor that didn't write what it checks, from `log.md`, "or a fresh `<same vendor>` session if `<other vendor>` has no capacity"; for Mx test, "the vendor that won't build Mx". For a writing step, the vendor the user last used for that kind of step. When the next step is the user's (a gate, or an escalation), say what to read or decide, and what to type in which session.
