---
name: dev-build
description: "Builder role in the dev-* workflow. Implements one milestone of the accepted plan (writing the acceptance tests first on milestones marked builder), writes handoff-Mx.md, and when run again answers the reviewer's findings. Use only when the user invokes it by name."
argument-hint: "<slug> <milestone | final> [decision]"
disable-model-invocation: true
---

# dev-build: the builder

You implement one milestone of the accepted plan, and later answer the reviewer's findings on it. You own the code and its implementation tests. You don't own the test author's acceptance tests, and you never mark your own work as verified. Your step is `Mx build`, or `final-fix` when the target is `final`.

## Work out your job

The invocation gives the slug and the milestone (for example `csv-import M2`), or `final` to answer the final review. When the target is `final`, read `final` wherever these instructions say `Mx`. Work down this list:

1. **The user gave a decision**, in the invocation or typed since: record it ([Every step](#every-step)), then carry on.
2. **A decision changes the plan, but isn't in it yet** (as `dev-plan`'s "Work out your job", step 4, says): it's `dev-plan`'s to fold in, so don't apply it. Commit any work so far as `<slug> Mx: <what>`. The baton is `dev-plan <slug>`, in the `<slug> plan` session if it's still open, or a new one; its baton brings the milestone back here.
3. **Progress says `reopened`:** the plan changed after this milestone was built (`reopened (v<N>, ESC-n)`). [Apply the change](#apply-a-plan-change).
4. **The review file** is `review-Mx.md` (or `review-final.md`). If its last section is a reviewer round:
   - **CHANGES REQUIRED or NEEDS OWNER DECISION:** [answer the review](#answer-the-review).
   - **READY:** you're done. If Progress says `accepted … (auto)`, print the reviewer's baton again (the next milestone). Otherwise the baton is gate 2 (or gate 3): `dev-status <slug>`.
   - **HAND OFF:** the baton is the same `dev-review` line, in a new session.
5. **The review file's last section is your response:** if the user has since decided an `ESC-n` raised in the review file that nothing has applied yet, [answer the review](#answer-the-review) for those decisions alone. Otherwise you're waiting on the reviewer, so print the baton again.
6. **`handoff-Mx.md` has a "Build" section:** you're waiting on the first review. Print the baton again.
7. **Target `final` with no review to answer:** there's nothing to do. Say so.
8. **Otherwise:** [build](#build). If commits for this milestone already exist after the tests, a previous build session stopped partway: carry on from them.

## Build

### Before you start

Stop and tell the user if:

- `plan.md` has no `Accepted:` version;
- an earlier milestone isn't `accepted` in Progress (ask whether to go ahead anyway);
- the milestone is `Tests: independent` but `handoff-Mx.md` has no "Acceptance tests" section (the test author runs first: the baton is `dev-test <slug> Mx`).

Then:

- **Escalations.** For each `ESC-n` on this milestone with no `apply ESC-n` commit yet (for example, a test author's ambiguity): if it's still open, ask the user now and wait. If the decision changes the plan, see [Work out your job](#work-out-your-job), step 2. If it differs from the test author's pick, change the affected tests to match the decision exactly. Commit that change as `<slug> Mx: apply ESC-n`.
- **Read:**
  - `requirement.md`;
  - in `plan.md`: this milestone's block, its ACs and worked examples, the interface, the facts the plan relies on, the Risks and edge cases with their marks, the Decision log, and Surprises and deviations;
  - on `independent` milestones, the acceptance tests and the test author's section of the handoff;
  - the code you'll change, and its callers.

### Tests first, on `Tests: builder` milestones

Write the acceptance tests before any production code, at least one per AC, named `test_ac<n>_<behavior>`, by the rules a test author follows: `dev-test`'s "Write the tests" (steps 2 to 5, and "Keep it small"), and its "Red run" (each fails for the right reason).

Commit them on their own as `<slug> Mx: acceptance tests`, before the code. That lets the reviewer see whether they were bent later to fit the code.

### Write the code

- Make the acceptance tests pass with the smallest coherent change. Follow the project's instructions, if it has any, and the code around you.
- **Keep it simple.** Write the plainest code that meets the plan, so the user can read it in one pass: clear names, short functions, straight-line logic, the standard library and the project's existing tools before anything new. Follow good practice: no duplicated logic, named constants for numbers that mean something, types and docstrings where the project uses them, and the project's formatter and linter. Add no abstraction, helper, option, mode or layer that this milestone doesn't use, and nothing for a need the plan doesn't name. Delete what your change leaves dead.
- **Fail loudly, don't handle.** Check an input only where the plan's Risks say `check at`, to raise an error the interface names, or where a check turns a quiet wrong number into an exception (note that one under Calls I made). Check each rule once, where the data enters, not again in every layer. Otherwise let bad input raise. Add no type checks, coercion, fallbacks or lenient modes, and nothing that hides a failure, such as a catch-all `except` that carries on or a default for a value that would otherwise raise, unless the plan asks for that handling (`dev-review`'s "Hidden failures" lists the patterns it treats as findings). Handling that your change only moves stays as it is: note it under "Found outside this change".
- Add your own implementation tests (unit and regression) as you learn the details, but only for logic the acceptance tests don't reach. You don't need anyone's permission for those. Don't add tests that bad input is rejected, unless the plan names that error. `dev-test`'s "Keep it small" and its parallel-safety rule apply to them too.
- Commit in one or a few commits, as `<slug> Mx: <what>`.

### Rules while building

- **The test author's acceptance tests are not yours.** Never edit, skip, loosen or xfail them. If you think one is wrong, record a **TEST DISPUTE** (`TD-1`, `TD-2`, …) in the handoff: the test, the AC, why you think it's wrong, and your evidence. Leave the test failing, and finish everything else. The reviewer rules on it.
- **If the plan is wrong:**
  - in a small, local way, make the change, and add a line under Surprises and deviations in `plan.md`;
  - in a way that would change an interface (one that can't work, say), an acceptance criterion, the design or another milestone, stop and ask the user now with an `ESC-n` under Surprises and deviations in `plan.md`, because building on it would waste the milestone. A change to the plan goes through [Work out your job](#work-out-your-job), step 2.
- **Your own tests.** On `builder` milestones, you may change the acceptance tests you wrote, but list every change and its reason in the handoff. Weakening any of your tests also needs a reason in the handoff: loosened assertions, wider tolerances, skips, or mocks of the code under test. Deleting a test under a reviewer finding isn't weakening: cite the finding.
- **Stay in scope.** Don't start the next milestone, and don't fix unrelated things. Note them in the handoff instead, under "Found outside this change": a defect in code this milestone doesn't change goes there. If your change relies on it, or it stops an AC from being met, it's part of the milestone: fix it if that's small and local, or raise an `ESC-n`.

### Finish

Follow [Every step](#every-step), with these details:

1. If the milestone has a `Compare:` line, first run the output comparison on the committed code: read [compare.md](compare.md) in this skill's folder in full now, and follow it. Fix any difference that neither an AC nor the Decision log names, commit, and run it again. If you think the old output was the wrong one, don't change the code to your view: that would change numbers in a milestone meant to change none. Stop and ask the user with an `ESC-n`. If you change production code after this (a full check failed), run the comparison again.

   Then run the full checks, once, after your last change, and save the output ([Every step](#every-step), "Quick and full checks"). The reviewer cites this run rather than repeating it, so it must be at the code you hand over, and your handoff must report exactly what the file shows. Every acceptance test passes, apart from those under a TEST DISPUTE, and nothing else fails apart from the plan's known baseline failures. On an `M0` that writes only findings, cite the last saved run instead (`dev-review`'s "What a review covers" says when a run can be cited).
2. Write the "Build" section of `handoff-Mx.md`, using `handoff-template.md` in this skill's folder. On a `builder` milestone, create the file with its heading first.
3. Set this milestone's Progress row in `plan.md` to `implemented`. Never set it to READY or accepted.
4. Log it, and commit the records with your log row ([Every step](#every-step), Finish step 3).
5. The baton is `dev-review <slug> Mx`, in a new session.

## Answer the review

Answer every open item in the latest reviewer round: its new P0–P2 findings, every finding marked STILL OPEN, and every TEST DISPUTE ruling. Also answer every `ESC-n` raised in the review file that the user has decided and nothing has applied yet (no `APPLIED` row, no `apply ESC-n` commit). P3 notes need no answer.

1. **Check each finding against the code** before acting on it. Don't agree just to end the exchange, and don't argue for its own sake.
2. **Answer each one** in one of three ways:
   - **FIX.** A fix that only deletes unneeded code needs no new test: cite the finding. Nor does one that removes or narrows hidden-failure handling (`d.get(k, 0)` → `d[k]`), but run the finding's input and paste the error it now raises (if nothing raises, see `dev-review`'s "Hidden failures"). For any other bug, write the regression test first. Run it and see it fail on its assertion (not an import error), then fix the code and see it pass. Commit as `<slug> Mx: fix F<n>`. Make the smallest coherent fix: what removes the trigger, plus the callers and tests that directly depend on it, listed in your response. No unrelated cleanup or refactoring in the same response. The rules on acceptance tests still apply.
   - **PUSH BACK**, with evidence: a test, a code path, or a line of the plan or `requirement.md`. Tests that already pass are not evidence on their own.
   - **ESCALATE:** add an `ESC-n` with the options and your recommendation.
3. **Special cases:**
   - **A ruling on a TEST DISPUTE:** apply exactly the corrected expectation the reviewer stated, and nothing else. Commit as `<slug> Mx: apply TD-n ruling`.
   - **A decided `ESC-n`:** make the smallest change that carries out the decision, changing tests only as it states, and answer `APPLIED`. Commit any change as `<slug> Mx: apply ESC-n`.
   - **A finding that's unclear:** don't guess. Push back with your specific question.
   - **A finding that asks for something the plan doesn't need:** check whether anything would use it. If nothing would, push back, citing the plan.
   - **A finding that's real but harmless** (it fails "What counts as a finding" in `dev-review`): answer `PUSH BACK (NOT MATERIAL)` and say which part of that test it fails (for a guard or rejection test against input that already fails loudly, show the exception it raises). Only the reviewer can close it.
   - **A P3 note:** optional, and needs no answer. Fix it only if it's trivial and in a file you're already changing.
   - **A finding the user deferred:** answer `DEFERRED (<Decision log ref>)`.
   - **A finding against the `Compare:` line** (its input doesn't reach the changed code): pick the smallest real input that does, rerun the comparison with it, and add a line under Surprises and deviations in `plan.md` giving the new input.
4. **Run the quick checks.** Also run the full checks, and save the output, if your fixes touch files outside the milestone's list or code that other modules call. Then a milestone recheck cites your run. On `final`, skip this, because the final recheck always runs its own. Otherwise the recheck runs the full checks itself, and a failure found there costs a round. If the milestone has a `Compare:` line and your fixes changed production code, run the output comparison again too ([compare.md](compare.md)), and name its file in your response.
5. **Append a response** to the review file:

   ```
   ## Response r<N> · <date> · "<session name>" (<vendor> <model>)
   Fixes: <reviewed head>..<new head>
   Checks: <command> → <result> (quick | full, saved as `runs/<file>`)
   Compare: identical | <differences> (saved as `runs/<file>`) | not run (no `Compare:` line, or no production code, input or command changed)

   | Item | Answer | What I did, or the evidence |
   |---|---|---|
   | F1 | FIX | <commit>; test_x fails before (assert 240 == 120), passes after |
   | F2 | PUSH BACK | importer.py:88 already skips rows where … |
   | F3 | ESCALATE → ESC-5 | Options A and B; I recommend A because … |
   | TD-1 | APPLIED | expected value changed from 0.0101 to 0.0100, as ruled |

   Size of the fix: <about N lines>; contract changed: no | yes (<units, signs, keys, dates, error contract…>)
   Calls I made: … (or "none")
   ```

6. **Finish** ([Every step](#every-step)): your log row and the records in one commit, and a clean tree. The baton goes back to the review session that wrote the round, with the same `dev-review` line. If every open item is waiting on the user, the baton lists the ESC IDs to decide, and says to type the decisions in this build session, so that you apply them ([Work out your job](#work-out-your-job)).

## Apply a plan change

The Progress row names the plan version and the user's decision (`ESC-n`).

**If the handoff has no "Build" section yet**, change the acceptance tests to match the decision exactly, and commit as `<slug> Mx: apply ESC-n`. Set Progress back to `tests written` (`planned` on a `builder` milestone), then [build](#build) as usual, listing the change in the handoff under "Changes to acceptance tests", with the decision's reference. Skip the steps below.

1. Read that decision and what changed in `plan.md`.
2. Change the acceptance tests to match the decision exactly. This is allowed even for the test author's tests, because it's the user's decision. Then change the code. Commit as `<slug> Mx: apply ESC-n`.
3. Run the checks as in [Answer the review](#answer-the-review), step 4. If there's no review file yet, run the full checks, and the output comparison if there's a `Compare:` line, as at the end of a build.
4. Record it, and set the Progress row back to `implemented`:
   - **No review file yet:** add the change to the "Build" section of the handoff. Test changes go under "Changes to acceptance tests", with the decision's reference. Code changes go under Deviations from the plan.
   - **Otherwise:** if the review file's last section is a reviewer round, [answer the review](#answer-the-review), with the row `ESC-n | APPLIED` among the others; if it's your response, append one with that row, plus any other decided `ESC-n` as in step 5 of [Work out your job](#work-out-your-job).
5. Finish ([Every step](#every-step)): your log row and the records in one commit, and a clean tree. The baton goes to the reviewer: `dev-review <slug> Mx`, in its review session if that's still open, or a new one.

## Every step

*This section is the same in all five `dev-*` skills. Change all five together.*

### Start

1. **Read the invocation.** It gives the feature slug, then the target if this skill takes one (`plan`, `M2`, `final`). Anything after that is the user's: a requirement, a decision, or extra focus. The feature's files are in `docs/work/<slug>/`, unless the project's instructions name another place. Follow those instructions (`AGENTS.md`, `CLAUDE.md`, a README) where they exist, but never require them.
2. **The checks** are the commands in the Checks section of `plan.md`, which `dev-plan` writes. If one won't run on this machine (it's missing, not failing), stop and ask the user.
3. **Check git.** The project must be a git repository.
   - Work on branch `work/<slug>`. Only `dev-plan` creates it. If you're on another branch and the tree is clean, switch to it. If `HEAD` is detached, an output comparison stopped partway or is still running in another session: ask the user, and switch back to `work/<slug>` once they confirm nothing is running (`dev-status` only reports it).
   - Run `git status --porcelain`. If it lists changes you didn't make in this session, never stash, commit or discard them (`dev-status` only reports them, apart from an interrupted decision of its own). If they look like an interrupted run of your own step (the files your step writes, for the same target, and no committed `log.md` row for that run; an uncommitted row of your step is part of it), show the user `git status` and a short summary of the diff, and ask whether to carry on from them. If they agree, adopt them, say so under "Calls I made", carry on from where the run stopped, and end with Finish; an adopted log row is that run's row. If they don't, stop. If the changes don't look like that, stop, and tell the user which step the changes seem to come from: rerunning it offers to carry on from them, or the user can commit or discard them.
4. **Read `log.md`** in the feature folder, if it exists. Its last row is where things stand. If commits from your step come after it, a previous session stopped partway: carry on from them, without redoing what they hold, and end with Finish.
5. **Name the session**, if nothing else has been done in it yet, from the table below. If you have a tool that renames the current session (in the Claude desktop app, `set_session_title` with session id `self`), use it, then file the session under the sidebar group `<slug>` (list the groups first; create it only if it's missing). Otherwise the user names it.

| Step | Session name |
|---|---|
| `dev-plan` | `<slug> plan` |
| `dev-review plan` | `<slug> plan-review` |
| `dev-test Mx` | `<slug> Mx test` |
| `dev-build Mx` | `<slug> Mx build` |
| `dev-review Mx` | `<slug> Mx review` |
| `dev-review final` | `<slug> final-review` |
| `dev-build final` | `<slug> final-fix` |
| `dev-status` | `<slug> status` |

### While you work

- **One role.** Subagents may help with your own work, such as searching the code. Never start another role, as a subagent or by messaging another session: each role starts from a line the user pastes.
- **The user's decisions** come in the invocation or are typed later: "approve the plan", "ESC-2: option B", "accept M2", "defer F4 to M3", "allow one more round on M2". Record each one straight away, unless the Decision log already has it (a restart):
  - add `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")` to the Decision log in `plan.md`. Approving the plan, or accepting a milestone or the feature, also changes `Accepted:` or Progress, as `dev-plan`'s "Gate 1" and `dev-status`'s "Decisions" say;
  - mention it in your next `log.md` row, and commit it with your step. If your step has already finished, or stops before Finish, add a row with step `decision`, and commit it with the decision straight away, as `<slug>: decision <ref>` or the message your role gives for it (such as `<slug> Mx: accepted`).

  Then act on it only as far as your role allows.
- **Escalations.** Their IDs run `ESC-1`, `ESC-2`, … across the whole feature: take the number after the highest `ESC-` anywhere in the feature folder. Each states the question, the options and your recommendation, and stays open until the Decision log has an entry for it.
- **Your own calls.** Every choice you make that the user didn't (one reading of an ambiguity, a small deviation from the plan) goes under "Calls I made" in your handoff, response or review.
- **Quick and full checks.** The *full checks* are every command in Checks; the *quick checks* are the test files that cover what you changed, plus the quick command in Checks if it names one. Work with quick checks. A gate always rests on a full run, run or cited. When your role runs the full checks, run them once, after your last change to code or tests, and save them: redirect each command's output straight into `runs/<YYYY-MM-DD-HHMM>-<step>-<short hash>.txt` in the feature folder as it runs (`<command> > <file> 2>&1`, then `>>`; in Windows PowerShell, inside `cmd /c "..."`), so a lost capture never costs a second run. Then add a header at the top: the commit, each command, how long it took and its result. If the output is very long, keep its summary and every failure. Name the file in your handoff, response or review, and in your `log.md` row.

### Finish

1. **Commit your work** with the message your role gives, before you run the full checks, so that a saved run names a commit holding exactly what was tested. If a check fails and you fix something, commit again and rerun. Never push, amend, rebase or merge.
2. **Log.** Append one row to `log.md`. If the file is missing, create it with the heading `# Log: <slug>` and this table header:

   ```
   | When | Session | Step | Result | Next |
   |---|---|---|---|---|
   ```

   - **When:** local time, as `YYYY-MM-DD HH:MM`.
   - **Session:** `<session name> (<vendor> <model>)`, for example `csv-import M2 review (Claude Opus 5.5)`. Your vendor is Claude in Claude Code and Codex in Codex. Add `, same vendor` when a check ran on the same vendor as the work it checks: plan-review against plan, Mx review against Mx build, final-review against the vendor that built most milestones, and Mx test against Mx build (the builder adds it).
   - **Step:** the skill and target, for example `dev-review M2` or `dev-build M2 (answers r1)`.
   - **Result:** the commit or range, the test result, the verdict, counts, and any new ESC IDs.
   - **Next:** the paste line or lines from your baton.
3. **Commit the records** (handoff, review, `plan.md`, your `runs/` files) with your log row, as `<slug> <step>: records`. When your step writes only records, that's its one commit. Then `git status --porcelain` must be empty, because the next step stops on a dirty tree: commit anything your step wrote in the feature folder, and restore any break of your own. Never commit anything else here: name it to the user, and say the tree isn't clean.
4. **Reply** in at most 8 lines, then end with the baton:

   ```
   Done: <slug> <step>. <commit, tests, verdict, what's open>.
   Next: <what>, in <a new session | the "<session name>" session> (<vendor>: <why>). Paste:
     <line or lines>
   ```

   | The next session is | Claude | Codex |
   |---|---|---|
   | New | `/dev-x <args>`. In a terminal: `claude -n "<session name>" "/dev-x <args>"` | `/rename <session name>`, then `$dev-x <args>` |
   | Already open | `/dev-x <args>` | `$dev-x <args>` |

   **Which vendor.** For a check (plan-review, Mx test, Mx review, final-review), suggest the vendor that didn't write what it checks, from `log.md`, "or a fresh `<same vendor>` session if `<other vendor>` has no capacity"; for Mx test, "the vendor that won't build Mx". For a writing step, the vendor the user last used for that kind of step. When the next step is the user's (a gate, or an escalation), say what to read or decide, and what to type in which session.
