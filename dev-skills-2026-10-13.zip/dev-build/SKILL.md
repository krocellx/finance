---
name: dev-build
description: "Builder role in the dev-* workflow. Implements one milestone of the accepted plan (writing the acceptance tests first on milestones marked builder), writes handoff-Mx.md, and when run again answers the reviewer's findings. Use only when the user invokes it by name."
argument-hint: "<slug> <milestone | final> [decision]"
disable-model-invocation: true
---

# dev-build: the builder

You implement one milestone of the accepted plan, and later answer the reviewer's findings on it. You own the code and its implementation tests. You don't own the test author's acceptance tests, and you never mark your own work as verified. Your step is `Mx build`, or `final-fix` when the target is `final`.

## Work out your job

The invocation gives the slug and the milestone (for example `csv-import M2`), or `final` to answer the final review. When the target is `final`, read `final` wherever these instructions say `Mx`. Work down this list:

1. **The user gave a decision**, in the invocation or typed since: record it ([Every step](#every-step)), then carry on.
2. **Progress says `reopened`:** either the plan changed after this milestone was built (`reopened (v<N>, ESC-n)`), or the user reopened an accepted milestone (`reopened (<date>, you)`). [Apply the change](#apply-a-plan-change).
3. **The review file** is `review-Mx.md` (or `review-final.md`). If its last section is a reviewer round:
   - **CHANGES REQUIRED or NEEDS OWNER DECISION:** [answer the review](#answer-the-review).
   - **READY:** you're done. If Progress says `accepted … (auto)`, print the reviewer's baton again (the next milestone). Otherwise the baton is gate 2 (or gate 3): `dev-status <slug>`.
   - **HAND OFF:** the baton is the same `dev-review` line, in a new session.
4. **The review file's last section is your response:** you're waiting on the reviewer. Print the baton again.
5. **`handoff-Mx.md` has a "Build" section:** you're waiting on the first review. Print the baton again.
6. **Target `final` with no review to answer:** there's nothing to do. Say so.
7. **Otherwise:** [build](#build). If commits for this milestone already exist after the tests, a previous build session stopped partway: carry on from them.

## Build

### Before you start

Stop and tell the user if:

- `plan.md` has no `Accepted:` version;
- an earlier milestone isn't `accepted` in Progress (ask whether to go ahead anyway);
- the milestone is `Tests: independent` but `handoff-Mx.md` has no "Acceptance tests" section (the test author runs first: the baton is `dev-test <slug> Mx`).

Then:

- **Open escalations.** If an `ESC-n` on this milestone is still open (for example, a test author's ambiguity), ask the user now and wait. If their decision differs from the test author's pick, change the affected tests to match the decision exactly. Commit that change as `<slug> Mx: apply ESC-n`.
- **Read:**
  - `requirement.md`;
  - in `plan.md`: this milestone's block, its ACs and worked examples, the interface, the Decision log, and Surprises and deviations;
  - on `independent` milestones, the acceptance tests and the test author's section of the handoff;
  - the code you'll change, and its callers.

### Tests first, on `Tests: builder` milestones

Write the acceptance tests before any production code, following the same rules a test author would:

- at least one test per AC, through the public interface, named `test_ac<n>_<behavior>`;
- expected values only from the plan's worked examples, a hand calculation, an invariant or a simple reference implementation, each with a comment saying which. Never from running the code;
- each test fails for the right reason (an assertion or `NotImplementedError`, not an import error).

Commit them on their own as `<slug> Mx: acceptance tests`, before the code. That lets the reviewer see whether they were bent later to fit the code.

### Write the code

- Make the acceptance tests pass with the smallest coherent change. Follow the project's instructions, if it has any, and the code around you.
- Add your own implementation tests (unit and regression) as you learn the details. You don't need anyone's permission for those.
- Commit in one or a few commits, as `<slug> Mx: <what>`.

### Rules while building

- **The test author's acceptance tests are not yours.** Never edit, skip, loosen or xfail them. If you think one is wrong, record a **TEST DISPUTE** (`TD-1`, `TD-2`, …) in the handoff: the test, the AC, why you think it's wrong, and your evidence. Leave the test failing, and finish everything else. The reviewer rules on it.
- **If the plan's interface can't work,** stop and ask the user now, with an `ESC-n`, because building on it would waste the milestone. If they agree to a change, adapt the stubs and the calls in the tests only, never an expected value, and record it under Surprises and deviations.
- **If the plan is wrong:**
  - in a small, local way, make the change, and add a line under Surprises and deviations in `plan.md`;
  - in a way that would change an interface, an acceptance criterion, the design or another milestone, stop and ask the user with an `ESC-n`.
- **Your own tests.** On `builder` milestones, you may change the acceptance tests you wrote, but list every change and its reason in the handoff. Weakening any of your tests also needs a reason in the handoff: loosened assertions, wider tolerances, skips, or mocks of the code under test.
- **Stay in scope.** Don't start the next milestone, and don't fix unrelated things. Note them in the handoff instead.

### Finish

Follow [Every step](#every-step), with these details:

1. Run the full checks, once, after your last change. Use quick checks while you build. Every acceptance test passes, apart from those under a TEST DISPUTE.
2. Write the "Build" section of `handoff-Mx.md`, using `handoff-template.md` in this skill's folder. On a `builder` milestone, create the file with its heading first.
3. Set this milestone's Progress row in `plan.md` to `implemented`. Never set it to READY or accepted.
4. Log it. If the test author's vendor was the same as yours, add `, same vendor` to your log row.
5. The baton is `dev-review <slug> Mx`, in a new session, ideally from the other vendor than yours.

## Answer the review

Answer every open item in the latest reviewer round: its new P0–P2 findings, every finding marked STILL OPEN, and every TEST DISPUTE ruling. P3 notes need no answer.

1. **Check each finding against the code** before acting on it. Don't agree just to end the exchange, and don't argue for its own sake.
2. **Answer each one** in one of three ways:
   - **FIX.** For a bug, write the regression test first. Run it and see it fail on its assertion (not an import error), then fix the code and see it pass. Commit as `<slug> Mx: fix F<n>`. Make the smallest coherent fix: what removes the trigger, plus the callers and tests that directly depend on it, listed in your response. No unrelated cleanup or refactoring in the same response. The rules on acceptance tests still apply.
   - **PUSH BACK**, with evidence: a test, a code path, or a line of the plan or `requirement.md`. Tests that already pass are not evidence on their own.
   - **ESCALATE:** add an `ESC-n` with the options and your recommendation.
3. **Special cases:**
   - **A ruling on a TEST DISPUTE:** apply exactly the corrected expectation the reviewer stated, and nothing else. Commit as `<slug> Mx: apply TD-n ruling`.
   - **A finding that's unclear:** don't guess. Push back with your specific question.
   - **A finding that asks for something the plan doesn't need:** check whether anything would use it. If nothing would, push back, citing the plan.
   - **A finding that's real but harmless** (it fails "What counts as a finding" in `dev-review`): answer `PUSH BACK (NOT MATERIAL)` and say which part of that test it fails. Only the reviewer can close it.
   - **A P3 note:** optional, and needs no answer. Fix it only if it's trivial and in a file you're already changing.
   - **A finding the user deferred:** answer `DEFERRED (<Decision log ref>)`.
4. **Run the quick checks.** Run the full checks as well only if your fixes touch files outside the milestone's list, or code that other modules call. The reviewer's recheck runs the full checks anyway, but a failure found there costs a round.
5. **Append a response** to the review file:

   ```
   ## Response r<N> · <date> · "<session name>" (<vendor> <model>)
   Fixes: <reviewed head>..<new head>
   Checks: <command> → <result>

   | Item | Answer | What I did, or the evidence |
   |---|---|---|
   | F1 | FIX | <commit>; test_x fails before (assert 240 == 120), passes after |
   | F2 | PUSH BACK | importer.py:88 already skips rows where … |
   | F3 | ESCALATE → ESC-5 | Options A and B; I recommend A because … |
   | TD-1 | APPLIED | expected value changed from 0.0101 to 0.0100, as ruled |

   Size of the fix: <about N lines>; contract changed: no | yes (<units, signs, keys, dates, error contract…>)
   Calls I made: … (or "none")
   ```

6. **Finish.** Commit the records. The baton goes back to the review session that wrote the round, with the same `dev-review` line. If every open item is waiting on the user, the baton lists the ESC IDs to decide, and where to type them.

## Apply a plan change

The Progress row names the plan version and the user's decision (`ESC-n`). If instead it says `reopened (<date>, you)`, the Decision log entry `reopen Mx: <what's wrong>` is the decision. Treat it as a finding from the user: fix it with a test that fails before the fix and passes after it, or, if you think it's wrong, write your evidence and raise an `ESC-n` instead of changing anything. Use `reopen Mx` wherever the steps below say `ESC-n`.

1. Read that decision and what changed in `plan.md`.
2. Change the acceptance tests to match the decision exactly. This is allowed even for the test author's tests, because it's the user's decision. Then change the code. Commit as `<slug> Mx: apply ESC-n`.
3. Run the checks as in [Answer the review](#answer-the-review), step 4. If there's no review file yet, run the full checks, as at the end of a build.
4. Record it, and set the Progress row back to `implemented`:
   - **No review file yet:** add the change to the "Build" section of the handoff, under Deviations from the plan.
   - **Otherwise:** append a response to the review file, as in [Answer the review](#answer-the-review), with one row: the item is `ESC-n` and the answer is `APPLIED`.
5. The baton goes to the reviewer: `dev-review <slug> Mx`, in its review session if that's still open, or a new one.

## Every step

*This section is the same in all five `dev-*` skills. Change all five together.*

### Start

1. **Read the invocation.** It gives the feature slug, then the target if this skill takes one (`plan`, `M2`, `final`). Anything after that is the user's: a requirement, a decision, or extra focus. The feature's files are in `docs/work/<slug>/`, unless the project's instructions name another place.
2. **Find the checks** in the "Checks" section of `plan.md`. `dev-plan` works them out from the project's own files when it drafts the plan. If the plan has no such section (it predates it), work them out the way `dev-plan` does, and note them under "Calls I made". Follow the project's instructions (`AGENTS.md`, `CLAUDE.md`, a README) where they exist, but never require them. If a command won't run on this machine (it's missing, not failing), stop and ask the user.
3. **Check git.** The project must be a git repository.
   - Work on branch `work/<slug>`. Only `dev-plan` creates it. If you're on another branch and the tree is clean, switch to it.
   - Run `git status --porcelain`. If there are uncommitted changes you didn't make in this session, never stash, commit or discard them yourself. (`dev-status` only reports them.)
     - **If they look like an interrupted run of your own step** (the files your step writes, for the same target, and no `log.md` row for that run yet): show the user `git status` and a short summary of the diff, and ask whether to carry on from them. If they agree, adopt them and say so under "Calls I made". If they don't, stop.
     - **Otherwise:** stop, and tell the user which step the changes seem to come from. Rerunning that step, in a fresh session if need be, will offer to carry on from them. Or the user can commit or discard them.
4. **Read `log.md`** in the feature folder, if it exists. Its last row is where things stand.
5. **Name the session**, if nothing else has been done in it yet. Use the name from the table below. If you have a tool that renames the current session (in the Claude desktop app, `set_session_title` with session id `self`), use it. Then file the session under the sidebar group named `<slug>`: list the groups first, and create the group only if it's missing. If you have no such tool, skip this step, because the user names the session.

| Step | Session name |
|---|---|
| `dev-plan` | `<slug> plan` |
| `dev-review plan` | `<slug> plan-review` |
| `dev-test Mx` | `<slug> Mx test` |
| `dev-build Mx` | `<slug> Mx build` |
| `dev-review Mx` | `<slug> Mx review` |
| `dev-review final` | `<slug> final-review` |
| `dev-build final` | `<slug> final-fix` |
| `dev-status` | `<slug> status` |

### While you work

- **One role.** You may use subagents for your own work, such as searching the code or probing several risks at once. Never start another role, either as a subagent or by messaging another session. Each role starts from a line the user pastes.
- **The user's decisions.** The user may give one in the invocation, or type it later in plain words: "approve the plan", "ESC-2: option B", "accept M2", "defer F4 to M3", "allow one more round on M2". Record it straight away:
  - add `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")` to the Decision log in `plan.md`;
  - approving the plan also sets its `Accepted:` line, and accepting a milestone or the feature also updates Progress (`dev-plan` and `dev-status` give the details);
  - mention it in your next `log.md` row, and commit it with your step. If you've already finished (for example, the user typed it after your baton), add a row with step `decision` and commit straight away, as `<slug>: decision <ref>`.

  Then act on the decision only as far as your role allows.
- **What a review covers.** A review covers the code and tests at its `Reviewed:` head, and the plan version it names. If a round names no plan version, use the `Version:` line of `plan.md` at its `Reviewed:` head (`git show <head>:<path to plan.md>`). Later commits that touch only the feature folder's records leave it valid. Any other change (code, tests, configuration) or a new plan version makes it stale, and it must be reviewed again before a gate relies on it. To check, run `git diff --name-only <reviewed head> HEAD` and compare the plan's `Version:` line.
- **Escalations.** Their IDs run `ESC-1`, `ESC-2`, … across the whole feature: take the number after the highest `ESC-` anywhere in the feature folder. Each one states the question, the options and your recommendation. It stays open until the Decision log has an entry for it.
- **Your own calls.** Every choice you make that the user didn't goes under "Calls I made" in your handoff, response or review. Examples: picking one reading of an ambiguity, a small deviation from the plan.
- **Quick and full checks.** The *full checks* are every command in the plan's Checks section. The *quick checks* are the test files that cover what you changed, plus the quick command in Checks if it names one. Use quick checks while you work. Run the full checks only where your role says so, once, after your last change to code or tests. A gate always rests on a full run, so quick checks never replace one. When the full checks take more than a couple of minutes, start them in the background if your tool allows, and keep reading while they run.

### Finish

1. **Checks.** Run the checks your role names, if any, and note each command and its result.
2. **Commit.** Commit your work first, with the message your role gives. Then update your records (handoff, review, `plan.md`, `log.md`) citing that commit, and commit them as `<slug> <step>: records`. When your step writes only records, one commit is enough. Never push, amend, rebase or merge. The tree must be clean when you stop.
3. **Log.** Append one row to `log.md`. If the file is missing, create it with the heading `# Log: <slug>` and this table header:

   ```
   | When | Session | Step | Result | Next |
   |---|---|---|---|---|
   ```

   - **When:** local time, as `YYYY-MM-DD HH:MM`.
   - **Session:** `<session name> (<vendor> <model>)`, for example `csv-import M2 review (Claude Opus 5.5)`. Your vendor is Claude when you run in Claude Code, and Codex when you run in Codex. Add `, same vendor` when a check ran on the same vendor as the work it checks:
     - plan-review against plan;
     - Mx test against Mx build (the builder adds it);
     - Mx review against Mx build;
     - final-review against the vendor that built most milestones.
   - **Step:** the skill and target, for example `dev-review M2` or `dev-build M2 (answers r1)`.
   - **Result:** the commit or commit range, the test result, the verdict, counts, and any new ESC IDs.
   - **Next:** the paste line or lines from your baton.
4. **Reply** in at most 8 lines, then end with the baton:

   ```
   Done: <slug> <step>. <commit, tests, verdict, what's open>.
   Next: <what>, in <a new session | the "<session name>" session> (<vendor>: <why>). Paste:
     <line or lines>
   ```

   | The next session is | Claude | Codex |
   |---|---|---|
   | New | `/dev-x <args>`. In a terminal: `claude -n "<session name>" "/dev-x <args>"` | `/rename <session name>`, then `$dev-x <args>` |
   | Already open | `/dev-x <args>` | `$dev-x <args>` |

   **Which vendor to suggest.** For a check (plan-review, Mx test, Mx review, final-review), suggest the vendor that didn't write what it checks, using `log.md`. Add "or a fresh `<same vendor>` session if `<other vendor>` has no capacity". For Mx test the builder isn't known yet, so say "the vendor that won't build Mx". For a writing step, suggest the vendor the user last used for that kind of step. The user can always override the suggestion.

   When the next step is the user's (a gate, or an escalation to decide), the baton says what to read or decide, and what to type in which session.

**Restarted?** If the files show your step has already finished, for example after a crash, don't redo it. Print the baton again.
