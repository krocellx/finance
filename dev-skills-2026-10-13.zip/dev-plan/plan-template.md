# Plan template

Copy everything below the line into `docs/work/<slug>/plan.md` and fill it in. Keep the section names, because the other `dev-*` skills look for them. Delete the guidance in *italics*.

---

# Plan: <slug>

Version: v1 (<YYYY-MM-DD>)
Accepted: no
Branch: `work/<slug>`, from `<branch>` at `<commit>`
Process: full | medium
Requirement: [requirement.md](requirement.md), the user's words, verbatim

## Goal

*One or two sentences: what the user can do once this is done.*

## Non-goals

- *What this feature deliberately won't do.*

## Acceptance criteria

*Number them AC-1, AC-2, …, and never renumber. Each one must be observable, and must say how it's checked. Any AC on money or data gets worked examples with exact expected values.*

**AC-1:** *<observable behavior>.* Checked by: *<acceptance test | command | manual step>*.

| Input | Expected | Source |
|---|---|---|
| *file A (120 trades), imported twice* | *120 rows in positions* | *the user (requirement.md)* |
| *trade T1 at 101.00, previous close 100.00* | *return 0.0100* | *planner: (101 − 100) / 100 (confirm at gate 1)* |

## Context

- Current behavior: *…*
- Relevant code: *paths, and what each does*

## Checks

*Worked out by the planner from the project's own files, and run once as the baseline. Every `dev-*` step reads its commands from here.*

- Full: `<command>` → *<baseline result>, about <N> min*; `<command>` → *…*
- Quick: *how to run one test file (for example `pytest <file>` or `node --test <file>`)*, plus `<fast subset command>` *(or "only the changed test files": write "not needed" when the full checks take under 2 minutes)*
- Found in: *package.json scripts | pyproject.toml | Makefile | the CI config | the project's instructions | the user*

## Design

*The approach. Discuss alternatives only where the choice matters. Name the real modules and functions.*

## Risks and edge cases

*For money and data, consider each of these: signs and direction; units and scale; rounding (and floats for money); currencies; time zones; as-of vs report dates; fiscal vs calendar periods; trading calendars and holidays; windows off by one; look-ahead; join keys (duplicates, missing, many-to-many); running twice; missing or empty inputs; totals that should reconcile.*

## Milestones

### M1: <title>

Tests: independent | builder. *<one-line reason>*
Covers: AC-1, AC-2
Interface: `<exact signatures, with types, units and errors raised>` *(exact on `independent` milestones)*
Worked examples: *a table, or "see AC-1"* *(required on `independent` milestones)*
Files: *the files you expect to change*
Done when: *the AC-1 and AC-2 acceptance tests pass, and the full suite is green*
Size: about *N* changed lines

## Test strategy

- Acceptance tests: `tests/acceptance/`, one or more per AC, named `test_ac<n>_<behavior>`, unless the project already has a convention (name it here).
- Fixtures: *…*
- Covered only by implementation tests, and why: *…*

## Open questions

*ESC-n: the question. Options A and B. Recommendation, with the reason. Each one is open until the Decision log has an entry for it.*

## Decision log

*One line per decision: `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")`. The planner's own calls go here too, marked `(planner)`.*

## Progress

| Milestone | State | Date | Ref |
|---|---|---|---|
| M1 | planned | | |

*States: planned → tests written (test author) → implemented (builder) → READY (reviewer) → accepted (the user; or `accepted <date> (auto)`, set by the reviewer on a `builder` milestone with nothing that needs the user's call). The user can set any accepted milestone to `reopened`. After the last milestone, add a row `Feature`, which the user sets to `accepted`.*

## Surprises and deviations

*The builder adds one line for each place where the code had to differ from the plan: `- <YYYY-MM-DD> Mx: <what differed>, <what was done>, <why>`.*
