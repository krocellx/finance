# The dev-* skills

*v1, 2026-10-09; revised through 2026-10-14. Written from [final_workflow](../final_workflow/). Installed, and in trial since 2026-10-12.*

This folder is the source of truth. If you link the skills into both tools with junctions (step 2 below), an edit here reaches Claude Code and Codex at once. With plain copies, copy them again after every edit.

| Skill | Role | Paste | Supporting file |
|---|---|---|---|
| [dev-analyse](dev-analyse/SKILL.md) | Analyst | `dev-analyse <slug>`, then your question or idea | [analysis-template.md](dev-analyse/analysis-template.md) |
| [dev-plan](dev-plan/SKILL.md) | Planner | `dev-plan <slug>`, in the same session once you've read `analysis.md` | [plan-template.md](dev-plan/plan-template.md) |
| [dev-test](dev-test/SKILL.md) | Test author | `dev-test <slug> Mx` | |
| [dev-build](dev-build/SKILL.md) | Builder | `dev-build <slug> Mx` (or `final`) | [handoff-template.md](dev-build/handoff-template.md), [compare.md](dev-build/compare.md), [answer-review.md](dev-build/answer-review.md) |
| [dev-review](dev-review/SKILL.md) | Every reviewer | `dev-review <slug> plan`, `Mx` or `final` | [review-template.md](dev-review/review-template.md), [plan-review.md](dev-review/plan-review.md), [recheck.md](dev-review/recheck.md) |
| [dev-status](dev-status/SKILL.md) | You | `dev-status <slug>`, then your decision | [gates.md](dev-status/gates.md) |
| [dev-control](dev-control/SKILL.md) | Your driver (optional) | `dev-control <slug>`, then any limits; for a new feature, your question or idea on the next lines | |

In Claude Code you start a skill with `/`, and in Codex with `$`. A session always takes the same line: each skill works out its next job from the files in `docs/work/<slug>/`.

## How the files are built

- **Two parts per `SKILL.md`.** The top is the role. The bottom, `## Every step`, is the same in all six role skills: starting, naming the session, recording your decisions, committing, the log row and the baton. **Edit that section in all six at once.** To check that they still match (all six hashes should be equal; `dev-control` has no such section: ignore its line):

  ```powershell
  Get-ChildItem skills\dev-*\SKILL.md | ForEach-Object { $t = Get-Content $_ -Raw -Encoding UTF8; $tail = $t.Substring($t.IndexOf('## Every step')); $h = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($tail))).Substring(0, 11); "$h  $($_.Directory.Name)" }
  ```

- **One body for both tools.** The text never uses `$ARGUMENTS`. It says "the invocation gives the slug, then the target". Codex sees that text in your message, and Claude Code appends it as `ARGUMENTS:`.
- **Nothing starts on its own.** `disable-model-invocation: true` in the frontmatter (Claude Code) and `allow_implicit_invocation: false` in `agents/openai.yaml` (Codex). This applies to `dev-status` too, because it writes your decisions, and to `dev-control`, because it starts sessions.
- **`dev-control` is not a role.** It has no `## Every step`, writes nothing in the project, and gives each session only the skill, slug and target from the baton's line (plus your own words), so a role works as if you had pasted it. Every step runs on its own vendor unless a pin or an exclusion moves it, or you add `cross` to the limits, which sends each step, checks included, to the vendor the baton suggests. In the Claude desktop app it starts Claude steps as app sessions (unless the app would cap the model), and everything else headless, with `claude -p` or `codex exec`.
- **No pinned models, and no Claude-only features** such as `context: fork`, `model:` or `!` commands. You choose the model for each session, or `dev-control` picks one per step within the limits you give it.
- **Templates sit next to each `SKILL.md`**, and the skills refer to them as "in this skill's folder".
- **Text only some runs need sits in its own file**, reached by a line that says "read it in full now" at the point it's needed: `recheck.md`, `plan-review.md`, `compare.md`, `answer-review.md`, `gates.md`.

## What the skills took from other projects

As planned in [3-existing-tools.md](../final_workflow/3-existing-tools.md#what-we-reuse), rewritten in our own words:

| Idea | From | Where |
|---|---|---|
| Check a finding against the code first, ask about unclear findings rather than guess, no performative agreement, check whether anything would use a requested addition | Superpowers, receiving-code-review | "Answer the review" in `dev-plan` and `dev-build` |
| Check every fix, then the whole fix diff for anything newly broken | Superpowers, re-review | `recheck.md` in `dev-review` |
| Every call an agent makes on its own is written down for you | Superpowers, controller rulings | "Calls I made" in every handoff, response and review, collected by `dev-status` at the gates |
| Bad-test patterns | BMAD TEA, test review | "Bad tests" in `dev-review` |
| AC-to-test trace table; only you waive | BMAD TEA, trace | the AC trace in `dev-review`; deferrals only by your decision |
| Each acceptance test fails before the build, for the right reason | BMAD TEA, ATDD | "Red run" in `dev-test` |
| Questions in rounds: each round asks only what the earlier answers allow, each question with a recommended answer that "yes" accepts; the agent finds facts, the user makes decisions | Matt Pocock's skills (`grilling`); grouped questions from Spec Kit, clarify | "Ask, in rounds" in `dev-analyse`; `dev-plan` asks only what the analysis left open |
| Check what the user says about the code against the code, and ask which is right | Matt Pocock's skills (`domain-modeling`) | "Ask, in rounds" in `dev-analyse` |
| 2–3 approaches with a recommendation when the choice matters; ask once whether you'd build it this way from scratch | Anthropic feature-dev; poteto's `plan` (alternatives and redesign checks) | "Approach" in `dev-analyse` |
| A fresh agent reads the brief as the planner who can't ask questions, and lists only what it would have to guess | Superpowers, brainstorming (builder check) | "Planner check" in `dev-analyse` |
| Wide code searches go to subagents, so the session keeps room for the plan | poteto's `plan` | "Look" in `dev-analyse` |
| Flag code that hides a failure: a broad catch that carries on, an unrequested fallback or default | Anthropic, silent-failure-hunter | "Hidden failures" in `dev-review`; "Fail loudly, don't handle" in `dev-build` |
| Pre-existing defects aren't findings against the change | Anthropic, code-review | "Found outside this change" in `dev-review` and the handoff, listed at gate 3 by `dev-status` |
| Ask at gate 1 whether the milestones are too coarse or too fine | Matt Pocock's skills (`to-tickets`) | `dev-status`'s gate 1 view |
| List the plan's assumptions with their sources | Claudex Loop, recon | "Facts the plan relies on" in `dev-plan`, checked by `dev-review`, `unverified` ones at gate 1 |
| Learn from each loop | Compound Engineering, compound | "How the process went" at gate 3 in `dev-status`, kept in the last `log.md` row |
| Published figures as expected values (anchors); gate 2 as short proof lines, not prose | our own, prompted by pstack (poteto, MIT): trust comes from proof you can check, not from reading the write-up | "anchors" in `dev-test`; their check and "Proof" in `dev-review` |
| Same real input, same output, before and after a refactor | our own | The `Compare:` line in `dev-plan`, `compare.md` in `dev-build`, run by `dev-build`; `dev-review` checks it and breaks the code once |

## Install

Done on the main PC on 2026-10-11, as plain copies. These steps are for another machine. They change your tool setup, so they're yours to run.

1. **Remove the old Codex skills first**, or Codex will load two `dev-plan`, `dev-build` and `dev-status` skills. `~/.codex/skills` is a git repository, so remove them there with a commit:

   ```powershell
   git -C "$env:USERPROFILE\.codex\skills" rm -r -q dev-build dev-fix-review dev-handoff dev-plan dev-recheck dev-review-code dev-review-plan dev-status
   ```

   ```powershell
   git -C "$env:USERPROFILE\.codex\skills" commit -m "Remove the 3 Oct dev-* skills; replaced by project_development_with_agent/skills"
   ```

2. **Link the six role skills into both tools.** Junctions need no admin rights. This is the same way your `knowledge-*` skills are linked in `~/.agents/skills`:

   ```powershell
   $src = "D:\PythonProjects\project_development_with_agent\skills"; foreach ($s in "dev-analyse","dev-plan","dev-test","dev-build","dev-review","dev-status") { New-Item -ItemType Junction -Path "$env:USERPROFILE\.claude\skills\$s" -Target "$src\$s" | Out-Null; New-Item -ItemType Junction -Path "$env:USERPROFILE\.agents\skills\$s" -Target "$src\$s" | Out-Null }
   ```

3. **In each project:** a git repository. Nothing else is required. `dev-plan` works out the test, lint and type-check commands from the project's own files, and records them in each feature's `plan.md` (its Checks section). An `AGENTS.md` or `CLAUDE.md` is optional, and is followed where it exists.

## Five-minute checks

Run these in a throwaway git repository that has a test command (for example a `package.json` with a `test` script):

- [ ] **Codex:** `$dev-status demo` loads the skill and sees `demo`. The Claude-only frontmatter keys cause no load error. (Codex's own `skill-creator` validator rejects `argument-hint` and `disable-model-invocation`. With those two keys removed, the first five passed it; `dev-analyse` hasn't been run through it yet. That's a packaging check, not proof of a loading failure. If Codex really refuses them, give Codex copies without the two keys instead of junctions.)
- [ ] **Codex:** an unrelated request ("what's the status?") doesn't start any `dev-*` skill on its own.
- [ ] **Claude Code:** `/dev-status demo` loads the skill. `dev-*` skills don't appear in what Claude can start by itself.
- [ ] **Claude desktop app:** a fresh session started with `/dev-status demo` renames itself `demo status` and files itself under a sidebar group `demo`.
- [ ] **Claude in a terminal:** `claude -n "demo status" "/dev-status demo"` opens a named session that runs the skill.
- [ ] **Both:** `/dev-analyse demo` (or `$dev-analyse demo`) with a two-line idea that needs a change finds `analysis-template.md` in its own folder, and `/dev-plan demo` after it finds `plan-template.md`.

## Pilot

Run one milestone that has money or data logic end to end, from `dev-plan` to gate 2, as in [2-running-it.md](../final_workflow/2-running-it.md#one-milestone-paste-by-paste). Things to watch:

- Did each skill pick the right job from the files, every time it was run again?
- Was every baton right, and could you paste it as is? Did any baton send you to a new session you didn't need? (Fixed once, 2026-10-12: the gate 2 and gate 3 batons in `dev-review` now say to run `dev-status` in the review session or any open one. Since 2026-10-13, `dev-review` shows gate 2 and gate 3 in its own baton.)
- Did the TEST DISPUTE path, the round budget or HAND OFF come up? If so, did they work?
- Did "What counts as a finding" cut the noise? Gate 3's "how the process went" counts the findings that were DOWNGRADED or left as P3 notes; check whether any of them turned out to matter later. (Added 2026-10-12, after the first trial's plan review ran four rounds and asked for a fifth; see `codex_review_04/`.)
- How long did each gate take you, and was the `dev-status` gate view enough to decide?
- Added 2026-10-14: did the facts list, a `Compare:` line, a hidden-failure finding or "Found outside this change" come up? Did each one catch something, or only add reading?

Afterwards, drop any part that didn't earn its place, before using the skills on a second feature.

## Credits

`dev-review`'s "How to judge any target" adapts wording from the code-reviewer prompt in [Superpowers](https://github.com/obra/superpowers) (`skills/requesting-code-review/code-reviewer.md`, v7.0.0), used under the MIT License:

> MIT License. Copyright (c) 2025 Jesse Vincent. Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
