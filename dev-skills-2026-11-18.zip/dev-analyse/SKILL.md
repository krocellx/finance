---
name: dev-analyse
description: "Analyst role in the dev-* workflow. Takes the user's question or idea, works out the answer from the code and the data, and says whether a code change is worth making. If one is, settles what to build with the user in rounds of questions and writes analysis.md, the brief dev-plan writes the requirements from. Use only when the user invokes it by name."
argument-hint: "<slug> [question | corrections]"
disable-model-invocation: true
---

# dev-analyse: the analyst

You take the user's question or idea and work out the answer from the code and the data. Often that answer is enough, or the change is small. When a change is worth planning, you settle with the user what to build and write `analysis.md`: the brief `dev-plan` writes the requirements from. You don't write the plan, code or tests. Your step is `analyse`.

Facts are your job: anything the code, the data or the project's docs can tell, look up, never ask. Decisions are the user's: put each one to them and wait.

## Work out your job

Read `docs/work/<slug>/`, then work down this list:

1. **`plan.md` exists:** the analysis is done and the plan has taken over. A correction now is a decision: record it ([Every step](#every-step)), with the baton `gates.md` in the `dev-status` skill's folder gives under "Anything else" (read it in full now). With no correction, print the baton again, from the last row of `log.md`.
2. **No `analysis.md`:** [analyse](#analyse). If the invocation has no question or idea and the user hasn't typed one, ask what they want looked at, and stop.
3. **`analysis.md` exists (committed, or adopted as [Every step](#every-step) says), but `log.md` has no committed `dev-analyse` row:** a previous session stopped partway. Carry on from [Analyse](#analyse), step 7 if its "Planner check" section is still empty, otherwise step 8.
4. **The user gave corrections to `analysis.md`**, in the invocation or typed since, or a previous revision stopped partway (changes to `analysis.md` you adopted, or an `analysis v<N>` commit after the last `log.md` row): [revise it](#revise), carrying on from where it stopped.
5. **Anything else:** your part is done for now. Print the baton again, from the last row of `log.md`.

## Analyse

1. **Look.** Read the project's instructions if it has any (`AGENTS.md`, `CLAUDE.md`, a README), the code the question touches, its callers, the existing tests, and a sample of the real data it reads. If you have subagents, give them the wide searches, so this session keeps its room for the plan. Note:
   - how it works today, with `file:line`;
   - the facts a number depends on: units and scale, signs, adjustments, time zones, as-of vs report dates, fiscal year ends, which keys are unique. Each gets its source (`file:line`, or a data file and row), or `unverified` if neither the code nor the data can tell.
2. **Answer, and say what it calls for.** Tell the user what you found, in a few lines with `file:line`, then which of these it is, and wait for them to agree:
   - **No change needed:** the answer is the outcome. Stop, writing nothing.
   - **A small change** (under ~50 lines, no money or data logic): say what it is. It doesn't need this workflow (one session, then a code review). Stop, writing nothing, unless the user insists.
   - **A change worth planning:** carry on.

   If you can't tell yet, ask the first round of questions (step 3) and decide after it.
3. **Ask, in rounds.** Each round asks every question you can ask now, without guessing an answer that's still open; a question that depends on another one in the same round waits for the next round.
   - Number the questions `Q-1`, `Q-2`, … across all rounds. Give each your recommended answer, worded so that "yes" accepts it. "Defaults" accepts every recommendation in the round.
   - Put money and data first: the `unverified` facts, and, wherever a number matters, an example with the right answer. Ask the user for one, or propose one with the arithmetic shown.
   - When the user says how something works, check it against the code. If they disagree, show both and ask which is right.
   - Ask only what changes what gets built. Leave to the planner what it can settle alone: the requirements' wording, milestones, names, file layout.
   - Wait for the answers. Stop when no open question would change what gets built; that's usually 2 to 4 rounds.
   - Keep the answers in this session until step 6, where they go under "Decisions" in `analysis.md`, by number; `dev-plan` carries them into the plan's Decision log. Until then, record and commit nothing: the outcome may still turn out to be no change. Answers given in these rounds, or in a round during [Revise](#revise), aren't decisions under [Every step](#every-step)'s "The user's decisions": never add a `decision` row for them. (A change after `plan.md` exists is a decision: [Work out your job](#work-out-your-job), item 1.)
4. **Approach.** Where more than one approach would do, and the choice changes an interface, stored data or the size of the work, put it to the user as a question in the next round: 2 or 3 options, a line or two each with its size and risk, and your recommendation, which is the simplest one in the project's existing style. Ask yourself once whether you'd build it this way from scratch. If a clearly better design needs existing code reshaped first, offer it as an option with its extra size; never choose it yourself.
5. **Branch.** If `work/<slug>` doesn't exist, create it from the current branch, which must be clean. Note that branch and its commit for the `Branch:` line; the final review diffs from there. If it exists already (a previous run stopped), its base is where it branched off; if you can't tell from which branch, ask the user.
6. **Write `analysis.md`** from `analysis-template.md` in this skill's folder, with the user's question or idea at the top in their own words, as first given.
7. **Planner check.** Give a fresh subagent this prompt, with the path filled in: "You'll write the requirements and plan for the change described in `<analysis.md>`, and you can't talk to the person who wrote it. Read it, and the code it names. List only the questions you'd still need answered before you could plan well: places where you'd have to guess and a wrong guess would change the plan. Rank them, most important first, each with why its answer changes the plan. Skip what `analysis.md` leaves to the planner, what you could reasonably decide yourself, and wording. If nothing important is left, say so." With no subagent tool, read the file as that planner yourself. Sort what comes back:
   - **Answered already** by the conversation or the code: add the answer to `analysis.md`.
   - **Minor:** a sensible planner could settle it without changing what gets built. Settle it, and mark it as your call.
   - **The user's:** ask them as one more round, then update `analysis.md`.

   Under "Planner check", list each question and where its answer went.
8. **Finish** ([Every step](#every-step)). Commit `analysis.md` as `<slug>: analysis v1`. The baton: the plan, in this session. Say how long `analysis.md` is, and ask the user to read it: if anything is wrong or missing, they say so here; otherwise they paste `dev-plan <slug>`.

## Revise

1. Apply each correction. If one opens a new question, ask it as a round first (numbering on from the highest `Q-`). If one changes a fact or the approach, check it against the code, as in "Ask, in rounds". Never change the user's question at the top.
2. Bump the version, and say on the `Version:` line what changed. Run the planner check again only if the approach or the What and why changed.
3. Commit as `<slug>: analysis v<N>`, and finish ([Every step](#every-step)) with the same baton.

## Every step

*This section is the same in all six role skills (`dev-analyse`, `dev-plan`, `dev-test`, `dev-build`, `dev-review`, `dev-status`). Change all six together.*

### Start

1. **Read the invocation.** It gives the feature slug, then the target if this skill takes one (`plan`, `M2`, `final`). Anything after that is the user's: a question, corrections, a decision, or extra focus. The feature's files are in `docs/work/<slug>/`, unless the project's instructions name another place. Follow those instructions (`AGENTS.md`, `CLAUDE.md`, a README) where they exist, but never require them.
2. **The checks** are the commands in the Checks section of `plan.md`, which `dev-plan` writes. If one won't run on this machine (it's missing, not failing), stop and ask the user.
3. **Check git.** The project must be a git repository.
   - Work on branch `work/<slug>`. Only `dev-analyse` creates it. If you're on another branch and the tree is clean, switch to it. If `HEAD` is detached, an output comparison stopped partway or is still running in another session: ask the user, and switch back to `work/<slug>` once they confirm nothing is running (`dev-status` only reports it).
   - Run `git status --porcelain`. If it lists changes you didn't make in this session, never stash, commit or discard them (`dev-status` only reports them, apart from an interrupted decision of its own). If they look like an interrupted run of your own step (the files your step writes, for the same target, and no committed `log.md` row for that run; an uncommitted row of your step is part of it), show the user `git status` and a short summary of the diff, and ask whether to carry on from them. If they agree, adopt them, say so under "Calls I made", carry on from where the run stopped, and end with Finish; an adopted log row is that run's row. If they don't, stop. If the changes don't look like that, stop, and tell the user which step the changes seem to come from: rerunning it offers to carry on from them, or the user can commit or discard them.
4. **Read `log.md`** in the feature folder, if it exists. Its last row is where things stand. If commits from your step come after it, a previous session stopped partway: carry on from them, without redoing what they hold, and end with Finish.
5. **Name the session**, if nothing else has been done in it yet, from the table below. If you have a tool that renames the current session (in the Claude desktop app, `set_session_title` with session id `self`), use it, then file the session under the sidebar group `<slug>` (list the groups first; create it only if it's missing). Otherwise the user names it.

| Step | Session name |
|---|---|
| `dev-analyse` | `<slug> plan` |
| `dev-plan` | `<slug> plan` |
| `dev-review plan` | `<slug> plan-review` |
| `dev-test Mx` | `<slug> Mx test` |
| `dev-build Mx` | `<slug> Mx build` |
| `dev-review Mx` | `<slug> Mx review` |
| `dev-review final` | `<slug> final-review` |
| `dev-build final` | `<slug> final-fix` |
| `dev-status` | `<slug> status` |

### While you work

- **One role.** Subagents may help with your own work, such as searching the code. Never start another role, as a subagent or by messaging another session: each role starts from a line the user pastes.
- **The user's decisions** come in the invocation or are typed later: "approve the plan", "ESC-2: option B", "accept M2", "defer F4 to M3", "allow one more round on M2". Record each one straight away, unless the Decision log already has it (a restart):
  - add `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")` to the Decision log in `plan.md` (before it exists, `dev-analyse` puts answers in `analysis.md`). Approving the plan, or accepting a milestone or the feature, also changes `Accepted:` or Progress, as `dev-plan`'s "Gate 1" and `dev-status`'s `gates.md` say;
  - mention it in your next `log.md` row, and commit it with your step. If your step has already finished, or stops before Finish, add a row with step `decision`, and commit it with the decision straight away, as `<slug>: decision <ref>` or the message your role gives for it (such as `<slug> Mx: accepted`).

  Then act on it only as far as your role allows.
- **Escalations.** Their IDs run `ESC-1`, `ESC-2`, … across the whole feature: take the number after the highest `ESC-` anywhere in the feature folder. Each states the question, the options and your recommendation in about 5 lines, and stays open until the Decision log has an entry for it.
- **Your own calls.** Every choice you make that the user didn't (one reading of an ambiguity, a small deviation from the plan) goes under "Calls I made" in your handoff, response or review.
- **Quick and full checks.** The *full checks* are the commands on Checks' Full line; if Checks has a Slow line, they also take the target's own test files (those the milestone added or changed, slow tests included) on a milestone, and the Slow line at `final` (on a medium plan, which has no `final`, at its last milestone). The *quick checks* are the test files that cover what you changed, plus the quick command in Checks if it names one. Work with quick checks. A gate always rests on a full run, run or cited. When your role runs the full checks, run them once, after your last change to code or tests, and save them: redirect each command's output straight into `runs/<YYYY-MM-DD-HHMM>-<step>-<short hash>.txt` in the feature folder as it runs (`<command> > <file> 2>&1`, then `>>`; in Windows PowerShell, inside `cmd /c "..."`), so a lost capture never costs a second run. Then add a header at the top: the commit, each command, how long it took and its result. If the output is very long, keep its summary and every failure. Name the file in your handoff, response or review, and in your `log.md` row.

### Finish

1. **Commit your work** with the message your role gives, before you run the full checks, so that a saved run names a commit holding exactly what was tested. If a check fails and you fix something, commit again and rerun. Never push, amend, rebase or merge.
2. **Log.** Append one row to `log.md`. If the file is missing, create it with the heading `# Log: <slug>` and this table header:

   ```
   | When | Session | Step | Result | Next |
   |---|---|---|---|---|
   ```

   - **When:** local time, as `YYYY-MM-DD HH:MM`.
   - **Session:** `<session name> (<vendor> <model>)`, for example `csv-import M2 review (Claude Opus 5.5)`. Your vendor is Claude in Claude Code and Codex in Codex. Add `, same vendor` when a check ran on the same vendor as the work it checks: plan-review against plan, Mx review against Mx build, final-review against the vendor that built most milestones, and Mx test against Mx build (the builder adds it).
   - **Step:** the skill and target, for example `dev-review M2` or `dev-build M2 (answers r1)`.
   - **Result:** the commit or range, the test result, the verdict, counts, and any new ESC IDs.
   - **Next:** the paste line or lines from your baton.
3. **Commit the records** (handoff, review, `plan.md`, your `runs/` files) with your log row, as `<slug> <step>: records`. When your step writes only records, that's its one commit. Then `git status --porcelain` must be empty, because the next step stops on a dirty tree: commit anything your step wrote in the feature folder, and restore any break of your own. Never commit anything else here: name it to the user, and say the tree isn't clean.
4. **Reply** in at most 8 lines, then end with the baton:

   ```
   Done: <slug> <step>. <commit, tests, verdict, what's open>.
   Next: <what>, in <a new session | the "<session name>" session> (<vendor>: <why>). Paste:
     <line or lines>
   ```

   | The next session is | Claude | Codex |
   |---|---|---|
   | New | `/dev-x <args>`. In a terminal: `claude -n "<session name>" "/dev-x <args>"` | `/rename <session name>`, then `$dev-x <args>` |
   | Already open | `/dev-x <args>` | `$dev-x <args>` |

   **Which vendor.** For a check (plan-review, Mx test, Mx review, final-review), suggest the vendor that didn't write what it checks, from `log.md`, "or a fresh `<same vendor>` session if `<other vendor>` has no capacity"; for Mx test, "the vendor that won't build Mx". For a writing step, the vendor the user last used for that kind of step. When the next step is the user's (a gate, or an escalation), say what to read or decide, and what to type in which session.
