# Analysis template

Copy everything below the line into `docs/work/<slug>/analysis.md` and fill it in. Keep the section names, because `dev-plan` and the plan review look for them. Delete the guidance in *italics*. Aim for a page: the plan holds the detail, and writes the requirements.

---

# Analysis: <slug>

Version: v1 (<YYYY-MM-DD>)
Branch: `work/<slug>`, from `<branch>` at `<commit>`

## The question

*The user's question or idea, in their own words, exactly as first given. Never edit it later; answers and changes go below.*

## What I found

*The answer to the question, and how the code works today, in a few lines with `file:line`; then why it calls for a change.*

## What and why

*Two to four sentences: who uses it, what they do with the result, and what success looks like to them.*

## Non-goals

- *What this feature deliberately won't do, and anything that would make it a failure even if it technically works.*

## Facts

*The facts about the data and the existing code that a number will depend on. Write "none" if no number depends on one.*

- *<fact>: <source: `file:line`, a sample you looked at (file and row), or the user (Q-n)>*
- *<fact>: `unverified`, <why neither the code nor the data can tell>*

## Decisions

*Every answer the user gave, one line each, by question number, with the date it was given. A default they accepted counts as theirs.*

- **Q-1** (<YYYY-MM-DD>) *<question>*: *<answer>* (you)
- **Q-2** (<YYYY-MM-DD>) *<question>*: *<recommended answer>* (your default)

## Approach

*Only when there was a real choice: each option in one line, which one was chosen (Q-n), and why. Otherwise: "One obvious approach: <it>".*

## Examples

*The user's own cases and figures, and any you proposed and they confirmed. Write "none" if nothing here is a number.*

| Input | Expected | Source |
|---|---|---|
| *file A (120 trades), imported twice* | *120 rows in positions* | *the user (Q-3)* |

## Left to the planner

- *What the analysis deliberately doesn't settle: milestones, names, file layout, …*

## Calls I made

- *Each choice you made that the user didn't, including the minor points from the planner check. "none" if none.*

## Planner check

- *Each question the cold read asked, and where its answer went: "answered: <section>", "my call: <call>", or "Q-n".*
