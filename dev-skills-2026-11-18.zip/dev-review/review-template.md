# Review templates

A review file holds one thread: `review-plan.md`, `review-Mx.md` or `review-final.md`. The file starts with `# Review: <slug> <target>`, and each round is appended below the last one. Never edit an earlier round (completing a `pending` round isn't editing one). Delete the guidance in *italics*, but keep every heading and field, writing "none" where one is empty.

## A first review (or a fresh one)

```
## Review r<N> · <YYYY-MM-DD> · "<session name>" (<vendor> <model>)
*If another session finished pass 2, add after the header line:* pass 2: "<session name>" (<vendor> <model>)
Target: plan v<N> | Mx | the whole branch
Reviewed: <base>..<head>   (tests: <a>..<b>; build: <b>..<c>)
Plan: v<N>; ACs: AC-…
Checks: <command> → <result>; <command> → <result>. ran: `runs/<file>` (not cited: `runs/<earlier file>`, because <reason>) | cited: `runs/<file>` (commit <hash>, matches the handoff: yes | no → F<n>)
Compare: *milestones with a `Compare:` line only.* <base>..<head> → identical | <N> differences → F<n>. cited: `runs/<file>` (commit <hash>) | ran: `runs/<file>`. A break showed a difference: yes | no → F<n>
Anchor: *milestones with anchor tests only.* <test> checked against <document, page> → matches | TD-<n> | F<n> (the plan has it wrong too) | not checked (<why>)

### AC trace
*Milestone and final reviews only.*

| AC | Acceptance tests | What I broke → which test failed (one break per AC with tests, at most 10, on `independent` milestones or where the plan asks; otherwise —) | Met? |
|---|---|---|---|
| AC-4 | test_ac4_reimport_adds_nothing | removed the dedup step → test_ac4 failed | yes |

### Tests
- Acceptance tests unchanged since their commit: yes | the changes, and the ESC or TD reference for each
- Changed or weakened tests listed in the handoff, and checked: none | …
- Bad-test patterns: none | …
- Repeated tests (`final` only): none | *the acceptance test → the test that repeats its proof, and a break that fails both*

### TEST DISPUTE rulings
- TD-1: the plan shows the test is wrong. Plan, AC-5 example 2: "<quote>". Corrected expectation: `<exact value>`.
- TD-2: the plan shows the code is wrong → F3.
- TD-3: the plan doesn't settle it → ESC-6, below.
- TD-4: anchor figure. <document, page>: "<quote>". Corrected expectation: `<exact value>` (and F5, if its test passed).

#### ESC-6 · <the question in short> (from TD-3)
- Question: <…>
- Options: A <…>; B <…>
- Recommended: A, because <…>

### Findings

#### F1 · P1 · demonstrated · <short title>
- Where: `path/to/file.py:88`
- Trigger → consequence: <input or state> → <what goes wrong>
- Evidence: <a failing command, a test, a code path>
- Smallest fix: <…>   *(if it needs a plan change the builder may not make: say so, with the options and your recommendation; the builder escalates it)*

### Declined to judge
- none | *one line each: a behaviour you considered and set aside as outside the plan, and why. Only what a reasonable user wouldn't rely on; anything they would expect is a finding.*

### Calls I made
- *Choices you made that the user didn't.*

### Not checked
- *What you couldn't run or verify, and why.*

### Found outside this change
- none | *one line each: where, the trigger, and what goes wrong. Defects in code this target doesn't change, that would be P0–P2 had it made them. They block nothing.*

### For the user
*Milestone rounds with verdict READY only. See "READY on a milestone" in the skill.*
- Needs your call: none | *what happened, what it risks, and the question*
- Worth a glance: none | *at most 3 lines, each ending with what it costs if wrong, plus one line per "Not checked" item*
- Proof: *one short line each: every kill-check break → the test that failed; the output comparison's result, if any; every anchor: figure = value (source), test passes, the one you checked marked; the checks: the saved run → result; the AC trace, and the planned changes and approved decisions, with their references*
- Auto-accepted: yes | no, because *Tests: independent, a tier 1 item, an unchecked AC, the `Compare:` conditions not met, or the user asked to stop here or at every gate*

Verdict: READY | CHANGES REQUIRED | NEEDS OWNER DECISION | REVIEW INCOMPLETE   *(a milestone first or fresh review reads `pending` between pass 1 and pass 2)*
Open: F1 (P1), ESC-6, … or "none"
Next: <the baton's paste line>
```

A plan review leaves out the Compare line and the AC trace, Tests and TEST DISPUTE rulings sections, and its `Reviewed:` line names the commit that holds `plan.md`.

## A recheck

```
## Recheck r<N> · <YYYY-MM-DD> · "<session name>" (<vendor> <model>)
Reviewed: <last reviewed head>..<pinned HEAD>
Response: r<N>, fixes <the Fixes range from it> | none (stale READY)
Plan: v<N>, at the pinned HEAD; ACs: AC-…
Checks: <command> → <result>. ran: `runs/<file>` (not cited: `runs/<earlier file>`, because <reason>) | cited: `runs/<file>` (commit <hash>) | none (plan recheck)
Compare: *milestones with a `Compare:` line whose fix changed production code, or the `Compare:` input or command.* identical | <N> differences → F<n>. cited: `runs/<file>` (commit <hash>) | ran: `runs/<file>`. Break run repeated (the input or command changed): yes | not needed
Round: recheck <n> of 2 | recheck 1 of 1 after the fresh review | after the budget, for <the user's decision>

| Item | Status | Evidence |
|---|---|---|
| F1 | VERIFIED | test_x fails before the fix (assert 240 == 120) and passes after |
| F2 | WITHDRAWN | importer.py:88 skips those rows; I ran it with <input> |
| F6 | DOWNGRADED | real, but both readings give the same totals; now a P3 note |
| F3 | ESCALATED | ESC-5. My view: option A, because … |
| F4 | STILL OPEN | the fix handles the example but not <trigger> |
| F5 | DEFERRED | Decision log, 2026-10-11 |
| TD-1 | VERIFIED | applied exactly as ruled |

### New findings
*Same format as in a first review. The numbering continues. Each one is caused by the fix, is P0 or P1, or is a P2 with evidence from this round (say what was missed).*

### Calls I made

### Not checked

### Found outside this change

### For the user
*Verdict READY on a milestone only. Same fields as in a first review.*

Verdict: READY | CHANGES REQUIRED | NEEDS OWNER DECISION | REVIEW INCOMPLETE | HAND OFF
Open: …
Next: …
```

When the verdict is NEEDS OWNER DECISION because the round budget was used up, add one block for each open item:

```
#### Still open: F4 → ESC-7
- The reviewer's claim, and its evidence: …
- The author's claim, and its evidence: …
- The smallest experiment that would settle it: …
```

When the verdict is HAND OFF, add one line saying which rule triggered it: a finding withdrawn on a money or data path, or a large or contract-changing code fix you couldn't re-verify (say what you couldn't verify).
