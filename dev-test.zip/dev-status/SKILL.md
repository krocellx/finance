---
name: dev-status
description: "The user's console in the dev-* workflow. Shows where a feature stands and what needs the user, from the feature's files and git; records the user's decisions, including accepting a milestone (gate 2) or the feature (gate 3). Use only when the user invokes it by name."
argument-hint: "[slug] [decision]"
disable-model-invocation: true
---

# dev-status: the user's console

You show the user where a feature stands, and what needs them, using only the files and git. You never change code, tests or reviews. You run no checks. You write only the user's decisions. Your step is `status`.

## Work out your job

- **No slug:** list each folder in `docs/work/`, one line each: the slug, and the last row of its `log.md`. Stop.
- **A slug:** show the [status](#the-status). If the user gave a decision in the invocation or types one afterwards, [record it](#decisions). If the tree isn't clean, show the status, but don't record decisions until it is.

## The status

Read `log.md`, `plan.md`, every `review-*.md` and `handoff-*.md` in the feature folder, and git (the branch, `git status --porcelain`, `HEAD`, and whether the commits in `log.md` exist). Keep the whole reply to about 25 lines:

```
<slug> · plan v<N>, accepted <date> (or "draft") · work/<slug> @ <short hash>, clean
| Milestone | Tests | State | Latest |
|---|---|---|---|
| M1 | builder | accepted 10-09 | |
| M2 | independent | CHANGES REQUIRED, recheck 1 of 2 | F2 (P1) open |
| M3 | independent | planned | |

Needs you:
1. ESC-3 (review-M2.md, F3): <the question>. Options A and B; recommended: B.
2. Same vendor: the M2 review was Claude, checking Claude's build.

Next: <the last log row's Next>
```

Under "Needs you", list everything that waits on the user. Write "nothing" if there's none.

- Open escalations: an `ESC-n` anywhere in the folder with no Decision log entry.
- A gate that's ready (below).
- Checks that ran on the same vendor as the work they checked (the log marks them).
- REVIEW INCOMPLETE verdicts.
- Problems with the record: a dirty tree, the wrong branch, a commit named in `log.md` that git doesn't have, a Progress state that disagrees with the latest review. Report them; don't fix them.

## Gate views

When a gate is ready, add its reading list below the status, with links to the files. First check that the READY round still covers the current state ([Every step](#every-step), "What a review covers"). If it's stale, say what changed, show no gate view, and make the baton the same `dev-review` line again.

**Gate 1, the plan.** The plan isn't accepted yet, and either its latest review is READY or it's a medium plan (which has no review). List:

- the Goal and Non-goals;
- each AC with its worked examples, marking those that came from the planner and need confirming;
- the milestones, with each `Tests:` mark and its reason;
- the open escalations.

Then: type `approve the plan`, in the `<slug> plan` session or here.

**Gate 2, a milestone.** Its latest review is READY, and it isn't accepted yet. List:

- the reviewer's AC trace table;
- every finding marked WITHDRAWN, ESCALATED or DEFERRED, with its reason;
- every TEST DISPUTE and its ruling;
- every change to an acceptance test, and every weakened test, from the handoff;
- the "Calls I made" from the test author, the builder and the reviewer;
- on `independent` milestones, the names of the acceptance tests, which read as the spec;
- any same-vendor checks.

Then: type `accept Mx`, or say what's wrong.

**Gate 3, the feature.** `review-final.md` is READY. List:

- the commands it gives for one normal case and one failure case, for the user to run;
- anything still deferred.

Then: type `accept the feature`.

## Decisions

Record each decision as [Every step](#every-step) says, with these additions:

- **`accept Mx`:**
  - If the latest review of Mx isn't READY, or its READY is stale, say what's open or what changed, and ask the user once to confirm, with a reason that goes in the Decision log.
  - Set the milestone's Progress row to `accepted <date>`, and commit as `<slug> Mx: accepted`.
  - The baton is the next milestone in the plan:
    - an `independent` milestone: `dev-test <slug> M<next>`, in a new session from the vendor that won't build it;
    - a `builder` milestone: `dev-build <slug> M<next>`, in a new session.
  - After the last milestone, the baton is `dev-review <slug> final`, in a new session, ideally from the vendor that built least. A medium plan has no final review, so the user goes straight to gate 3: tell them how to try the feature, then to type `accept the feature`.
  - Remind the user they can archive the `Mx build`, `Mx test` and `Mx review` sessions.
- **`approve the plan`:**
  - If the latest plan review isn't READY or is for an older plan version (on a full plan), an escalation is still open, or a `(planner; confirm at gate 1)` example hasn't been confirmed, list it, and ask the user once to confirm, with a reason.
  - Set `Accepted: v<N> <date>` at the top of `plan.md`, and every Progress row to `planned`. Commit as `<slug>: plan v<N> accepted`.
  - The baton is the first milestone, as for `accept Mx` below.
- **`accept the feature`:**
  - If `review-final.md` isn't READY, or its READY is stale, ask the user once to confirm, with a reason. A medium plan has no final review, and needs none.
  - Add a Progress row `Feature | accepted | <date>`, and commit as `<slug>: feature accepted`.
  - The baton gives the merge commands for the user to run themselves, for example `git switch <base branch>` and then `git merge --no-ff work/<slug>`, and reminds them to archive the remaining sessions. Never merge or push yourself.
- **Anything else** ("ESC-2: option B", "defer F4 to M3", "allow one more round on M2"): record it. The baton is whatever was next before the decision, unless the decision changes that. For example, a decision that changes an AC sends the user to `dev-plan <slug>` to amend the plan.

## Every step

*This section is the same in all five `dev-*` skills. Change all five together.*

### Start

1. **Read the invocation.** It gives the feature slug, then the target if this skill takes one (`plan`, `M2`, `final`). Anything after that is the user's: a requirement, a decision, or extra focus. The feature's files are in `docs/work/<slug>/`, unless `AGENTS.md` names another place.
2. **Read `AGENTS.md`** for the test, lint and type-check commands. If it gives no test command, ask the user for it. Don't guess.
3. **Check git.** The project must be a git repository.
   - Work on branch `work/<slug>`. Only `dev-plan` creates it. If you're on another branch and the tree is clean, switch to it.
   - Run `git status --porcelain`. If there are uncommitted changes you didn't make in this session, never stash, commit or discard them yourself. (`dev-status` only reports them.)
     - **If they look like an interrupted run of your own step** (the files your step writes, for the same target, and no `log.md` row for that run yet): show the user `git status` and a short summary of the diff, and ask whether to carry on from them. If they agree, adopt them and say so under "Calls I made". If they don't, stop.
     - **Otherwise:** stop, and tell the user which step the changes seem to come from. Rerunning that step, in a fresh session if need be, will offer to carry on from them. Or the user can commit or discard them.
4. **Read `log.md`** in the feature folder, if it exists. Its last row is where things stand.
5. **Name the session**, if nothing else has been done in it yet. Use the name from the table below. If you have a tool that renames the current session (in the Claude desktop app, `set_session_title` with session id `self`), use it. Then file the session under the sidebar group named `<slug>`: list the groups first, and create the group only if it's missing. If you have no such tool, skip this step, because the user names the session.

| Step | Session name |
|---|---|
| `dev-plan` | `<slug> plan` |
| `dev-review plan` | `<slug> plan-review` |
| `dev-test Mx` | `<slug> Mx test` |
| `dev-build Mx` | `<slug> Mx build` |
| `dev-review Mx` | `<slug> Mx review` |
| `dev-review final` | `<slug> final-review` |
| `dev-build final` | `<slug> final-fix` |
| `dev-status` | `<slug> status` |

### While you work

- **One role.** You may use subagents for your own work, such as searching the code or probing several risks at once. Never start another role, either as a subagent or by messaging another session. Each role starts from a line the user pastes.
- **The user's decisions.** The user may give one in the invocation, or type it later in plain words: "approve the plan", "ESC-2: option B", "accept M2", "defer F4 to M3", "allow one more round on M2". Record it straight away:
  - add `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")` to the Decision log in `plan.md`;
  - approving the plan also sets its `Accepted:` line, and accepting a milestone or the feature also updates Progress (`dev-plan` and `dev-status` give the details);
  - mention it in your next `log.md` row, and commit it with your step. If you've already finished (for example, the user typed it after your baton), add a row with step `decision` and commit straight away, as `<slug>: decision <ref>`.

  Then act on the decision only as far as your role allows.
- **What a review covers.** A review covers the code and tests at its `Reviewed:` head, and the plan version it names. If a round names no plan version, use the `Version:` line of `plan.md` at its `Reviewed:` head (`git show <head>:<path to plan.md>`). Later commits that touch only the feature folder's records leave it valid. Any other change (code, tests, configuration) or a new plan version makes it stale, and it must be reviewed again before a gate relies on it. To check, run `git diff --name-only <reviewed head> HEAD` and compare the plan's `Version:` line.
- **Escalations.** Their IDs run `ESC-1`, `ESC-2`, … across the whole feature: take the number after the highest `ESC-` anywhere in the feature folder. Each one states the question, the options and your recommendation. It stays open until the Decision log has an entry for it.
- **Your own calls.** Every choice you make that the user didn't goes under "Calls I made" in your handoff, response or review. Examples: picking one reading of an ambiguity, a small deviation from the plan, leaving a P3 unfixed.

### Finish

1. **Checks.** Run the full checks from `AGENTS.md` once, unless your role says otherwise. Note each command and its result.
2. **Commit.** Commit your work first, with the message your role gives. Then update your records (handoff, review, `plan.md`, `log.md`) citing that commit, and commit them as `<slug> <step>: records`. When your step writes only records, one commit is enough. Never push, amend, rebase or merge. The tree must be clean when you stop.
3. **Log.** Append one row to `log.md`. If the file is missing, create it with the heading `# Log: <slug>` and this table header:

   ```
   | When | Session | Step | Result | Next |
   |---|---|---|---|---|
   ```

   - **When:** local time, as `YYYY-MM-DD HH:MM`.
   - **Session:** `<session name> (<vendor> <model>)`, for example `csv-import M2 review (Claude Opus 5.5)`. Your vendor is Claude when you run in Claude Code, and Codex when you run in Codex. Add `, same vendor` when a check ran on the same vendor as the work it checks:
     - plan-review against plan;
     - Mx test against Mx build (the builder adds it);
     - Mx review against Mx build;
     - final-review against the vendor that built most milestones.
   - **Step:** the skill and target, for example `dev-review M2` or `dev-build M2 (answers r1)`.
   - **Result:** the commit or commit range, the test result, the verdict, counts, and any new ESC IDs.
   - **Next:** the paste line or lines from your baton.
4. **Reply** in at most 8 lines, then end with the baton:

   ```
   Done: <slug> <step>. <commit, tests, verdict, what's open>.
   Next: <what>, in <a new session | the "<session name>" session> (<vendor>: <why>). Paste:
     <line or lines>
   ```

   | The next session is | Claude | Codex |
   |---|---|---|
   | New | `/dev-x <args>`. In a terminal: `claude -n "<session name>" "/dev-x <args>"` | `/rename <session name>`, then `$dev-x <args>` |
   | Already open | `/dev-x <args>` | `$dev-x <args>` |

   **Which vendor to suggest.** For a check (plan-review, Mx test, Mx review, final-review), suggest the vendor that didn't write what it checks, using `log.md`. Add "or a fresh `<same vendor>` session if `<other vendor>` has no capacity". For Mx test the builder isn't known yet, so say "the vendor that won't build Mx". For a writing step, suggest the vendor the user last used for that kind of step. The user can always override the suggestion.

   When the next step is the user's (a gate, or an escalation to decide), the baton says what to read or decide, and what to type in which session.

**Restarted?** If the files show your step has already finished, for example after a crash, don't redo it. Print the baton again.
