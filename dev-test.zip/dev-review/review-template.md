# Review templates

A review file holds one thread: `review-plan.md`, `review-Mx.md` or `review-final.md`. The file starts with `# Review: <slug> <target>`, and each round is appended below the last one. Never edit an earlier round. Delete the guidance in *italics*, but keep every heading and field, writing "none" where one is empty.

## A first review (or a fresh one)

```
## Review r<N> · <YYYY-MM-DD> · "<session name>" (<vendor> <model>)
Target: plan v<N> | Mx | the whole branch
Reviewed: <base>..<head>   (tests: <a>..<b>; build: <b>..<c>)
Plan: v<N>; ACs: AC-…
Checks: <command> → <result>; <command> → <result>

### AC trace
*Milestone and final reviews only.*

| AC | Acceptance tests | What I broke → which test failed | Met? |
|---|---|---|---|
| AC-4 | test_ac4_reimport_adds_nothing | removed the dedup step → test_ac4 failed | yes |

### Tests
- Acceptance tests unchanged since their commit: yes | the changes, and the ESC or TD reference for each
- Changed or weakened tests listed in the handoff, and checked: none | …
- Bad-test patterns: none | …

### TEST DISPUTE rulings
- TD-1: the plan shows the test is wrong. Plan, AC-5 example 2: "<quote>". Corrected expectation: `<exact value>`.
- TD-2: the plan shows the code is wrong → F3.
- TD-3: the plan doesn't settle it → ESC-6.

### Findings

#### F1 · P1 · demonstrated · <short title>
- Where: `path/to/file.py:88`
- Trigger → consequence: <input or state> → <what goes wrong>
- Evidence: <a failing command, a test, a code path>
- Smallest fix: <…>

### Calls I made
- *Choices you made that the user didn't.*

### Not checked
- *What you couldn't run or verify, and why.*

Verdict: READY | CHANGES REQUIRED | NEEDS OWNER DECISION | REVIEW INCOMPLETE
Open: F1 (P1), ESC-6, … or "none"
Next: <the baton's paste line>
```

A plan review leaves out the AC trace, Tests and TEST DISPUTE rulings sections, and its `Reviewed:` line names the commit that holds `plan.md`.

## A recheck

```
## Recheck r<N> · <YYYY-MM-DD> · "<session name>" (<vendor> <model>)
Reviewed: <last reviewed head>..<pinned HEAD>
Response: r<N>, fixes <the Fixes range from it> | none (stale READY)
Plan: v<N>, at the pinned HEAD; ACs: AC-…
Checks: <command> → <result>
Round: recheck <n> of 2

| Item | Status | Evidence |
|---|---|---|
| F1 | VERIFIED | test_x fails before the fix (assert 240 == 120) and passes after |
| F2 | WITHDRAWN | importer.py:88 skips those rows; I ran it with <input> |
| F3 | ESCALATED | ESC-5. My view: option A, because … |
| F4 | STILL OPEN | the fix handles the example but not <trigger> |
| F5 | DEFERRED | Decision log, 2026-10-11 |
| TD-1 | VERIFIED | applied exactly as ruled |

### New findings in the fix diff
*Same format as in a first review. The numbering continues.*

### Calls I made

Verdict: READY | CHANGES REQUIRED | NEEDS OWNER DECISION | REVIEW INCOMPLETE | HAND OFF
Open: …
Next: …
```

When the verdict is NEEDS OWNER DECISION because the round limit was reached, add one block for each open item:

```
#### Still open: F4 → ESC-7
- The reviewer's claim, and its evidence: …
- The author's claim, and its evidence: …
- The smallest experiment that would settle it: …
```

When the verdict is HAND OFF, add one line saying which rule triggered it: a large fix, a redesign, or a finding withdrawn on a money or data path.
