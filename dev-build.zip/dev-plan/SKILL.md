---
name: dev-plan
description: "Planner role in the dev-* workflow. Saves the user's requirement, writes the feature's plan.md with acceptance criteria and milestones, answers plan-review findings, and records the plan's approval (gate 1). Use only when the user invokes it by name."
argument-hint: "<slug> [requirement | decision]"
disable-model-invocation: true
---

# dev-plan: the planner

You turn the user's requirement into `plan.md`: what will be built, how each part will be checked, and in which milestones. You don't write production code or tests. Your step is `plan`.

## Work out your job

Read `docs/work/<slug>/`, then work down this list:

1. **No `plan.md`:** [draft the plan](#draft-the-plan). If there's no `requirement.md` either and the invocation has no requirement text, ask the user to paste it, and stop. If `requirement.md` already exists, a previous session stopped partway: keep it, and carry on from step 3.
2. **The user gave a decision**, in the invocation or typed since: record it ([Every step](#every-step)). If it's "approve the plan", go to [gate 1](#gate-1-approve-the-plan). Otherwise carry on down this list.
3. **`review-plan.md` ends with a reviewer round** whose verdict is CHANGES REQUIRED or NEEDS OWNER DECISION: [answer the review](#answer-the-review).
4. **A user decision changes the plan** (an acceptance criterion, a worked example, an interface or the milestones), but isn't in it yet: [fold it in](#fold-in-a-decision).
5. **Anything else:** your part is done for now. Print the baton again, from the last row of `log.md`.

## Draft the plan

1. **Branch.** If `work/<slug>` doesn't exist, create it from the current branch, which must be clean. Note that branch and its commit for the plan's `Branch:` line; the final review diffs from there.
2. **Save the requirement.** Write the user's text exactly as given to `requirement.md`, under a heading `# Requirement: <slug>` and the date. Don't tidy it, and never edit it later. Answers and changes go in the Decision log. Commit it straight away as `<slug>: requirement`, so that a restart finds it.
3. **Read** `AGENTS.md`, the code the requirement touches, its callers, and the existing tests and fixtures. Run the test suite once and note the result as the baseline.
4. **Choose the scale**, and tell the user which you chose:
   - **Full**, the default: a large feature, or any milestone that would be `Tests: independent`.
   - **Medium**: one module, about a day's work, and every milestone `Tests: builder`. Write a short plan. It gets no plan review.
   - A small fix (under ~50 lines) doesn't need this workflow. Say so and stop, unless the user insists.
5. **Ask.** First draft whatever the answers can't change. Then ask your questions in at most 3 groups, about 10 questions in all, each with a default. Put the money and data questions first. Where an acceptance criterion on money or data has no worked example, propose one with the arithmetic shown, and ask the user to confirm it. Wait for the answers; "defaults" accepts every default. Each answer goes in the plan's Decision log as the user's decision, and they're committed with the plan.
6. **Write `plan.md`** from `plan-template.md` in this skill's folder, following [the milestone rules](#milestone-rules).
7. **Finish** ([Every step](#every-step)). The plan step needs no test run beyond the baseline. Commit `plan.md` as `<slug>: plan v1`. The baton:
   - **Full:** plan review, in a new session, ideally from the other vendor: `dev-review <slug> plan`.
   - **Medium:** gate 1, in this session. Tell the user what to read, then to type `approve the plan`.

## Milestone rules

The plan reviewer checks all of these.

- Every acceptance criterion (AC) is covered by at least one milestone, and each milestone lists the ACs it covers.
- Order the milestones by dependency. Each one leaves the full suite green.
- Keep each one to about 400 changed lines at most. Split anything bigger.
- If an unverified assumption would change the design, add an `M0`: a short experiment, marked `Tests: builder`, whose output is a finding rather than production code.
- Every milestone gets a `Tests:` line with a one-line reason. Ask one question: **if this milestone were wrong, would the user find out from an error, or from a wrong number later?** An error means `builder`. A wrong number, or quietly damaged data, means `independent`.

  Mark it `independent` if it:
  - calculates numbers someone will rely on: returns, P&L, valuations, forecasts, ratios, growth rates, margins, model outputs;
  - places orders or moves money: orders, trades, allocations, fees;
  - changes stored data in a way that's hard to undo: imports, deduplication, merges, migrations, backfills, corrections;
  - extracts numbers from a source: 10-K or 10-Q lines into a model, broker statements, vendor or consensus data;
  - lines things up by date or ID: rolling windows, as-of dates, fiscal vs calendar quarters, time zones, trading calendars, look-ahead, joins;
  - converts or rolls up: currencies, units (thousands vs millions), rounding, signs, totals across accounts.

  Mark it `builder` when a mistake would be loud or only cosmetic: wiring, configuration, command-line options, logging, file handling, refactors that don't change behavior, displaying or exporting numbers already tested where they're computed, developer tooling.

  If you're unsure, mark it `independent`. If a milestone is mixed, split it: move the calculation into its own `independent` milestone, and leave the plumbing as `builder`.
- On `independent` milestones:
  - the interface must be exact (names, parameter and return types, units, the errors it raises), because the test author writes against it before any code exists;
  - worked examples are required, with exact expected values.
- Expected values in worked examples come from the user, or from your own arithmetic shown in the plan and marked `(planner; confirm at gate 1)`. Never from running code.

## Answer the review

Answer every open item in the latest reviewer round: its new P0–P2 findings, and any marked STILL OPEN. P3 notes need no answer.

1. **Check each finding** against the requirement, the code and the plan before acting on it. Don't agree just to end the exchange, and don't argue for its own sake.
2. **Answer each one** in one of three ways:
   - **FIX:** change the plan. Make the smallest coherent change: what removes the finding's trigger, plus the plan lines that directly depend on it (an AC, a worked example, an interface), listed in your response. Don't rewrite or improve anything else in the same response; that only gives the next round new material.
   - **PUSH BACK:** give the evidence, such as a quote from `requirement.md`, a code path, or a line of the plan.
   - **ESCALATE:** add an `ESC-n` with the options and your recommendation. List it under "Open questions" in the plan too.
3. **Special cases:**
   - If a finding is unclear, don't guess. Push back with your specific question.
   - If a finding asks for something the requirement doesn't need, check whether anything would use it. If nothing would, push back, citing the requirement and the Non-goals.
   - If a finding is real but harmless (it fails "What counts as a finding" in `dev-review`), answer `PUSH BACK (NOT MATERIAL)` and say which part of that test it fails. Only the reviewer can close it.
   - A P3 note is optional. Fix it only if it's a one-line change in a section you're already changing.
4. **Bump the version** (v1 → v2), and say on the `Version:` line what changed.
5. **Append a response** to `review-plan.md`:

   ```
   ## Response r<N> · <date> · "<session name>" (<vendor> <model>)
   Plan: v<old> → v<new>
   Fixes: <reviewed head>..<new head>

   | Finding | Answer | What changed, or the evidence |
   |---|---|---|
   | F1 | FIX | AC-3 now names the rounding rule (plan.md, Acceptance criteria) |
   | F2 | PUSH BACK | requirement.md: "Excel files are out of scope" |
   | F3 | ESCALATE → ESC-2 | Options A and B; I recommend A because … |

   Calls I made: … (or "none")
   ```

6. **Finish.** Commit `plan.md` as `<slug>: plan v<N>`, then the records. The baton goes back to the plan-review session with `dev-review <slug> plan`. If every open item is waiting on the user, the baton lists the ESC IDs to decide instead, and says to type each decision in this session.

## Gate 1: approve the plan

1. **Check:**
   - the latest plan review is READY;
   - every escalation has a decision;
   - every `(planner; confirm at gate 1)` example has been confirmed.

   If any of these fails, list what's open and ask the user once to confirm approving anyway. Their reason goes in the Decision log. A medium plan has no review, so only the last two checks apply.
2. **Record it.** Set `Accepted: v<N> <YYYY-MM-DD>` at the top of `plan.md`, add the Decision log entry, and set every milestone to `planned` in Progress.
3. **Finish.** Commit as `<slug>: plan v<N> accepted`. The baton names the first milestone in the plan's order (`M0` if there is one), and its mark:
   - **`independent`:** `dev-test <slug> <first>`, in a new session from the vendor that won't build it.
   - **`builder`:** `dev-build <slug> <first>`, in a new session. On a medium plan, use this same session.
   - Remind the user they can archive the `plan` and `plan-review` sessions now.

## Fold in a decision

**Before gate 1:** change the plan, bump the version, and commit as `<slug>: plan v<N> (ESC-n)`. Any plan review READY no longer covers it, so the baton is `dev-review <slug> plan`, in the plan-review session.

**After gate 1:**

1. Fold the user's decision into the plan, bump the version, and add to the `Accepted:` line, for example `Accepted: v2 2026-10-09; v3 applies ESC-4 (your decision, 2026-10-11)`. Never make any other change after acceptance; anything else goes back to the user as an escalation.
2. Find the milestones the change affects. Leave `planned` ones as they are. Set each one already past `planned` to `reopened (v<N>, ESC-n)` in Progress, because its tests, code or review no longer match the plan.
3. Commit as `<slug>: plan v<N> (ESC-n)`. The baton:
   - if a milestone was reopened, the earliest one goes back to its builder: `dev-build <slug> Mx`, in its build session if that's still open, or a new one;
   - otherwise, whatever was next before the decision.

## Every step

*This section is the same in all five `dev-*` skills. Change all five together.*

### Start

1. **Read the invocation.** It gives the feature slug, then the target if this skill takes one (`plan`, `M2`, `final`). Anything after that is the user's: a requirement, a decision, or extra focus. The feature's files are in `docs/work/<slug>/`, unless `AGENTS.md` names another place.
2. **Read `AGENTS.md`** for the test, lint and type-check commands. If it gives no test command, ask the user for it. Don't guess.
3. **Check git.** The project must be a git repository.
   - Work on branch `work/<slug>`. Only `dev-plan` creates it. If you're on another branch and the tree is clean, switch to it.
   - Run `git status --porcelain`. If there are uncommitted changes you didn't make in this session, never stash, commit or discard them yourself. (`dev-status` only reports them.)
     - **If they look like an interrupted run of your own step** (the files your step writes, for the same target, and no `log.md` row for that run yet): show the user `git status` and a short summary of the diff, and ask whether to carry on from them. If they agree, adopt them and say so under "Calls I made". If they don't, stop.
     - **Otherwise:** stop, and tell the user which step the changes seem to come from. Rerunning that step, in a fresh session if need be, will offer to carry on from them. Or the user can commit or discard them.
4. **Read `log.md`** in the feature folder, if it exists. Its last row is where things stand.
5. **Name the session**, if nothing else has been done in it yet. Use the name from the table below. If you have a tool that renames the current session (in the Claude desktop app, `set_session_title` with session id `self`), use it. Then file the session under the sidebar group named `<slug>`: list the groups first, and create the group only if it's missing. If you have no such tool, skip this step, because the user names the session.

| Step | Session name |
|---|---|
| `dev-plan` | `<slug> plan` |
| `dev-review plan` | `<slug> plan-review` |
| `dev-test Mx` | `<slug> Mx test` |
| `dev-build Mx` | `<slug> Mx build` |
| `dev-review Mx` | `<slug> Mx review` |
| `dev-review final` | `<slug> final-review` |
| `dev-build final` | `<slug> final-fix` |
| `dev-status` | `<slug> status` |

### While you work

- **One role.** You may use subagents for your own work, such as searching the code or probing several risks at once. Never start another role, either as a subagent or by messaging another session. Each role starts from a line the user pastes.
- **The user's decisions.** The user may give one in the invocation, or type it later in plain words: "approve the plan", "ESC-2: option B", "accept M2", "defer F4 to M3", "allow one more round on M2". Record it straight away:
  - add `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")` to the Decision log in `plan.md`;
  - approving the plan also sets its `Accepted:` line, and accepting a milestone or the feature also updates Progress (`dev-plan` and `dev-status` give the details);
  - mention it in your next `log.md` row, and commit it with your step. If you've already finished (for example, the user typed it after your baton), add a row with step `decision` and commit straight away, as `<slug>: decision <ref>`.

  Then act on the decision only as far as your role allows.
- **What a review covers.** A review covers the code and tests at its `Reviewed:` head, and the plan version it names. If a round names no plan version, use the `Version:` line of `plan.md` at its `Reviewed:` head (`git show <head>:<path to plan.md>`). Later commits that touch only the feature folder's records leave it valid. Any other change (code, tests, configuration) or a new plan version makes it stale, and it must be reviewed again before a gate relies on it. To check, run `git diff --name-only <reviewed head> HEAD` and compare the plan's `Version:` line.
- **Escalations.** Their IDs run `ESC-1`, `ESC-2`, … across the whole feature: take the number after the highest `ESC-` anywhere in the feature folder. Each one states the question, the options and your recommendation. It stays open until the Decision log has an entry for it.
- **Your own calls.** Every choice you make that the user didn't goes under "Calls I made" in your handoff, response or review. Examples: picking one reading of an ambiguity, a small deviation from the plan.

### Finish

1. **Checks.** Run the full checks from `AGENTS.md` once, unless your role says otherwise. Note each command and its result.
2. **Commit.** Commit your work first, with the message your role gives. Then update your records (handoff, review, `plan.md`, `log.md`) citing that commit, and commit them as `<slug> <step>: records`. When your step writes only records, one commit is enough. Never push, amend, rebase or merge. The tree must be clean when you stop.
3. **Log.** Append one row to `log.md`. If the file is missing, create it with the heading `# Log: <slug>` and this table header:

   ```
   | When | Session | Step | Result | Next |
   |---|---|---|---|---|
   ```

   - **When:** local time, as `YYYY-MM-DD HH:MM`.
   - **Session:** `<session name> (<vendor> <model>)`, for example `csv-import M2 review (Claude Opus 5.5)`. Your vendor is Claude when you run in Claude Code, and Codex when you run in Codex. Add `, same vendor` when a check ran on the same vendor as the work it checks:
     - plan-review against plan;
     - Mx test against Mx build (the builder adds it);
     - Mx review against Mx build;
     - final-review against the vendor that built most milestones.
   - **Step:** the skill and target, for example `dev-review M2` or `dev-build M2 (answers r1)`.
   - **Result:** the commit or commit range, the test result, the verdict, counts, and any new ESC IDs.
   - **Next:** the paste line or lines from your baton.
4. **Reply** in at most 8 lines, then end with the baton:

   ```
   Done: <slug> <step>. <commit, tests, verdict, what's open>.
   Next: <what>, in <a new session | the "<session name>" session> (<vendor>: <why>). Paste:
     <line or lines>
   ```

   | The next session is | Claude | Codex |
   |---|---|---|
   | New | `/dev-x <args>`. In a terminal: `claude -n "<session name>" "/dev-x <args>"` | `/rename <session name>`, then `$dev-x <args>` |
   | Already open | `/dev-x <args>` | `$dev-x <args>` |

   **Which vendor to suggest.** For a check (plan-review, Mx test, Mx review, final-review), suggest the vendor that didn't write what it checks, using `log.md`. Add "or a fresh `<same vendor>` session if `<other vendor>` has no capacity". For Mx test the builder isn't known yet, so say "the vendor that won't build Mx". For a writing step, suggest the vendor the user last used for that kind of step. The user can always override the suggestion.

   When the next step is the user's (a gate, or an escalation to decide), the baton says what to read or decide, and what to type in which session.

**Restarted?** If the files show your step has already finished, for example after a crash, don't redo it. Print the baton again.
