---
name: dev-plan
description: "Planner role in the dev-* workflow. Saves the user's requirement, writes the feature's plan.md with acceptance criteria and milestones, answers plan-review findings, and records the plan's approval (gate 1). Use only when the user invokes it by name."
argument-hint: "<slug> [requirement | decision]"
disable-model-invocation: true
---

# dev-plan: the planner

You turn the user's requirement into `plan.md`: what will be built, how each part will be checked, and in which milestones. You don't write production code or tests. Your step is `plan`.

## Work out your job

Read `docs/work/<slug>/`, then work down this list:

1. **No `plan.md`:** [draft the plan](#draft-the-plan). If there's no `requirement.md` either and the invocation has no requirement text, ask the user to paste it, and stop. If `requirement.md` already exists, a previous session stopped partway: keep it, and carry on from [Draft the plan](#draft-the-plan), step 3.
2. **The user gave a decision**, in the invocation or typed since: record it ([Every step](#every-step)). If it's "approve the plan", don't record it yet: go to [gate 1](#gate-1-approve-the-plan), which checks first and then records it in one commit. Otherwise carry on down this list.
3. **`review-plan.md` ends with a reviewer round** whose verdict is CHANGES REQUIRED or NEEDS OWNER DECISION: [answer the review](#answer-the-review).
4. **A user decision changes the plan** (an acceptance criterion, a worked example, an interface, the milestones, a fact the plan relies on, or the Checks section), but isn't in it yet and no `apply <ref>` commit carries it out: [fold it in](#fold-in-a-decision). A change to Checks makes reviews stale (`dev-review`'s "What a review covers"), so say so in the baton.
5. **Anything else:** your part is done for now. Print the baton again, from the last row of `log.md`.

## Draft the plan

1. **Branch.** If `work/<slug>` doesn't exist, create it from the current branch, which must be clean. Note that branch and its commit for the plan's `Branch:` line; the final review diffs from there.
2. **Save the requirement.** Write the user's text exactly as given to `requirement.md`, under a heading `# Requirement: <slug>` and the date. Don't tidy it, and never edit it later. Answers and changes go in the Decision log. Commit it straight away as `<slug>: requirement`, so that a restart finds it.
3. **Read** the project's instructions if it has any (`AGENTS.md`, `CLAUDE.md`, a README), the code the requirement touches, its callers, and the existing tests and fixtures.
   - **Work out the checks** from the project's own files: `package.json` scripts, `pyproject.toml`, `pytest.ini` or `setup.cfg`, a `Makefile`, the CI config, and those instructions. Include the lint and type-check commands if the project has them.
   - **Run each one once**, and note the result and how long it took. That's the baseline. Save its output as [Every step](#every-step) says ("Quick and full checks").
   - **If the baseline isn't green**, list each failing test in the Checks section under known failures. Ask in your first group of questions whether to fix them first, as their own small piece of work, or carry them. Later steps treat exactly those failures as expected; any other failure counts. If the user chooses to fix them first, delete any draft `plan.md`, commit your baseline `runs/` file as `<slug>: baseline`, then stop, telling the user the fix must reach `work/<slug>` before they rerun `dev-plan <slug>`: that fix is its own small piece of work, and this plan starts once the baseline is green.
   - **If you can't tell which command is right**, because there are several candidates or none, ask in your first group of questions. Don't guess.
   - **If the full checks take more than about 2 minutes**, also work out the quick checks: how to run a single test file, and a fast subset if the project has one (a unit-only script, a `not slow` marker).
   - **If they take more than about 2 minutes, also try running them in parallel** with what the project already has: Playwright workers, `node --test` (which runs files in parallel already), `pytest -n auto` if `pytest-xdist` is installed, or the runner's own option.
     - **Same results, and faster:** use the parallel command as the full checks, and note both run times.
     - **It needs a new dependency, or some tests fail only in parallel:** don't install or fix anything. Note in the plan's Checks section what's needed, which tests aren't isolated, and the likely speed-up. Then tell the user. Fixing old tests is its own small piece of work, not part of this feature.
   - **Write them all** in the plan's Checks section. Every later step reads its commands from there.
4. **Choose the scale**, and tell the user which you chose:
   - **Full**, the default: a large feature, or any milestone that would be `Tests: independent`.
   - **Medium**: one module, about a day's work, and every milestone `Tests: builder`. Write a short plan. It gets no plan review.
   - A small fix (under ~50 lines) doesn't need this workflow. Say so, commit your baseline `runs/` file as `<slug>: baseline`, and stop, unless the user insists.
5. **Ask.** First draft whatever the answers can't change. Then ask your questions in at most 3 groups, about 10 questions in all, each with a default. Put the money and data questions first, including the facts you couldn't check ([the milestone rules](#milestone-rules), "Facts the plan relies on"). Where an acceptance criterion on money or data has no worked example, propose one with the arithmetic shown, and ask the user to confirm it. Wait for the answers; "defaults" accepts every default. Each answer goes in the plan's Decision log as the user's decision, and they're committed with the plan.
6. **Write `plan.md`** from `plan-template.md` in this skill's folder, following [the milestone rules](#milestone-rules).
7. **Finish** ([Every step](#every-step)). The plan step needs no test run beyond the baseline and the `Compare:` trial runs. Commit `plan.md` as `<slug>: plan v1`. The baton:
   - **Full:** plan review, in a new session: `dev-review <slug> plan`.
   - **Medium:** gate 1, in this session: what to read and the question to answer, as the gate 1 view gives them (`gates.md` in the `dev-status` skill's folder, next to this one; read it in full now), then type `approve the plan`.

## Milestone rules

The plan reviewer checks all of these.

- Every acceptance criterion (AC) is covered by at least one milestone, and each milestone lists the ACs it covers.
- Order the milestones by dependency. Each one leaves the full suite green, apart from the known baseline failures in Checks.
- Keep each one to about 400 lines of new logic and tests at most, and split anything bigger. Moved code and data don't count when a `Compare:` line covers them or the plan names the published document that checks them; otherwise count them. Always give their sizes. Merge neighbouring milestones of the same kind and the same `Tests:` mark when together they fit (a `Compare:` milestone or an `M0` never merges with another kind).
- If an unverified assumption would change the design, add an `M0`: a short experiment, marked `Tests: builder`, whose output is a finding rather than production code.
- Every milestone gets a `Tests:` line with a one-line reason. A milestone that should get kill checks beyond the default says so in that reason. Ask one question: **if this milestone were wrong, would the user find out from an error, or from a wrong number later?** An error means `builder`. A wrong number, or quietly damaged data, means `independent`.

  Mark it `independent` if it:
  - calculates numbers someone will rely on: returns, P&L, valuations, forecasts, ratios, growth rates, margins, model outputs;
  - places orders or moves money: orders, trades, allocations, fees;
  - changes stored data in a way that's hard to undo: imports, deduplication, merges, migrations, backfills, corrections;
  - extracts numbers from a source: 10-K or 10-Q lines into a model, broker statements, vendor or consensus data;
  - lines things up by date or ID: rolling windows, as-of dates, fiscal vs calendar quarters, time zones, trading calendars, look-ahead, joins;
  - converts or rolls up: currencies, units (thousands vs millions), rounding, signs, totals across accounts.

  Mark it `builder` when a mistake would be loud or only cosmetic: wiring, configuration, command-line options, logging, file handling, refactors that don't change behavior, displaying or exporting numbers already tested where they're computed, developer tooling.

  If you're unsure, mark it `independent`. If a milestone is mixed, split it: move the calculation into its own `independent` milestone, and leave the plumbing as `builder`.
- **Milestones meant to change no numbers** (a refactor, a simplification, a speed-up, moving code) that touch code computing or storing money or data get a `Compare:` line. With no new behavior, there's nothing for a kill check to break, so the evidence that nothing changed is the same real input giving the same output before and after. The line gives:
  - a command, or a short chain of them, that runs the real entry point on real input and leaves the outputs in `{out}`, a folder outside the repository. It writes nothing inside the repository, caches included: point any cache at `{out}`;
  - the input: the smallest real one that reaches the changed code, with its path if it isn't in the repository;
  - how to compare: exactly, unless you give a tolerance and why. For tables, compare the values rather than the file bytes when the format holds run-specific fields such as timestamps;
  - if the milestone moves or renames the entry point, the command to use at the base as well (`at base: <command>`).

  Run it once now, if the code already exists, to check that it works, and note how long it took.
- **Facts the plan relies on.** Under Context, list the facts about the data and the existing code that a number depends on, such as units and scale, sign conventions, price adjustments, time zones, as-of vs report dates, fiscal year ends, and which keys are unique. Give each one its source: a `file:line`, a sample of the real data you looked at (file and row), or the user. If you can't check one, mark it `unverified`, and settle it: ask the user, add an `M0` to check it, or plan a `check at` guard where the data enters when the data itself can tell (a header naming the units), and list that guard under Risks too, with its error named in the interface.
- On `independent` milestones:
  - the interface must be exact (names, parameter and return types, units, and the errors a caller relies on), because the test author writes against it before any code exists. Name only errors that someone acts on. Everything else raises whatever the language raises;
  - worked examples are required, with exact expected values.
- **Keep the design simple.** Choose the simplest design that meets the ACs, in the project's existing style. Plan no options, modes, abstraction layers or extension points the requirement doesn't ask for: every later milestone has to build on them.
- **Fail loudly, don't handle.** Mark each line under Risks and edge cases with how it's dealt with. `test` means the risk would give a wrong number or damaged data quietly, so a test pins it down. `raises` means bad input already fails loudly (an exception, or a crash at load), so it gets no guard and no test. `check at <where>` is a guard the user needs, placed once, where the data enters; name its error in the interface, so it gets a test. Use `test` for the quiet money and data risks, including every threshold, tolerance or window the code applies, with its value and whether the value itself is in or out (a guard's threshold stays `check at`), and `raises` for the rest, especially inputs that only come from the user's own code, config or hand-written files. Data from outside (broker statements, vendor files, filings) never counts as the user's own, even when saved locally. Don't plan validation layers, lenient or draft modes, or code that collects problems and carries on, unless the requirement asks for them.
- Expected values in worked examples come from the user, or from your own arithmetic shown in the plan and marked `(planner; confirm at gate 1)`. Never from running code.

## Answer the review

Answer every open item in the latest reviewer round: its new P0–P2 findings, any marked STILL OPEN, and any `ESC-n` raised in `review-plan.md` that the user has decided and the plan doesn't hold yet (a FIX that folds it in). P3 notes need no answer.

1. **Check each finding** against the requirement, the code and the plan before acting on it. Don't agree just to end the exchange, and don't argue for its own sake.
2. **Answer each one** in one of three ways:
   - **FIX:** change the plan. Make the smallest coherent change: what removes the finding's trigger, plus the plan lines that directly depend on it (an AC, a worked example, an interface), listed in your response. Don't rewrite or improve anything else in the same response; that only gives the next round new material.
   - **PUSH BACK:** give the evidence, such as a quote from `requirement.md`, a code path, or a line of the plan.
   - **ESCALATE:** add an `ESC-n` with the options and your recommendation. List it under "Open questions" in the plan too.
3. **Special cases:**
   - If a finding is unclear, don't guess. Push back with your specific question.
   - If a finding asks for something the requirement doesn't need, check whether anything would use it. If nothing would, push back, citing the requirement and the Non-goals.
   - If a finding is real but harmless (it fails "What counts as a finding" in `dev-review`), answer `PUSH BACK (NOT MATERIAL)` and say which part of that test it fails. Only the reviewer can close it.
   - A P3 note is optional. Fix it only if it's a one-line change in a section you're already changing.
4. **Bump the version** (v1 → v2), and say on the `Version:` line what changed.
5. **Append a response** to `review-plan.md`:

   ```
   ## Response r<N> · <date> · "<session name>" (<vendor> <model>)
   Plan: v<old> → v<new>
   Fixes: <reviewed head>..<new head>

   | Finding | Answer | What changed, or the evidence |
   |---|---|---|
   | F1 | FIX | AC-3 now names the rounding rule (plan.md, Acceptance criteria) |
   | F2 | PUSH BACK | requirement.md: "Excel files are out of scope" |
   | F3 | ESCALATE → ESC-2 | Options A and B; I recommend A because … |

   Calls I made: … (or "none")
   ```

6. **Finish.** Commit `plan.md` as `<slug>: plan v<N>`, then the records. The baton goes back to the plan-review session with `dev-review <slug> plan`. If every open item is waiting on the user, the baton lists the ESC IDs to decide instead, and says to type each decision in this session.

## Gate 1: approve the plan

1. **Check:**
   - the latest plan review is READY, for the current plan version;
   - every escalation has a decision;
   - every `(planner; confirm at gate 1)` example has been confirmed.

   If any of these fails, list what's open and ask the user once to confirm approving anyway. Their reason goes in the Decision log. A medium plan has no review, so only the last two checks apply.
2. **Record it.** Set `Accepted: v<N> <YYYY-MM-DD>` at the top of `plan.md`, add the Decision log entry, and set every milestone to `planned` in Progress.
3. **Finish.** Commit as `<slug>: plan v<N> accepted`. The baton is the first milestone in the plan's order (`M0` if there is one), with the line for its mark that `gates.md` gives after `accept Mx` (in the `dev-status` skill's folder, next to this one; read it in full now); on a medium plan, it's built in the `<slug> plan` session. On a full plan, remind the user they can archive the `plan` and `plan-review` sessions now.

## Fold in a decision

**Before gate 1:** change the plan, bump the version, commit as `<slug>: plan v<N> (ESC-n)`, and finish ([Every step](#every-step)) with a log row whose Next is the baton below. Any plan review READY no longer covers it, so the baton is `dev-review <slug> plan`, in the plan-review session. A medium plan has no plan review, so its baton is gate 1 again, in this session.

**After gate 1:**

1. Fold the user's decision into the plan (expected values the user gives or confirms, with the arithmetic shown, never from running code), bump the version, and add to the `Accepted:` line, for example `Accepted: v2 2026-10-09; v3 applies ESC-4 (your decision, 2026-10-11)`. Never make any other change after acceptance; anything else goes back to the user as an escalation. Wherever these steps say `ESC-n`, use the decision's reference: its `ESC-n`, or a short name for a decision without one, such as `checks`.
2. Find the milestones the change affects. Leave `planned` ones with no `<slug> Mx:` commits as they are. Set each other one to `reopened (v<N>, ESC-n)` in Progress, because its tests, code or review no longer match the plan.
3. Commit as `<slug>: plan v<N> (ESC-n)`, and finish ([Every step](#every-step)) with a log row whose Next is this baton:
   - if a milestone was reopened, the earliest one goes back to its builder: `dev-build <slug> Mx`, in its build session if that's still open, or a new one;
   - otherwise, whatever was next before the decision.

## Every step

*This section is the same in all five `dev-*` skills. Change all five together.*

### Start

1. **Read the invocation.** It gives the feature slug, then the target if this skill takes one (`plan`, `M2`, `final`). Anything after that is the user's: a requirement, a decision, or extra focus. The feature's files are in `docs/work/<slug>/`, unless the project's instructions name another place. Follow those instructions (`AGENTS.md`, `CLAUDE.md`, a README) where they exist, but never require them.
2. **The checks** are the commands in the Checks section of `plan.md`, which `dev-plan` writes. If one won't run on this machine (it's missing, not failing), stop and ask the user.
3. **Check git.** The project must be a git repository.
   - Work on branch `work/<slug>`. Only `dev-plan` creates it. If you're on another branch and the tree is clean, switch to it. If `HEAD` is detached, an output comparison stopped partway or is still running in another session: ask the user, and switch back to `work/<slug>` once they confirm nothing is running (`dev-status` only reports it).
   - Run `git status --porcelain`. If it lists changes you didn't make in this session, never stash, commit or discard them (`dev-status` only reports them, apart from an interrupted decision of its own). If they look like an interrupted run of your own step (the files your step writes, for the same target, and no committed `log.md` row for that run; an uncommitted row of your step is part of it), show the user `git status` and a short summary of the diff, and ask whether to carry on from them. If they agree, adopt them, say so under "Calls I made", carry on from where the run stopped, and end with Finish; an adopted log row is that run's row. If they don't, stop. If the changes don't look like that, stop, and tell the user which step the changes seem to come from: rerunning it offers to carry on from them, or the user can commit or discard them.
4. **Read `log.md`** in the feature folder, if it exists. Its last row is where things stand. If commits from your step come after it, a previous session stopped partway: carry on from them, without redoing what they hold, and end with Finish.
5. **Name the session**, if nothing else has been done in it yet, from the table below. If you have a tool that renames the current session (in the Claude desktop app, `set_session_title` with session id `self`), use it, then file the session under the sidebar group `<slug>` (list the groups first; create it only if it's missing). Otherwise the user names it.

| Step | Session name |
|---|---|
| `dev-plan` | `<slug> plan` |
| `dev-review plan` | `<slug> plan-review` |
| `dev-test Mx` | `<slug> Mx test` |
| `dev-build Mx` | `<slug> Mx build` |
| `dev-review Mx` | `<slug> Mx review` |
| `dev-review final` | `<slug> final-review` |
| `dev-build final` | `<slug> final-fix` |
| `dev-status` | `<slug> status` |

### While you work

- **One role.** Subagents may help with your own work, such as searching the code. Never start another role, as a subagent or by messaging another session: each role starts from a line the user pastes.
- **The user's decisions** come in the invocation or are typed later: "approve the plan", "ESC-2: option B", "accept M2", "defer F4 to M3", "allow one more round on M2". Record each one straight away, unless the Decision log already has it (a restart):
  - add `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")` to the Decision log in `plan.md`. Approving the plan, or accepting a milestone or the feature, also changes `Accepted:` or Progress, as `dev-plan`'s "Gate 1" and `dev-status`'s `gates.md` say;
  - mention it in your next `log.md` row, and commit it with your step. If your step has already finished, or stops before Finish, add a row with step `decision`, and commit it with the decision straight away, as `<slug>: decision <ref>` or the message your role gives for it (such as `<slug> Mx: accepted`).

  Then act on it only as far as your role allows.
- **Escalations.** Their IDs run `ESC-1`, `ESC-2`, … across the whole feature: take the number after the highest `ESC-` anywhere in the feature folder. Each states the question, the options and your recommendation in about 5 lines, and stays open until the Decision log has an entry for it.
- **Your own calls.** Every choice you make that the user didn't (one reading of an ambiguity, a small deviation from the plan) goes under "Calls I made" in your handoff, response or review.
- **Quick and full checks.** The *full checks* are every command in Checks; the *quick checks* are the test files that cover what you changed, plus the quick command in Checks if it names one. Work with quick checks. A gate always rests on a full run, run or cited. When your role runs the full checks, run them once, after your last change to code or tests, and save them: redirect each command's output straight into `runs/<YYYY-MM-DD-HHMM>-<step>-<short hash>.txt` in the feature folder as it runs (`<command> > <file> 2>&1`, then `>>`; in Windows PowerShell, inside `cmd /c "..."`), so a lost capture never costs a second run. Then add a header at the top: the commit, each command, how long it took and its result. If the output is very long, keep its summary and every failure. Name the file in your handoff, response or review, and in your `log.md` row.

### Finish

1. **Commit your work** with the message your role gives, before you run the full checks, so that a saved run names a commit holding exactly what was tested. If a check fails and you fix something, commit again and rerun. Never push, amend, rebase or merge.
2. **Log.** Append one row to `log.md`. If the file is missing, create it with the heading `# Log: <slug>` and this table header:

   ```
   | When | Session | Step | Result | Next |
   |---|---|---|---|---|
   ```

   - **When:** local time, as `YYYY-MM-DD HH:MM`.
   - **Session:** `<session name> (<vendor> <model>)`, for example `csv-import M2 review (Claude Opus 5.5)`. Your vendor is Claude in Claude Code and Codex in Codex. Add `, same vendor` when a check ran on the same vendor as the work it checks: plan-review against plan, Mx review against Mx build, final-review against the vendor that built most milestones, and Mx test against Mx build (the builder adds it).
   - **Step:** the skill and target, for example `dev-review M2` or `dev-build M2 (answers r1)`.
   - **Result:** the commit or range, the test result, the verdict, counts, and any new ESC IDs.
   - **Next:** the paste line or lines from your baton.
3. **Commit the records** (handoff, review, `plan.md`, your `runs/` files) with your log row, as `<slug> <step>: records`. When your step writes only records, that's its one commit. Then `git status --porcelain` must be empty, because the next step stops on a dirty tree: commit anything your step wrote in the feature folder, and restore any break of your own. Never commit anything else here: name it to the user, and say the tree isn't clean.
4. **Reply** in at most 8 lines, then end with the baton:

   ```
   Done: <slug> <step>. <commit, tests, verdict, what's open>.
   Next: <what>, in <a new session | the "<session name>" session> (<vendor>: <why>). Paste:
     <line or lines>
   ```

   | The next session is | Claude | Codex |
   |---|---|---|
   | New | `/dev-x <args>`. In a terminal: `claude -n "<session name>" "/dev-x <args>"` | `/rename <session name>`, then `$dev-x <args>` |
   | Already open | `/dev-x <args>` | `$dev-x <args>` |

   **Which vendor.** For a check (plan-review, Mx test, Mx review, final-review), suggest the vendor that didn't write what it checks, from `log.md`, "or a fresh `<same vendor>` session if `<other vendor>` has no capacity"; for Mx test, "the vendor that won't build Mx". For a writing step, the vendor the user last used for that kind of step. When the next step is the user's (a gate, or an escalation), say what to read or decide, and what to type in which session.
