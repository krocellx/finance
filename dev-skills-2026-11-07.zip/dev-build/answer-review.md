# dev-build: answering a review, applying a plan change

Read this in full when `SKILL.md`'s "Work out your job" sends you here. The rest of `SKILL.md` still applies: the rules on tests, and Every step.

## Answer the review

Answer every open item in the latest reviewer round: its new P0–P2 findings, every finding marked STILL OPEN, and every TEST DISPUTE ruling. Also answer every `ESC-n` raised in the review file that the user has decided and nothing has applied yet (no `APPLIED` row, no `apply ESC-n` commit). P3 notes need no answer.

1. **Check each finding against the code** before acting on it. Don't agree just to end the exchange, and don't argue for its own sake.
2. **Answer each one** in one of three ways:
   - **FIX.** A fix that only deletes unneeded code needs no new test: cite the finding. Nor does one whose failing test is a TD ruling you applied: cite the TD. Nor does one that removes or narrows hidden-failure handling (`d.get(k, 0)` → `d[k]`), but run the finding's input and paste the error it now raises (if nothing raises, see `dev-review`'s "Hidden failures"). For an uncaught break, the new test must fail with the reviewer's break in place, and on an `independent` milestone it goes in your own tests, not the acceptance file. For any other bug, write the regression test first. Run it and see it fail on its assertion (not an import error), then fix the code and see it pass. Commit as `<slug> Mx: fix F<n>`. Make the smallest coherent fix: what removes the trigger, plus the callers and tests that directly depend on it, listed in your response. No unrelated cleanup or refactoring in the same response. The rules on acceptance tests still apply.
   - **PUSH BACK**, with evidence: a test, a code path, or a line of the plan or `requirement.md`. Tests that already pass are not evidence on their own.
   - **ESCALATE:** add an `ESC-n` with the options and your recommendation.
3. **Special cases:**
   - **A ruling on a TEST DISPUTE:** apply exactly the corrected expectation the reviewer stated, and nothing else. Commit as `<slug> Mx: apply TD-n ruling`.
   - **A decided `ESC-n`:** make the smallest change that carries out the decision, changing tests only as it states, and answer `APPLIED`. Commit any change as `<slug> Mx: apply ESC-n`.
   - **A finding that's unclear:** don't guess. Push back with your specific question.
   - **A finding that asks for something the plan doesn't need:** check whether anything would use it. If nothing would, push back, citing the plan.
   - **A finding that's real but harmless** (it fails "What counts as a finding" in `dev-review`): answer `PUSH BACK (NOT MATERIAL)` and say which part of that test it fails (for a guard or rejection test against input that already fails loudly, show the exception it raises). Only the reviewer can close it.
   - **A P3 note:** optional, and needs no answer. Fix it only if it's trivial and in a file you're already changing.
   - **A finding the user deferred:** answer `DEFERRED (<Decision log ref>)`.
   - **A finding against the `Compare:` line** (its input doesn't reach the changed code): pick the smallest real input that does, rerun the comparison with it, and add a line under Surprises and deviations in `plan.md` giving the new input.
4. **Run the quick checks.** Also run the full checks, and save the output, if your fixes touch files outside the milestone's list or code that other modules call. Then the recheck cites your run. Otherwise the recheck runs the full checks itself, and a failure found there costs a round. If the milestone has a `Compare:` line and your fixes changed production code, run the output comparison again too ([compare.md](compare.md)), and name its file in your response.
5. **Append a response** to the review file:

   ```
   ## Response r<N> · <date> · "<session name>" (<vendor> <model>)
   Fixes: <reviewed head>..<new head>
   Checks: <command> → <result> (quick | full, saved as `runs/<file>`)
   Compare: identical | <differences> (saved as `runs/<file>`) | not run (no `Compare:` line, or no production code, input or command changed)

   | Item | Answer | What I did, or the evidence |
   |---|---|---|
   | F1 | FIX | <commit>; test_x fails before (assert 240 == 120), passes after |
   | F2 | PUSH BACK | importer.py:88 already skips rows where … |
   | F3 | ESCALATE → ESC-5 | Options A and B; I recommend A because … |
   | TD-1 | APPLIED | expected value changed from 0.0101 to 0.0100, as ruled |

   Size of the fix: <about N lines>; contract changed: no | yes (<units, signs, keys, dates, error contract…>)
   Calls I made: … (or "none")
   ```

6. **Finish** (Every step): your log row and the records in one commit, and a clean tree. The baton goes back to the review session that wrote the round, with the same `dev-review` line. If every open item is waiting on the user, the baton lists the ESC IDs to decide, and says to type the decisions in this build session, so that you apply them (`SKILL.md`'s "Work out your job").

## Apply a plan change

The Progress row names the plan version and the user's decision (`ESC-n`).

**If the handoff has no "Build" section yet**, change the acceptance tests to match the decision exactly, and commit as `<slug> Mx: apply ESC-n`. Set Progress back to `tests written` (`planned` on a `builder` milestone), then build as `SKILL.md`'s "Build" says, listing the change in the handoff under "Changes to acceptance tests", with the decision's reference. Skip the steps below.

1. Read that decision and what changed in `plan.md`.
2. Change the acceptance tests to match the decision exactly. This is allowed even for the test author's tests, because it's the user's decision. Then change the code. Commit as `<slug> Mx: apply ESC-n`.
3. Run the checks as in [Answer the review](#answer-the-review), step 4. If there's no review file yet, run the full checks, and the output comparison if there's a `Compare:` line, as at the end of a build.
4. Record it, and set the Progress row back to `implemented`:
   - **No review file yet:** add the change to the "Build" section of the handoff. Test changes go under "Changes to acceptance tests", with the decision's reference. Code changes go under Deviations from the plan.
   - **Otherwise:** if the review file's last section is a reviewer round, [answer the review](#answer-the-review), with the row `ESC-n | APPLIED` among the others; if it's your response, append one with that row, plus any other decided `ESC-n` as in step 5 of `SKILL.md`'s "Work out your job".
5. Finish (Every step): your log row and the records in one commit, and a clean tree. The baton goes to the reviewer: `dev-review <slug> Mx`, in its review session if that's still open, or a new one.
