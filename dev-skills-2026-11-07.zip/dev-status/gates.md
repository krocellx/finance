# dev-status: gate views and decisions

`dev-status` reads this when a gate is ready or it records a decision. `dev-plan` and `dev-review` read it when a gate comes up in their session.

## Gate views

**Gate 1, the plan.** List:

- the Goal and Non-goals;
- each AC with its worked examples, marking those that came from the planner and need confirming;
- the milestones, with each `Tests:` mark and its reason, and the `Compare:` line where there is one, under one line giving how many milestones and their total size;
- the Risks on money or data paths marked `raises` or `check at`, one line each;
- the facts the plan relies on that are still `unverified`, each with how the plan settles it;
- the Checks section: the full and quick commands, how long the full checks took, and any known baseline failures;
- the open escalations.

Keep this view to about 40 lines, one line per AC and milestone, and point to `plan.md` for the rest. To fit, shorten; never cut an example to confirm, an `unverified` fact, a `raises` or `check at` risk, or an open escalation. Ask: are the milestones too coarse or too fine? If so, say how to change them, here or in the `<slug> plan` session.

Then: type `approve the plan`, in the `<slug> plan` session or here.

**Gate 2, a milestone.** Don't hand the user a reading list. Show the "For the user" section of the READY round. If the round has none (reviews written before this section existed), build it yourself from the handoff and the reviews, with the three tiers in `dev-review`'s "READY on a milestone".

On `independent` milestones, also list the acceptance test names, one per line, under "The spec, as tested". They're the one thing worth a quick read, because they say what was pinned down.

Quote what matters inline; the user shouldn't have to open a file. When a source helps, cite the file and its section heading (`handoff-M3.md`, "Weakened tests"), never a line number.

End with a verdict line:
- "Needs your call" empty: `Nothing needs your judgment. Type accept Mx here.`
- otherwise: `Answer the N item(s) above, then type accept Mx here, or say what's wrong.`

**Gate 3, the feature.** List:

- the commands `review-final.md` gives for one normal case and one failure case, for the user to run (on a medium plan, write them yourself from the plan's ACs);
- each auto-accepted milestone, with the "Worth a glance" lines from its READY round (or "nothing"). This is the user's one look at the calls made on those milestones;
- anything still deferred;
- everything under "Found outside this change" in the handoffs and reviews, one line per defect even when several rounds note it (or "nothing"). These are defects in code the feature didn't change. They don't block the merge; any of them can become its own piece of work, started with `dev-plan`;
- **how the process went**, in about 4 lines, counted from the review files, the handoffs, `plan.md` and `log.md`:
  - rounds per target, counted as the round budget counts them (REVIEW INCOMPLETE rounds don't count), for example `plan 3, M1 1, M2 2, final 1`, plus any hand-offs;
  - P0–P2 findings by how they ended: VERIFIED, WITHDRAWN, DOWNGRADED, DEFERRED, ESCALATED, or still open when the user accepted over them; and the number of P3 notes;
  - test disputes, and how each was ruled: the test was wrong, the code was wrong, or escalated;
  - milestones auto-accepted, accepted milestones later reopened, and checks that ran on the same vendor.

  These are the numbers that decide, after the pilot, which steps earn their place.

Then: type `accept the feature` here.

## Decisions

Record each decision as Every step says, with these additions. Each decision is one commit: the change to `plan.md` and its `decision` row in `log.md` together, and the tree is clean afterwards.

- **`accept Mx`:**
  - If the latest review of Mx isn't READY, or its READY is stale, say what's open or what changed, and ask the user once to confirm, with a reason that goes in the Decision log.
  - Set the milestone's Progress row to `accepted <date>`, and commit as `<slug> Mx: accepted`.
  - The baton is the next milestone in the plan:
    - an `independent` milestone: `dev-test <slug> M<next>`, in a new session;
    - a `builder` milestone: `dev-build <slug> M<next>`, in a new session.
  - After the last milestone, the baton is `dev-review <slug> final`, in a new session. A medium plan has no final review, so the user goes straight to gate 3: show its gate view (above) right away, then they type `accept the feature`.
  - Remind the user they can archive the `Mx build`, `Mx test` and `Mx review` sessions.
- **`approve the plan`:** check and record it as `dev-plan`'s "Gate 1" does, baton included.
- **`accept the feature`:**
  - If `review-final.md` isn't READY, or its READY is stale, ask the user once to confirm, with a reason. A medium plan has no final review, and needs none.
  - Add a Progress row `Feature | accepted | <date>`, and commit as `<slug>: feature accepted`. The `log.md` row's Result gives the "how the process went" counts on one line, so they can be compared across features.
  - The baton gives the merge commands for the user to run themselves, for example `git switch <the branch after "from" on plan.md's Branch: line>` and then `git merge --no-ff work/<slug>`, and reminds them to archive the remaining sessions. Never merge or push yourself.
- **`stop at Mx`** or **`stop at every gate`:** record it.
- **Anything else** ("ESC-2: option B", "defer F4 to M3", "allow one more round on M2"): record it. The baton is whatever was next before the decision, unless the decision changes that. For example, a decision that changes the plan (what `dev-plan`'s "Work out your job", step 4, lists) goes to the build session of the milestone it concerns (`dev-build <slug> Mx`, in that session if it's still open, or a new one), which folds it in, or to `dev-plan <slug>` if it concerns no milestone already started.
