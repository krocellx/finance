---
name: dev-control
description: "Runs a feature through the dev-* workflow for the user: starts each step as a new session on its own vendor (or, if asked, checks on the other vendor), picks the model and effort from the step's difficulty within the user's limits, and stops whenever the user must decide. Use only when the user invokes it by name."
argument-hint: "<slug> [limits]"
disable-model-invocation: true
---

# dev-control: the user's driver

You do what the user does between steps: read the baton, start the next session, paste its line. You never change code, tests, plans, reviews or `log.md`, never commit, and never decide anything the user decides. The steps' own skills do all the work and keep all the records; you only start them and read what they leave. You work the same from Claude Code or Codex. Every step runs on your own vendor (Claude in Claude Code, Codex in Codex), unless the user's limits say `cross` ([below](#limits)).

## Start

1. **Read the invocation.** The first line gives the slug, then any limits ([below](#limits)). If `docs/work/<slug>/log.md` doesn't exist yet, the lines after the first are the user's requirement; if there are none, ask for it. Keep the limits for the whole session, and say back in one line how you read them; without `cross`, add that every step, checks included, will run on your vendor unless a pin or an exclusion says otherwise.
2. **Check** that the project is a git repository and that your vendor's tool runs (`claude --version` or `codex --version`), and the other one too when `cross`, a pin or an exclusion can send a step there. A missing tool removes its vendor (in the Claude desktop app, a missing `claude` removes only headless Claude runs); say so. If that leaves a step no vendor, stop and say so.
3. **Keep your files outside the project** (a temp folder, one per slug): prompts, outputs, session ids. Every step stops on a dirty tree.

## The loop

Repeat until you stop:

1. **Where things stand.** `git status --porcelain` must be empty and the branch `work/<slug>` (or the project's branch, before `dev-plan` has created it). Otherwise stop and show it, unless the changes look like an interrupted run of the next step (its files, for its target) and no session you started is still running: then run that step, which offers to carry on from them. Read the last row of `log.md`; with no `log.md`, the next step is `dev-plan <slug>` followed by the requirement.
2. **Is the next move the user's?** It is when the row's Next names no `dev-plan`, `dev-test`, `dev-build` or `dev-review` line, or, before its first such line, asks the user for an action (fix a blocker, read, run, close, merge) or for a decision that is still open. What Next asks after its first line waits for that step's own row. A decision is still open when it's a gate (`approve the plan`, `accept Mx`, `accept the feature`) that `plan.md` doesn't show as done, or an `ESC-n` that Next names and `plan.md`'s Decision log has no entry for (`## Every step`, "Escalations"). Open escalations Next doesn't name don't count: the workflow carries them to a later gate. Nor does a reminder to archive sessions, or anything "when convenient". Then [stop for the user](#stopping-for-the-user).
3. **Pick the vendor.** Without `cross`, your own, whatever Next prefers; if your limits exclude it, the other one, and say so. With `cross`, the vendor the row's Next prefers ("Codex preferred", "ideally Codex"). If it names a session already open ("in the `X M1 review` session"), the vendor that session ran on, from its latest `log.md` row. If it offers both without a preference, or names none, use the vendor `## Every step`'s "Which vendor" gives from `log.md`. If only one vendor's line is there (`$dev-…` is Codex; `/dev-…` or `claude -n …` is Claude), that one. If your limits exclude it, or it has just given a usage-limit or access message, use the other one and say so; whenever this puts a check on the vendor that did the work, say so. Either way, a [pin](#limits) for the step decides the vendor instead. If the vendor you picked has just given a usage-limit or access message and you can't switch (without `cross`, on a pinned step, or when the other vendor is excluded or missing), stop and say so. A check on the vendor that did the work marks `same vendor` in its own log row.
4. **Pick the model** ([below](#models)), then **run** the step as a new session ([commands](#commands)). Its prompt is the skill, slug and target from the line (`dev-build csv-import M2`), in the run vendor's form (`/dev-…` for Claude, `$dev-…` for Codex), and nothing else: drop anything else the line carries, such as a suggested decision, and add no summary, focus or anything you read. That is what keeps each check independent and every decision the user's. The only other text a session ever gets is the user's own words, verbatim: the requirement after `dev-plan`, a decision ([below](#stopping-for-the-user)), or an answer to its question.
5. **Read the result.** A step finished when `log.md` has a new committed row and the tree is clean. Report one line: step, vendor, model and effort, minutes, the row's Result. Then loop.
   - **It asked a question** (its last message asks the user something, such as `dev-plan`'s questions or "carry on from these changes?"): show the question verbatim and wait. Send the user's reply verbatim to the same headless session ([resume](#commands)); in an app session, the user answers there themselves, and you wait for it to end its turn again.
   - **It failed** (a crash, a non-zero exit, a timeout, a limit message): make sure its process has ended, then run the same step once more in a new session: after a limit message, on the other vendor with `cross` (without it, on a pinned step, or when the other vendor is excluded or missing, stop instead), otherwise one tier up. The skills carry on from what the first run committed. A second failure stops you.
   - **It ended any other way without a new row** (a skill that stopped on purpose, or reprinted its baton): show its last message and stop.

Run one step at a time: all steps share one checkout. A step can take 40 minutes; if your shell limits command time, run it in the background and wait for it to exit.

## Stopping for the user

Run `dev-status <slug>` in a new session at the `normal` tier, on your own vendor unless your limits say otherwise, and show its reply as it is (status, "Needs you", the gate view). Then wait. After a stop for a usage-limit or access message, run no `dev-status`: show the message, say that a pin, `no <vendor>` or `cross` can move steps to the other vendor, and wait; on "go on", forget earlier limit messages and failures, and go back to the loop, step 1.

- **A decision** ("approve the plan", "accept M2", "ESC-3: option B", "allow one more round on M2", "stop at every gate"): if Next told the user to type it in a step's session ("in the `X M2 build` session"), run that step (`dev-build <slug> M2`) with their words, verbatim, after the line, as in the loop, steps 3–5; every skill records a decision given in its invocation. Otherwise run `dev-status <slug> <their words, verbatim>` in a new `normal` session and read its result as in the loop, step 5 (it can ask a question, such as a reason to accept over a stale READY). Then carry on as for "go on", using that run's reply instead of running `dev-status` again.
- **"Go on"**, once the user has done the action asked of them (fixed a blocker, closed an app, committed a fix): run `dev-status <slug>` again. If it says a READY went stale, the next step is the `dev-review` line it gives. Otherwise, if it shows a gate view, or a gate its Next asks for is still open (loop, step 2), say what is still missing and run nothing. If its Next has no step line (the merge), stop. Else the next step is the first step line its Next names; if that Next also names an open `ESC-n`, ask the user once whether to run the step anyway ("allow one more round", just typed, is that yes). Run that step as in the loop, steps 1 and 3–5, with `cross` reading dev-status's Next for the vendor as you would the row's.
- **A step line** the user types (`dev-review <slug> plan`): run it, as in the loop, steps 1 and 3–5 (on the vendor step 3 gives, whichever form they typed). This is the way past a baton that names no step.
- **Anything else** (a question, changed limits, "stop"): answer it, or stop.

Never merge or push. At the end, show gate 3's merge commands and stop.

## Models

Each step gets a tier from its difficulty:

| Tier | Steps |
|---|---|
| `hard` | `dev-plan` with no `plan.md` yet; `dev-test`; `dev-review` unless the last section of `review-<target>.md` is a `Response` (so every first review, a redone one and a finished `pending` one); `dev-build` on an `independent` milestone (`plan.md`, its `Tests:` line), with no `handoff-Mx.md` "Build" section yet |
| `normal` | every other step, `dev-status` included |

A failed step's rerun, other than after a limit message, goes one tier up: `normal` to `hard`, `hard` to `top`, and `top` stays `top`. The new review after a HAND OFF verdict is `top`.

| Tier | Claude | Codex |
|---|---|---|
| `top` | `fable` `high` | `gpt-6-astra` `high` |
| `hard` | `opus` `high` | `gpt-6.1-sol` `xhigh` |
| `normal` | `sonnet` `high` | `gpt-6.1-sol` `medium` |

Strongest first. Claude: `fable`, `opus`, `sonnet`, `haiku`; effort `max`, `xhigh`, `high`, `medium`, `low`. Codex: `gpt-6-astra`, `gpt-6.1-sol`, `gpt-6-luna`; effort `ultra`, `max`, `xhigh`, `high`, `medium`, `low`. When a model here is no longer offered, tell the user, and use the next one down.

### Limits

The user gives these after the slug, in plain words, separated by commas; for example `dev-control csv-import max opus high, no fable, max gpt-6.1-sol, sonnet for builds`.

- **`cross`**: each step on the vendor the baton suggests, which for a check is usually the one that didn't do the work ([the loop](#the-loop), step 3). `no cross` goes back to the default.
- **`max <model> [effort]`**: nothing stronger on that model's vendor; on that model itself, no higher effort than named.
- **`no <model | vendor>`**, or **`<vendor> only`**: never use it.
- **`<model> [effort] for <steps>`**: always that, for those steps (plans, tests, builds, reviews, rechecks, status).

Apply a pin first, then the caps: a pick above a cap drops to the cap, an excluded model drops to the next one down that's allowed. If no model of either vendor is allowed for a step, stop and say why. Limits typed later replace the ones they name.

## Commands

**In the Claude desktop app, start Claude steps as app sessions,** so the user can open and watch each one: your tool for starting a session (`start_session`), started because the user asked, with a fresh context in this same checkout (no worktree), the step's session name from `## Every step` as the title, the prompt as the brief, and as background only this fixed text: "A dev-* workflow step, started by the user's dev-control session. Do exactly what the skill in the brief says." Set its model and effort there. The app caps them at your own, so a `hard` or `top` step needs you running on that model: if it would be capped, say so, and run the step headless instead (with no `claude` tool, stop and say so). Wait for the app to tell you the session ended its turn; don't poll. Codex steps always run headless.

**Headless,** from the project root. Write each prompt to a file in your temp folder (every file below lives there, never in the project) and feed it on stdin, so `$` and line breaks reach the session untouched (in Windows PowerShell, inside `cmd /c "..."`, which has `<`). New session:

- **Claude:** `claude -p --model <model> --effort <effort> -n "<session name>" --session-id <new uuid> --permission-mode auto < <temp>/prompt.txt > <temp>/out.txt`.
- **Codex:** `codex exec -C <project root> -m <model> -c model_reasoning_effort=<effort> -s workspace-write --approve-for-me --json -o <temp>/last.txt - < <temp>/prompt.txt > <temp>/events.jsonl`. The session id is the `thread_id` of the first `thread.started` event.

Resume, to answer a question, with the same model and effort:

- **Claude:** `claude -p --resume <id> --model <model> --effort <effort> --permission-mode auto < <temp>/answer.txt > <temp>/out.txt`.
- **Codex** (from the project root): `codex exec resume <thread_id> -m <model> -c model_reasoning_effort=<effort> -c sandbox_mode="workspace-write" --json -o <temp>/last.txt - < <temp>/answer.txt > <temp>/events.jsonl`.

If a step fails on a command its sandbox or permission mode blocked (a Codex step that can't commit, say), stop and tell the user: they decide whether that vendor's steps get more access or run in sessions they open themselves. Never add a flag that skips permissions or the sandbox. Run from Codex, you need network access and long command timeouts for these commands; if you don't have them, say so.
