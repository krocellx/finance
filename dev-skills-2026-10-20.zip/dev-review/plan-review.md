# dev-review: reviewing a plan

Read this in full when your job is a first or fresh review of `plan`, a redo of one, or a plan recheck (for the parts the fix changed). The rest of `SKILL.md` still applies: how to judge, findings, verdict and finish.

Read `requirement.md`, the code it touches, then `plan.md`. Check the plan against every rule in `dev-plan`'s "Milestone rules", and:

- **Coverage:** every point of the requirement has an AC or a Non-goal, and the plan adds nothing it didn't ask for. A reasonable-user expectation the requirement is silent on needs an AC or a Non-goal: raise it as a finding, not as scope creep. Each AC is observable and says how it's checked.
- **Worked examples:** recompute every expected value by hand; flag each one the planner made up, for the user to confirm at gate 1.
- **Facts the plan relies on:** spot-check what you can. A missing or wrong fact that would change a number is a finding, and so is an `unverified` one the plan doesn't settle.
- **Fit:** real modules and the code's conventions. An option, mode, layer or extension point the requirement doesn't ask for is unneeded complexity.
- **Checks:** the full checks cover the whole suite (compare with the test folders and CI config), and the quick checks are a subset of them; a partial "full" command is P1, because every later gate would pass on it.
- **Risks:** a quiet money or data risk marked `raises` is a finding. Handling that fills, skips or defaults missing money or data values without the requirement asking is a finding; extra validation modes or repeated checks are unneeded complexity: ask for them to be removed, never added.

A plan review needs no test run. READY means ready for the user's gate 1.
