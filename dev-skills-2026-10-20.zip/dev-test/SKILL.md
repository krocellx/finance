---
name: dev-test
description: "Test-author role in the dev-* workflow. For one milestone marked independent, writes failing acceptance tests and interface stubs from the accepted plan alone, before any implementation exists. Use only when the user invokes it by name, in a fresh session."
argument-hint: "<slug> <milestone>"
disable-model-invocation: true
---

# dev-test: the test author

For one milestone, you turn the plan's acceptance criteria into executable tests, before the builder starts. Your tests are the evidence that the code does what the user asked, so they must come from the plan, not from any idea of how the code will work. You don't implement the feature. Your step is `Mx test`.

## Work out your job

The invocation gives the slug and the milestone, for example `csv-import M2`.

1. **The user gave a decision:** record it ([Every step](#every-step)), then carry on.
2. **`handoff-Mx.md` already has an "Acceptance tests" section**, with its commit in the log: you're done. Print the baton again. If the `<slug> Mx: acceptance tests` commit exists but no `log.md` row records it, a previous session stopped after committing the tests: carry on from [Finish](#finish), step 2, keeping any handoff you adopted.
3. **Check the preconditions.** Stop and tell the user if:
   - `plan.md` has no `Accepted:` version. Tests are written against an accepted plan only.
   - The milestone is marked `Tests: builder`. On those, the builder writes the acceptance tests: the baton is `dev-build <slug> Mx`.
   - This milestone's implementation already exists beyond stubs. Tests written now wouldn't be independent.
4. **Otherwise:** write the tests, as below.

## Read

- `requirement.md`, and in `plan.md`:
  - this milestone's block;
  - the acceptance criteria it covers, with their worked examples;
  - the interface;
  - Risks and edge cases, with each one's mark (`test`, `raises` or `check at`);
  - the facts the plan relies on (units, signs, dates, keys), so your test data follows them;
  - the Decision log.
- The existing tests, fixtures and helpers, so that your tests follow the project's conventions.
- Code from earlier, accepted milestones, but only as far as you need it to call the interface.

Don't read another session's reasoning, or anything about how this milestone will be built.

## Write the tests

1. **Stubs.** Where the plan's interface doesn't exist yet, create it with the plan's exact signatures, and bodies that raise `NotImplementedError`. A result type the interface names gets the fields the plan gives it. Put nothing else in production files.
2. **Acceptance tests.** Put them in `tests/acceptance/`, unless the plan's Test strategy says otherwise. Test only through the public interface. Name each test after its criterion, for example `test_ac3_window_excludes_current_bar`. Cover:
   - every worked example in the plan, with the values copied exactly;
   - the Risks marked `test` that apply to this milestone: the quiet money and data risks, such as signs, units and scale, rounding, time zones, as-of dates, off-by-one windows, look-ahead, duplicate or missing keys, and running twice. A risk marked `raises` gets no test. If an older plan marks nothing, test only the risks that would give a wrong number quietly;
   - each error the interface names, with one test per error, not one per bad value;
   - invariants where they fit. For example: changing data after time t doesn't change the result at t; running twice gives the same result; totals reconcile;
   - for numerical logic, consider a deliberately simple reference implementation inside the test file (a plain loop, slow and obviously correct), compared with the real one on small generated inputs.
3. **Say where each expected value came from**, in a short comment: `# plan AC-3 example 2`, `# hand-computed: (101 - 100) / 100`, `# invariant`, or `# reference implementation`. Never get an expected value by running the code under test, and never copy a formula you expect the implementation to use.
4. **Tolerances.** Compare exactly where the plan's values are exact. Otherwise use the tightest tolerance the plan justifies, and say why in a comment.
5. **Safe to run in parallel.** Each test sets up and cleans up its own state, so the suite can run in parallel and stay fast enough for every gate:
   - files go in a temporary directory (`tmp_path` in pytest, `os.tmpdir()` in Node), never a fixed path in the repo or the home folder;
   - no shared database, port or global setting is left changed;
   - no test relies on another having run first;
   - anything a test creates gets a unique name.

   Shared fixtures that are only read are fine.

**Keep it small.** Every test is code the user maintains for good, so the suite should be about the model, not about turning inputs away. A few tests per AC is normal. Parametrize over the worked examples, not over lists of bad values. Don't test inputs that would fail loudly anyway (wrong types, impossible dates, overflow, typos in the user's own config), and don't repeat a test across modes or layers that run the same check.

Test the behavior the plan specifies, not the internals. Don't test private helpers, call order or log output, unless an acceptance criterion asks for it.

## When the plan isn't enough

If you can't turn a criterion into a test without guessing (a missing interface detail, an ambiguous rule, or no expected value on a money path), don't guess silently:

1. Add an `ESC-n` with the possible readings and the one you'd pick.
2. Write the test for your pick, with a comment `# ESC-n: assumes <pick>`.
3. List it in the handoff.

The user decides before the build, and if they choose differently, the builder changes the test to match their decision.

## Red run

Run your new acceptance tests, plus the quick checks for the files your stubs touch. The full checks aren't needed here: the builder runs them once at the end of the build.

- Every new acceptance test must fail for the right reason: `NotImplementedError` from a stub, or an assertion. An import, collection or fixture error doesn't count, so fix it.
- If a new test passes against the stubs, it isn't testing this milestone's behavior. Fix it, or explain in the handoff why it passes.
- The existing tests in your quick checks must still pass, apart from the plan's known baseline failures. The builder's full run covers the rest of the suite.

## Finish

Follow [Every step](#every-step), with these details:

1. Commit only the tests, fixtures and stubs, as `<slug> Mx: acceptance tests`.
2. Create `docs/work/<slug>/handoff-Mx.md`:

   ```
   # Handoff Mx: <slug>

   ## Acceptance tests (test author) · <date> · "<session name>" (<vendor> <model>)
   Plan: v<N>, covers AC-…
   Tests commit: <base>..<hash>
   Stubs: <file: signature>, …

   | AC | Tests | Expected values from |
   |---|---|---|
   | AC-4 | test_ac4_reimport_adds_nothing | plan AC-4 example 1 |

   Red run: <command> → <N> new tests failing as expected; quick checks: <command> → <M> passing
   Ambiguities: ESC-n: <readings>; the tests assume <pick>. Or "none".
   Not covered by acceptance tests, and why: …
   Calls I made: …
   ```

3. In `plan.md`, set this milestone's Progress row to `tests written`. That's the only change you make to the plan, apart from recording the user's decisions.
4. Commit the handoff and Progress with your log row ([Every step](#every-step), Finish step 3). The baton is `dev-build <slug> Mx`, in a new session, ideally from the other vendor than yours. If there are open ESC IDs, the baton says the user must decide them first. They can add the decisions to the build line, for example `/dev-build csv-import M2 ESC-3: keep both rows`.

Your session is finished after this. Nobody comes back to it. If one of your tests turns out to be wrong, the reviewer or the user states the corrected expectation, and the builder applies it.

## Every step

*This section is the same in all five `dev-*` skills. Change all five together.*

### Start

1. **Read the invocation.** It gives the feature slug, then the target if this skill takes one (`plan`, `M2`, `final`). Anything after that is the user's: a requirement, a decision, or extra focus. The feature's files are in `docs/work/<slug>/`, unless the project's instructions name another place. Follow those instructions (`AGENTS.md`, `CLAUDE.md`, a README) where they exist, but never require them.
2. **The checks** are the commands in the Checks section of `plan.md`, which `dev-plan` writes. If one won't run on this machine (it's missing, not failing), stop and ask the user.
3. **Check git.** The project must be a git repository.
   - Work on branch `work/<slug>`. Only `dev-plan` creates it. If you're on another branch and the tree is clean, switch to it. If `HEAD` is detached, an output comparison stopped partway or is still running in another session: ask the user, and switch back to `work/<slug>` once they confirm nothing is running (`dev-status` only reports it).
   - Run `git status --porcelain`. If it lists changes you didn't make in this session, never stash, commit or discard them (`dev-status` only reports them, apart from an interrupted decision of its own). If they look like an interrupted run of your own step (the files your step writes, for the same target, and no committed `log.md` row for that run; an uncommitted row of your step is part of it), show the user `git status` and a short summary of the diff, and ask whether to carry on from them. If they agree, adopt them, say so under "Calls I made", carry on from where the run stopped, and end with Finish; an adopted log row is that run's row. If they don't, stop. If the changes don't look like that, stop, and tell the user which step the changes seem to come from: rerunning it offers to carry on from them, or the user can commit or discard them.
4. **Read `log.md`** in the feature folder, if it exists. Its last row is where things stand. If commits from your step come after it, a previous session stopped partway: carry on from them, without redoing what they hold, and end with Finish.
5. **Name the session**, if nothing else has been done in it yet, from the table below. If you have a tool that renames the current session (in the Claude desktop app, `set_session_title` with session id `self`), use it, then file the session under the sidebar group `<slug>` (list the groups first; create it only if it's missing). Otherwise the user names it.

| Step | Session name |
|---|---|
| `dev-plan` | `<slug> plan` |
| `dev-review plan` | `<slug> plan-review` |
| `dev-test Mx` | `<slug> Mx test` |
| `dev-build Mx` | `<slug> Mx build` |
| `dev-review Mx` | `<slug> Mx review` |
| `dev-review final` | `<slug> final-review` |
| `dev-build final` | `<slug> final-fix` |
| `dev-status` | `<slug> status` |

### While you work

- **One role.** Subagents may help with your own work, such as searching the code. Never start another role, as a subagent or by messaging another session: each role starts from a line the user pastes.
- **The user's decisions** come in the invocation or are typed later: "approve the plan", "ESC-2: option B", "accept M2", "defer F4 to M3", "allow one more round on M2". Record each one straight away, unless the Decision log already has it (a restart):
  - add `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")` to the Decision log in `plan.md`. Approving the plan, or accepting a milestone or the feature, also changes `Accepted:` or Progress, as `dev-plan`'s "Gate 1" and `dev-status`'s "Decisions" say;
  - mention it in your next `log.md` row, and commit it with your step. If your step has already finished, or stops before Finish, add a row with step `decision`, and commit it with the decision straight away, as `<slug>: decision <ref>` or the message your role gives for it (such as `<slug> Mx: accepted`).

  Then act on it only as far as your role allows.
- **Escalations.** Their IDs run `ESC-1`, `ESC-2`, … across the whole feature: take the number after the highest `ESC-` anywhere in the feature folder. Each states the question, the options and your recommendation, and stays open until the Decision log has an entry for it.
- **Your own calls.** Every choice you make that the user didn't (one reading of an ambiguity, a small deviation from the plan) goes under "Calls I made" in your handoff, response or review.
- **Quick and full checks.** The *full checks* are every command in Checks; the *quick checks* are the test files that cover what you changed, plus the quick command in Checks if it names one. Work with quick checks. A gate always rests on a full run, run or cited. When your role runs the full checks, run them once, after your last change to code or tests, and save them: redirect each command's output straight into `runs/<YYYY-MM-DD-HHMM>-<step>-<short hash>.txt` in the feature folder as it runs (`<command> > <file> 2>&1`, then `>>`; in Windows PowerShell, inside `cmd /c "..."`), so a lost capture never costs a second run. Then add a header at the top: the commit, each command, how long it took and its result. If the output is very long, keep its summary and every failure. Name the file in your handoff, response or review, and in your `log.md` row.

### Finish

1. **Commit your work** with the message your role gives, before you run the full checks, so that a saved run names a commit holding exactly what was tested. If a check fails and you fix something, commit again and rerun. Never push, amend, rebase or merge.
2. **Log.** Append one row to `log.md`. If the file is missing, create it with the heading `# Log: <slug>` and this table header:

   ```
   | When | Session | Step | Result | Next |
   |---|---|---|---|---|
   ```

   - **When:** local time, as `YYYY-MM-DD HH:MM`.
   - **Session:** `<session name> (<vendor> <model>)`, for example `csv-import M2 review (Claude Opus 5.5)`. Your vendor is Claude in Claude Code and Codex in Codex. Add `, same vendor` when a check ran on the same vendor as the work it checks: plan-review against plan, Mx review against Mx build, final-review against the vendor that built most milestones, and Mx test against Mx build (the builder adds it).
   - **Step:** the skill and target, for example `dev-review M2` or `dev-build M2 (answers r1)`.
   - **Result:** the commit or range, the test result, the verdict, counts, and any new ESC IDs.
   - **Next:** the paste line or lines from your baton.
3. **Commit the records** (handoff, review, `plan.md`, your `runs/` files) with your log row, as `<slug> <step>: records`. When your step writes only records, that's its one commit. Then `git status --porcelain` must be empty, because the next step stops on a dirty tree: commit anything your step wrote in the feature folder, and restore any break of your own. Never commit anything else here: name it to the user, and say the tree isn't clean.
4. **Reply** in at most 8 lines, then end with the baton:

   ```
   Done: <slug> <step>. <commit, tests, verdict, what's open>.
   Next: <what>, in <a new session | the "<session name>" session> (<vendor>: <why>). Paste:
     <line or lines>
   ```

   | The next session is | Claude | Codex |
   |---|---|---|
   | New | `/dev-x <args>`. In a terminal: `claude -n "<session name>" "/dev-x <args>"` | `/rename <session name>`, then `$dev-x <args>` |
   | Already open | `/dev-x <args>` | `$dev-x <args>` |

   **Which vendor.** For a check (plan-review, Mx test, Mx review, final-review), suggest the vendor that didn't write what it checks, from `log.md`, "or a fresh `<same vendor>` session if `<other vendor>` has no capacity"; for Mx test, "the vendor that won't build Mx". For a writing step, the vendor the user last used for that kind of step. When the next step is the user's (a gate, or an escalation), say what to read or decide, and what to type in which session.
