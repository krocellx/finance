# dev-build: the output comparison

Read this in full when you run or check the output comparison of a milestone with a `Compare:` line (`dev-review` reads it too). The line gives a command that runs real input through the code and leaves its outputs in `{out}`, plus how to compare them. If Surprises and deviations records a newer input or command for it, use that.

1. Commit anything you've changed, so that the tree is clean apart from your own `runs/` files. Records go in a `<slug> <step>: records` commit; another one at Finish is fine.
2. Make two new, empty temporary folders outside the repository. Run the command at `HEAD` into the first.
3. `git switch --detach <base>`, run the command (or its `at base:` form) into the second, and `git switch work/<slug>`. The base is the commit before the milestone's first commit: the `<base>` of the milestone's first range in `log.md`, or, for a builder making that first commit, `HEAD` before it. For a milestone reopened after later milestones were built, it's `HEAD` before the reopen's first commit, and only what the reopen's decision names may differ.
4. After each run, check `git status --porcelain`. If the run changed anything, restore it before going on, and don't use that run: the `Compare:` line is wrong, because it must write nothing inside the repository, caches included. The builder fixes the command, as a small plan change under Surprises and deviations; a reviewer raises a P2 against the `Compare:` line.
5. Compare the two as the line says. Save the result to `runs/<YYYY-MM-DD-HHMM>-<step>-compare-<short hash>.txt`: both commits, the command, the input, and either "identical" or the number of differences with the first 10. Name it wherever you name your full run.

Never switch while a full run of yours is still going.
