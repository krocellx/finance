---
name: dev-plan
description: "Planner role in the dev-* workflow. Saves the user's requirement, writes the feature's plan.md with acceptance criteria and milestones, answers plan-review findings, and records the plan's approval (gate 1). Use only when the user invokes it by name."
argument-hint: "<slug> [requirement | decision]"
disable-model-invocation: true
---

# dev-plan: the planner

You turn the user's requirement into `plan.md`: what will be built, how each part will be checked, and in which milestones. You don't write production code or tests. Your step is `plan`.

## Work out your job

Read `docs/work/<slug>/`, then work down this list:

1. **No `plan.md`:** [draft the plan](#draft-the-plan). If there's no `requirement.md` either and the invocation has no requirement text, ask the user to paste it, and stop. If `requirement.md` already exists, a previous session stopped partway: keep it, and carry on from [Draft the plan](#draft-the-plan), step 3.
2. **The user gave a decision**, in the invocation or typed since: record it ([Every step](#every-step)). If it's "approve the plan", don't record it yet: go to [gate 1](#gate-1-approve-the-plan), which checks first and then records it in one commit. Otherwise carry on down this list.
3. **`review-plan.md` ends with a reviewer round** whose verdict is CHANGES REQUIRED or NEEDS OWNER DECISION: [answer the review](#answer-the-review).
4. **A user decision changes the plan** (an acceptance criterion, a worked example, an interface, the milestones, a fact the plan relies on, or the Checks section), but isn't in it yet: [fold it in](#fold-in-a-decision). Adding a missing Checks section counts. Work it out as in [Draft the plan](#draft-the-plan), step 3, but keep the commands that the earlier saved runs and handoffs used, and add only what they lacked: timings, quick checks, known failures, the parallel try. Added that way, it reopens no milestone and leaves milestone and final reviews valid. Any other change to Checks, such as a different full command, makes them stale ([Every step](#every-step), "What a review covers"), so say so in the baton.
5. **Anything else:** your part is done for now. Print the baton again, from the last row of `log.md`.

## Draft the plan

1. **Branch.** If `work/<slug>` doesn't exist, create it from the current branch, which must be clean. Note that branch and its commit for the plan's `Branch:` line; the final review diffs from there.
2. **Save the requirement.** Write the user's text exactly as given to `requirement.md`, under a heading `# Requirement: <slug>` and the date. Don't tidy it, and never edit it later. Answers and changes go in the Decision log. Commit it straight away as `<slug>: requirement`, so that a restart finds it.
3. **Read** the project's instructions if it has any (`AGENTS.md`, `CLAUDE.md`, a README), the code the requirement touches, its callers, and the existing tests and fixtures.
   - **Work out the checks** from the project's own files: `package.json` scripts, `pyproject.toml`, `pytest.ini` or `setup.cfg`, a `Makefile`, the CI config, and those instructions. Include the lint and type-check commands if the project has them.
   - **Run each one once**, and note the result and how long it took. That's the baseline. Save its output as [Every step](#every-step) says ("Quick and full checks").
   - **If the baseline isn't green**, list each failing test in the Checks section under known failures. Ask in your first group of questions whether to fix them first, as their own small piece of work, or carry them. Later steps treat exactly those failures as expected; any other failure counts. If the user chooses to fix them first, delete any draft `plan.md`, commit your baseline `runs/` file as `<slug>: baseline`, then stop, telling the user the fix must reach `work/<slug>` before they rerun `dev-plan <slug>`: that fix is its own small piece of work, and this plan starts once the baseline is green.
   - **If you can't tell which command is right**, because there are several candidates or none, ask in your first group of questions. Don't guess.
   - **If the full checks take more than about 2 minutes**, also work out the quick checks: how to run a single test file, and a fast subset if the project has one (a unit-only script, a `not slow` marker).
   - **If they take more than about 2 minutes, also try running them in parallel** with what the project already has: Playwright workers, `node --test` (which runs files in parallel already), `pytest -n auto` if `pytest-xdist` is installed, or the runner's own option.
     - **Same results, and faster:** use the parallel command as the full checks, and note both run times.
     - **It needs a new dependency, or some tests fail only in parallel:** don't install or fix anything. Note in the plan's Checks section what's needed, which tests aren't isolated, and the likely speed-up. Then tell the user. Fixing old tests is its own small piece of work, not part of this feature.
   - **Write them all** in the plan's Checks section. Every later step reads its commands from there.
4. **Choose the scale**, and tell the user which you chose:
   - **Full**, the default: a large feature, or any milestone that would be `Tests: independent`.
   - **Medium**: one module, about a day's work, and every milestone `Tests: builder`. Write a short plan. It gets no plan review.
   - A small fix (under ~50 lines) doesn't need this workflow. Say so, commit your baseline `runs/` file as `<slug>: baseline`, and stop, unless the user insists.
5. **Ask.** First draft whatever the answers can't change. Then ask your questions in at most 3 groups, about 10 questions in all, each with a default. Put the money and data questions first, including the facts you couldn't check ([the milestone rules](#milestone-rules), "Facts the plan relies on"). Where an acceptance criterion on money or data has no worked example, propose one with the arithmetic shown, and ask the user to confirm it. Wait for the answers; "defaults" accepts every default. Each answer goes in the plan's Decision log as the user's decision, and they're committed with the plan.
6. **Write `plan.md`** from `plan-template.md` in this skill's folder, following [the milestone rules](#milestone-rules).
7. **Finish** ([Every step](#every-step)). The plan step needs no test run beyond the baseline and the `Compare:` trial runs. Commit `plan.md` as `<slug>: plan v1`. The baton:
   - **Full:** plan review, in a new session, ideally from the other vendor: `dev-review <slug> plan`.
   - **Medium:** gate 1, in this session. Tell the user what to read, including every fact still `unverified` with how the plan settles it, and each `Compare:` line, then to type `approve the plan`.

## Milestone rules

The plan reviewer checks all of these.

- Every acceptance criterion (AC) is covered by at least one milestone, and each milestone lists the ACs it covers.
- Order the milestones by dependency. Each one leaves the full suite green, apart from the known baseline failures in Checks.
- Keep each one to about 400 changed lines at most. Split anything bigger.
- If an unverified assumption would change the design, add an `M0`: a short experiment, marked `Tests: builder`, whose output is a finding rather than production code.
- Every milestone gets a `Tests:` line with a one-line reason. Ask one question: **if this milestone were wrong, would the user find out from an error, or from a wrong number later?** An error means `builder`. A wrong number, or quietly damaged data, means `independent`.

  Mark it `independent` if it:
  - calculates numbers someone will rely on: returns, P&L, valuations, forecasts, ratios, growth rates, margins, model outputs;
  - places orders or moves money: orders, trades, allocations, fees;
  - changes stored data in a way that's hard to undo: imports, deduplication, merges, migrations, backfills, corrections;
  - extracts numbers from a source: 10-K or 10-Q lines into a model, broker statements, vendor or consensus data;
  - lines things up by date or ID: rolling windows, as-of dates, fiscal vs calendar quarters, time zones, trading calendars, look-ahead, joins;
  - converts or rolls up: currencies, units (thousands vs millions), rounding, signs, totals across accounts.

  Mark it `builder` when a mistake would be loud or only cosmetic: wiring, configuration, command-line options, logging, file handling, refactors that don't change behavior, displaying or exporting numbers already tested where they're computed, developer tooling.

  If you're unsure, mark it `independent`. If a milestone is mixed, split it: move the calculation into its own `independent` milestone, and leave the plumbing as `builder`.
- **Milestones meant to change no numbers** (a refactor, a simplification, a speed-up, moving code) that touch code computing or storing money or data get a `Compare:` line. With no new behavior, there's nothing for a kill check to break, so the evidence that nothing changed is the same real input giving the same output before and after. The line gives:
  - a command, or a short chain of them, that runs the real entry point on real input and leaves the outputs in `{out}`, a folder outside the repository. It writes nothing inside the repository, caches included: point any cache at `{out}`;
  - the input: the smallest real one that reaches the changed code, with its path if it isn't in the repository;
  - how to compare: exactly, unless you give a tolerance and why. For tables, compare the values rather than the file bytes when the format holds run-specific fields such as timestamps;
  - if the milestone moves or renames the entry point, the command to use at the base as well (`at base: <command>`).

  Run it once now, if the code already exists, to check that it works, and note how long it took. The builder runs it before and after the change, the reviewer checks that run and breaks the changed code once to show the input reaches it, and any difference the plan doesn't name is a finding.
- **Facts the plan relies on.** Under Context, list the facts about the data and the existing code that a number depends on, such as units and scale, sign conventions, price adjustments, time zones, as-of vs report dates, fiscal year ends, and which keys are unique. Give each one its source: a `file:line`, a sample of the real data you looked at (file and row), or the user. If you can't check one, mark it `unverified`, and settle it: ask the user, add an `M0` to check it, or plan a `check at` guard where the data enters when the data itself can tell (a header naming the units), and list that guard under Risks too, with its error named in the interface. Gate 1 shows every fact still `unverified`.
- On `independent` milestones:
  - the interface must be exact (names, parameter and return types, units, and the errors a caller relies on), because the test author writes against it before any code exists. Name only errors that someone acts on. Everything else raises whatever the language raises;
  - worked examples are required, with exact expected values.
- **Keep the design simple.** Choose the simplest design that meets the ACs, in the project's existing style. Plan no options, modes, abstraction layers or extension points the requirement doesn't ask for: every later milestone has to build on them.
- **Fail loudly, don't handle.** Mark each line under Risks and edge cases with how it's dealt with. `test` means the risk would give a wrong number or damaged data quietly, so a test pins it down. `raises` means bad input already fails loudly (an exception, or a crash at load), so it gets no guard and no test. `check at <where>` is a guard the user needs, placed once, where the data enters; name its error in the interface, so it gets a test. Use `test` for the quiet money and data risks, and `raises` for the rest, especially inputs that only come from the user's own code, config or hand-written files. Data from outside (broker statements, vendor files, filings) never counts as the user's own, even when saved locally. Don't plan validation layers, lenient or draft modes, or code that collects problems and carries on, unless the requirement asks for them.
- Expected values in worked examples come from the user, or from your own arithmetic shown in the plan and marked `(planner; confirm at gate 1)`. Never from running code.

## Answer the review

Answer every open item in the latest reviewer round: its new P0–P2 findings, and any marked STILL OPEN. P3 notes need no answer.

1. **Check each finding** against the requirement, the code and the plan before acting on it. Don't agree just to end the exchange, and don't argue for its own sake.
2. **Answer each one** in one of three ways:
   - **FIX:** change the plan. Make the smallest coherent change: what removes the finding's trigger, plus the plan lines that directly depend on it (an AC, a worked example, an interface), listed in your response. Don't rewrite or improve anything else in the same response; that only gives the next round new material.
   - **PUSH BACK:** give the evidence, such as a quote from `requirement.md`, a code path, or a line of the plan.
   - **ESCALATE:** add an `ESC-n` with the options and your recommendation. List it under "Open questions" in the plan too.
3. **Special cases:**
   - If a finding is unclear, don't guess. Push back with your specific question.
   - If a finding asks for something the requirement doesn't need, check whether anything would use it. If nothing would, push back, citing the requirement and the Non-goals.
   - If a finding is real but harmless (it fails "What counts as a finding" in `dev-review`), answer `PUSH BACK (NOT MATERIAL)` and say which part of that test it fails. Only the reviewer can close it.
   - A P3 note is optional. Fix it only if it's a one-line change in a section you're already changing.
4. **Bump the version** (v1 → v2), and say on the `Version:` line what changed.
5. **Append a response** to `review-plan.md`:

   ```
   ## Response r<N> · <date> · "<session name>" (<vendor> <model>)
   Plan: v<old> → v<new>
   Fixes: <reviewed head>..<new head>

   | Finding | Answer | What changed, or the evidence |
   |---|---|---|
   | F1 | FIX | AC-3 now names the rounding rule (plan.md, Acceptance criteria) |
   | F2 | PUSH BACK | requirement.md: "Excel files are out of scope" |
   | F3 | ESCALATE → ESC-2 | Options A and B; I recommend A because … |

   Calls I made: … (or "none")
   ```

6. **Finish.** Commit `plan.md` as `<slug>: plan v<N>`, then the records. The baton goes back to the plan-review session with `dev-review <slug> plan`. If every open item is waiting on the user, the baton lists the ESC IDs to decide instead, and says to type each decision in this session.

## Gate 1: approve the plan

1. **Check:**
   - the latest plan review is READY;
   - every escalation has a decision;
   - every `(planner; confirm at gate 1)` example has been confirmed.

   If any of these fails, list what's open and ask the user once to confirm approving anyway. Their reason goes in the Decision log. A medium plan has no review, so only the last two checks apply.
2. **Record it.** Set `Accepted: v<N> <YYYY-MM-DD>` at the top of `plan.md`, add the Decision log entry, and set every milestone to `planned` in Progress.
3. **Finish.** Commit as `<slug>: plan v<N> accepted`. The baton names the first milestone in the plan's order (`M0` if there is one), and its mark:
   - **`independent`:** `dev-test <slug> <first>`, in a new session from the vendor that won't build it.
   - **`builder`:** `dev-build <slug> <first>`, in a new session. On a medium plan, use this same session.
   - Remind the user they can archive the `plan` and `plan-review` sessions now.

## Fold in a decision

**Before gate 1:** change the plan, bump the version, commit as `<slug>: plan v<N> (ESC-n)`, and finish ([Every step](#every-step)) with a log row whose Next is the baton below. Any plan review READY no longer covers it, so the baton is `dev-review <slug> plan`, in the plan-review session. A medium plan has no plan review, so its baton is gate 1 again, in this session.

**After gate 1:**

1. Fold the user's decision into the plan, bump the version, and add to the `Accepted:` line, for example `Accepted: v2 2026-10-09; v3 applies ESC-4 (your decision, 2026-10-11)`. Never make any other change after acceptance; anything else goes back to the user as an escalation. Wherever these steps say `ESC-n`, use the decision's reference: its `ESC-n`, or a short name for a decision without one, such as `checks`.
2. Find the milestones the change affects. Leave `planned` ones as they are. Set each one already past `planned` to `reopened (v<N>, ESC-n)` in Progress, because its tests, code or review no longer match the plan.
3. Commit as `<slug>: plan v<N> (ESC-n)`, and finish ([Every step](#every-step)) with a log row whose Next is this baton:
   - if a milestone was reopened, the earliest one goes back to its builder: `dev-build <slug> Mx`, in its build session if that's still open, or a new one;
   - otherwise, whatever was next before the decision.

## Every step

*This section is the same in all five `dev-*` skills. Change all five together.*

### Start

1. **Read the invocation.** It gives the feature slug, then the target if this skill takes one (`plan`, `M2`, `final`). Anything after that is the user's: a requirement, a decision, or extra focus. The feature's files are in `docs/work/<slug>/`, unless the project's instructions name another place.
2. **Find the checks** in the "Checks" section of `plan.md`. `dev-plan` works them out from the project's own files when it drafts the plan. If the plan has no such section (it predates it), use the commands that the latest saved run or handoff used, so that every step runs the same ones. If there are none yet, work them out the way `dev-plan` does (`dev-status` only reads them), and note them under "Calls I made". Either way, suggest adding the section with `dev-plan <slug> add a Checks section to the plan`. Follow the project's instructions (`AGENTS.md`, `CLAUDE.md`, a README) where they exist, but never require them. If a command won't run on this machine (it's missing, not failing), stop and ask the user.
3. **Check git.** The project must be a git repository.
   - Work on branch `work/<slug>`. Only `dev-plan` creates it. If you're on another branch and the tree is clean, switch to it. If `HEAD` is detached, an output comparison stopped partway or is still running in another session: `dev-status` only reports it; any other step asks the user, and switches back to `work/<slug>` once they confirm nothing is running.
   - Run `git status --porcelain`. If there are uncommitted changes you didn't make in this session, never stash, commit or discard them yourself. (`dev-status` only reports them, apart from an interrupted decision of its own.)
     - **If they look like an interrupted run of your own step** (the files your step writes, for the same target, and no committed `log.md` row for that run yet; an uncommitted row of your step is part of the interrupted run): show the user `git status` and a short summary of the diff, and ask whether to carry on from them. If they agree, adopt them, say so under "Calls I made", and finish that run before any baton: carry on from where it stopped, and end with Finish. An adopted log row is that run's row; don't add another. If they don't, stop.
     - **Otherwise:** stop, and tell the user which step the changes seem to come from. Rerunning that step, in a fresh session if need be, will offer to carry on from them. Or the user can commit or discard them.
4. **Read `log.md`** in the feature folder, if it exists. Its last row is where things stand.
5. **Name the session**, if nothing else has been done in it yet. Use the name from the table below. If you have a tool that renames the current session (in the Claude desktop app, `set_session_title` with session id `self`), use it. Then file the session under the sidebar group named `<slug>`: list the groups first, and create the group only if it's missing. If you have no such tool, skip this step, because the user names the session.

| Step | Session name |
|---|---|
| `dev-plan` | `<slug> plan` |
| `dev-review plan` | `<slug> plan-review` |
| `dev-test Mx` | `<slug> Mx test` |
| `dev-build Mx` | `<slug> Mx build` |
| `dev-review Mx` | `<slug> Mx review` |
| `dev-review final` | `<slug> final-review` |
| `dev-build final` | `<slug> final-fix` |
| `dev-status` | `<slug> status` |

### While you work

- **One role.** You may use subagents for your own work, such as searching the code or probing several risks at once. Never start another role, either as a subagent or by messaging another session. Each role starts from a line the user pastes.
- **The user's decisions.** The user may give one in the invocation, or type it later in plain words: "approve the plan", "ESC-2: option B", "accept M2", "defer F4 to M3", "allow one more round on M2". Record it straight away, unless the Decision log already has it (a restart):
  - add `- <YYYY-MM-DD> <ref>: <decision> (you, in "<session name>")` to the Decision log in `plan.md`;
  - approving the plan also sets its `Accepted:` line, and accepting a milestone or the feature also updates Progress (`dev-plan` and `dev-status` give the details, and `dev-review` follows `dev-status` when the user accepts at its gate baton);
  - mention it in your next `log.md` row, and commit it with your step. If you've already finished (for example, the user typed it after your baton), or your step stops before Finish for any reason (a precondition fails, or there's nothing to do), add a row with step `decision`, and commit it with the decision in one commit straight away, as `<slug>: decision <ref>`, or with the message your role gives for that decision (such as `<slug> Mx: accepted`).

  Then act on the decision only as far as your role allows.
- **What a review covers.** A review covers the code and tests at its `Reviewed:` head, and the plan version it names. If a round names no plan version, use the `Version:` line of `plan.md` at its `Reviewed:` head (`git show <head>:<path to plan.md>`). Later commits that touch only the feature folder's records leave it valid. Any other change (code, tests, configuration), or a new plan version, makes it stale, and it must be reviewed again before a gate relies on it. One exception: a version that only adds a Checks section to a plan that had none, keeping the commands that earlier runs used, leaves milestone and final reviews valid. To check, run `git diff --name-only <reviewed head> HEAD` and compare the plan's `Version:` line.
- **Escalations.** Their IDs run `ESC-1`, `ESC-2`, … across the whole feature: take the number after the highest `ESC-` anywhere in the feature folder. Each one states the question, the options and your recommendation. It stays open until the Decision log has an entry for it.
- **Your own calls.** Every choice you make that the user didn't goes under "Calls I made" in your handoff, response or review. Examples: picking one reading of an ambiguity, a small deviation from the plan.
- **Quick and full checks.** The *full checks* are every command in the plan's Checks section. The *quick checks* are the test files that cover what you changed, plus the quick command in Checks if it names one. Use quick checks while you work. A gate always rests on a full run, either run or cited, so quick checks never replace one.
  - **Run once, and save the output.** Run the full checks where your role says so, after your last change to code or tests. Save the output to `runs/<YYYY-MM-DD-HHMM>-<step>-<short hash>.txt` in the feature folder. Start with the commit, each command, how long it took and its result, then the runner's output; if that's very long, keep its summary and every failure in full. Commit the file with your records, and name it in your handoff, response or review, and in your `log.md` row. When the full checks take more than a couple of minutes, start them in the background if your tool allows, and keep reading while they run.
  - **Cite instead of rerunning** when a saved run exists whose commit differs from `HEAD` only in records, meaning `git diff --name-only <its commit> HEAD` lists only files in the feature folder. Open the file and check its commit, commands and result yourself; never take a summary's word for them. Run again if the file is missing, its commit or commands differ, or anything else has changed: code, tests, configuration, dependencies or test data. An `M0` that writes only findings usually needs no run of its own.
- **Output comparison.** A milestone's `Compare:` line in the plan gives a command that runs real input through the code and leaves its outputs in `{out}`, plus how to compare them. If Surprises and deviations records a newer input or command for it, use that. To run it:
  1. Commit anything you've changed, so that the tree is clean apart from your own `runs/` files. Records go in a `<slug> <step>: records` commit; another one at Finish is fine.
  2. Make two new, empty temporary folders outside the repository. Run the command at `HEAD` into the first.
  3. `git switch --detach <base>`, run the command (or its `at base:` form) into the second, and `git switch work/<slug>`. The base is the commit before the milestone's first commit: the `<base>` of the milestone's first range in `log.md`, or, for a builder making that first commit, `HEAD` before it. For a milestone reopened after later milestones were built, it's `HEAD` before the reopen's first commit, and only what the reopen's decision names may differ.
  4. After each run, check `git status --porcelain`. If the run changed anything, restore it before going on, and don't use that run: the `Compare:` line is wrong, because it must write nothing inside the repository, caches included. The builder fixes the command, as a small plan change under Surprises and deviations; a reviewer raises a P2 against the `Compare:` line.

  Compare the two as the line says. Save the result to `runs/<YYYY-MM-DD-HHMM>-<step>-compare-<short hash>.txt`: both commits, the command, the input, and either "identical" or the number of differences with the first 10. Name it wherever you name your full run. Never switch while a full run of yours is still going.

### Finish

1. **Checks.** Run the checks your role names, if any, and note each command and its result. Run the full checks on committed code: make the first commit of step 2 (your work) before you run them, so that a saved run names a commit holding exactly what was tested. If they fail and you fix something, commit again and rerun.
2. **Commit your work** with the message your role gives. Never push, amend, rebase or merge.
3. **Log.** Append one row to `log.md`, before the last commit, so that it goes in with your records. If the file is missing, create it with the heading `# Log: <slug>` and this table header:

   ```
   | When | Session | Step | Result | Next |
   |---|---|---|---|---|
   ```

   - **When:** local time, as `YYYY-MM-DD HH:MM`.
   - **Session:** `<session name> (<vendor> <model>)`, for example `csv-import M2 review (Claude Opus 5.5)`. Your vendor is Claude when you run in Claude Code, and Codex when you run in Codex. Add `, same vendor` when a check ran on the same vendor as the work it checks:
     - plan-review against plan;
     - Mx test against Mx build (the builder adds it);
     - Mx review against Mx build;
     - final-review against the vendor that built most milestones.
   - **Step:** the skill and target, for example `dev-review M2` or `dev-build M2 (answers r1)`.
   - **Result:** the commit or commit range, the test result, the verdict, counts, and any new ESC IDs.
   - **Next:** the paste line or lines from your baton.
4. **Commit the records.** Update your records (handoff, review, `plan.md`, your `runs/` files) citing the commit of step 2, and commit them together with your log row as `<slug> <step>: records`. When your step writes only records, steps 2 and 4 are one commit, log row included. Then run `git status --porcelain`: it must be empty, because the next step stops on a dirty tree. Commit anything your step wrote in the feature folder with your records, and restore any break of your own. Never commit anything else here (changes you didn't make, or code, test or generated files outside the feature folder): name it to the user, and say the tree isn't clean.
5. **Reply** in at most 8 lines, then end with the baton:

   ```
   Done: <slug> <step>. <commit, tests, verdict, what's open>.
   Next: <what>, in <a new session | the "<session name>" session> (<vendor>: <why>). Paste:
     <line or lines>
   ```

   | The next session is | Claude | Codex |
   |---|---|---|
   | New | `/dev-x <args>`. In a terminal: `claude -n "<session name>" "/dev-x <args>"` | `/rename <session name>`, then `$dev-x <args>` |
   | Already open | `/dev-x <args>` | `$dev-x <args>` |

   **Which vendor to suggest.** For a check (plan-review, Mx test, Mx review, final-review), suggest the vendor that didn't write what it checks, using `log.md`. Add "or a fresh `<same vendor>` session if `<other vendor>` has no capacity". For Mx test the builder isn't known yet, so say "the vendor that won't build Mx". For a writing step, suggest the vendor the user last used for that kind of step. The user can always override the suggestion.

   When the next step is the user's (a gate, or an escalation to decide), the baton says what to read or decide, and what to type in which session.

**Restarted?** If the committed files show your step has already finished (its `log.md` row is committed), for example after a crash, don't redo it. Print the baton again. If commits from your step exist after the last `log.md` row, a previous session stopped partway: carry on from them, without redoing what they hold, and end with Finish.
