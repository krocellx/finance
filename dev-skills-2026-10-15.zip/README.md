# The five dev-* skills

*v1, 2026-10-09; revised through 2026-10-14. Written from [final_workflow](../final_workflow/). Installed, and in trial since 2026-10-12.*

This folder is the source of truth. If you link the skills into both tools with junctions (step 2 below), an edit here reaches Claude Code and Codex at once. With plain copies, copy them again after every edit.

| Skill | Role | Paste | Supporting file |
|---|---|---|---|
| [dev-plan](dev-plan/SKILL.md) | Planner | `dev-plan <slug>`, then your requirement | [plan-template.md](dev-plan/plan-template.md) |
| [dev-test](dev-test/SKILL.md) | Test author | `dev-test <slug> Mx` | |
| [dev-build](dev-build/SKILL.md) | Builder | `dev-build <slug> Mx` (or `final`) | [handoff-template.md](dev-build/handoff-template.md) |
| [dev-review](dev-review/SKILL.md) | Every reviewer | `dev-review <slug> plan`, `Mx` or `final` | [review-template.md](dev-review/review-template.md) |
| [dev-status](dev-status/SKILL.md) | You | `dev-status <slug>`, then your decision | |

In Claude Code you start a skill with `/`, and in Codex with `$`. A session always takes the same line: each skill works out its next job from the files in `docs/work/<slug>/`.

## How the files are built

- **Two parts per `SKILL.md`.** The top is the role. The bottom, `## Every step`, is the same in all five: starting, naming the session, recording your decisions, committing, the log row and the baton. **Edit that section in all five at once.** To check that they still match (all five hashes should be equal):

  ```powershell
  Get-ChildItem skills\dev-*\SKILL.md | ForEach-Object { $t = Get-Content $_ -Raw -Encoding UTF8; $tail = $t.Substring($t.IndexOf('## Every step')); $h = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($tail))).Substring(0, 11); "$h  $($_.Directory.Name)" }
  ```

- **One body for both tools.** The text never uses `$ARGUMENTS`. It says "the invocation gives the slug, then the target". Codex sees that text in your message, and Claude Code appends it as `ARGUMENTS:`.
- **Nothing starts on its own.** `disable-model-invocation: true` in the frontmatter (Claude Code) and `allow_implicit_invocation: false` in `agents/openai.yaml` (Codex). This applies to `dev-status` too, because it writes your decisions.
- **No pinned models, and no Claude-only features** such as `context: fork`, `model:` or `!` commands. You choose the model for each session.
- **Templates sit next to each `SKILL.md`**, and the skills refer to them as "in this skill's folder".

## What the skills took from other projects

As planned in [3-existing-tools.md](../final_workflow/3-existing-tools.md#what-we-reuse), rewritten in our own words:

| Idea | From | Where |
|---|---|---|
| Check a finding against the code first, ask about unclear findings rather than guess, no performative agreement, check whether anything would use a requested addition | Superpowers, receiving-code-review | "Answer the review" in `dev-plan` and `dev-build` |
| Check every fix, then the whole fix diff for anything newly broken | Superpowers, re-review | "Recheck" in `dev-review` |
| Every call an agent makes on its own is written down for you | Superpowers, controller rulings | "Calls I made" in every handoff, response and review, collected by `dev-status` at the gates |
| Bad-test patterns | BMAD TEA, test review | "Bad-test patterns" in `dev-review` |
| AC-to-test trace table; only you waive | BMAD TEA, trace | the AC trace in `dev-review`; deferrals only by your decision |
| Each acceptance test fails before the build, for the right reason | BMAD TEA, ATDD | "Red run" in `dev-test` |
| Grouped clarifying questions, each with a default | Spec Kit, clarify | "Ask" in `dev-plan` |
| Flag code that hides a failure: a broad catch that carries on, an unrequested fallback or default | Anthropic, silent-failure-hunter | "Hidden failures" in `dev-review`; "Fail loudly, don't handle" in `dev-build` |
| Pre-existing defects aren't findings against the change | Anthropic, code-review | "Found outside this change" in `dev-review` and the handoff, listed at gate 3 by `dev-status` |
| List the plan's assumptions with their sources | Claudex Loop, recon | "Facts the plan relies on" in `dev-plan`, checked by `dev-review`, `unverified` ones at gate 1 |
| Learn from each loop | Compound Engineering, compound | "How the process went" at gate 3 in `dev-status`, kept in the last `log.md` row |
| Same real input, same output, before and after a refactor | our own | The `Compare:` line in `dev-plan`, "Output comparison" in Every step, run by `dev-build`; `dev-review` checks it and breaks the code once |

## Install

Done on the main PC on 2026-10-11, as plain copies. These steps are for another machine. They change your tool setup, so they're yours to run.

1. **Remove the old Codex skills first**, or Codex will load two `dev-plan`, `dev-build` and `dev-status` skills. `~/.codex/skills` is a git repository, so remove them there with a commit:

   ```powershell
   git -C "$env:USERPROFILE\.codex\skills" rm -r -q dev-build dev-fix-review dev-handoff dev-plan dev-recheck dev-review-code dev-review-plan dev-status
   ```

   ```powershell
   git -C "$env:USERPROFILE\.codex\skills" commit -m "Remove the 3 Oct dev-* skills; replaced by project_development_with_agent/skills"
   ```

2. **Link the five skills into both tools.** Junctions need no admin rights. This is the same way your `knowledge-*` skills are linked in `~/.agents/skills`:

   ```powershell
   $src = "D:\PythonProjects\project_development_with_agent\skills"; foreach ($s in "dev-plan","dev-test","dev-build","dev-review","dev-status") { New-Item -ItemType Junction -Path "$env:USERPROFILE\.claude\skills\$s" -Target "$src\$s" | Out-Null; New-Item -ItemType Junction -Path "$env:USERPROFILE\.agents\skills\$s" -Target "$src\$s" | Out-Null }
   ```

3. **In each project:** a git repository. Nothing else is required. `dev-plan` works out the test, lint and type-check commands from the project's own files, and records them in each feature's `plan.md` (its Checks section). An `AGENTS.md` or `CLAUDE.md` is optional, and is followed where it exists.

## Five-minute checks

Run these in a throwaway git repository that has a test command (for example a `package.json` with a `test` script):

- [ ] **Codex:** `$dev-status demo` loads the skill and sees `demo`. The Claude-only frontmatter keys cause no load error. (Codex's own `skill-creator` validator rejects `argument-hint` and `disable-model-invocation`. With those two keys removed, all five pass it. That's a packaging check, not proof of a loading failure. If Codex really refuses them, give Codex copies without the two keys instead of junctions.)
- [ ] **Codex:** an unrelated request ("what's the status?") doesn't start any `dev-*` skill on its own.
- [ ] **Claude Code:** `/dev-status demo` loads the skill. `dev-*` skills don't appear in what Claude can start by itself.
- [ ] **Claude desktop app:** a fresh session started with `/dev-status demo` renames itself `demo status` and files itself under a sidebar group `demo`.
- [ ] **Claude in a terminal:** `claude -n "demo status" "/dev-status demo"` opens a named session that runs the skill.
- [ ] **Both:** `/dev-plan demo` (or `$dev-plan demo`) with a two-line requirement finds `plan-template.md` in its own folder.

## Pilot

Run one milestone that has money or data logic end to end, from `dev-plan` to gate 2, as in [2-running-it.md](../final_workflow/2-running-it.md#one-milestone-paste-by-paste). Things to watch:

- Did each skill pick the right job from the files, every time it was run again?
- Was every baton right, and could you paste it as is? Did any baton send you to a new session you didn't need? (Fixed once, 2026-10-12: the gate 2 and gate 3 batons in `dev-review` now say to run `dev-status` in the review session or any open one. Since 2026-10-13, `dev-review` shows gate 2 and gate 3 in its own baton.)
- Did the TEST DISPUTE path, the round budget or HAND OFF come up? If so, did they work?
- Did "What counts as a finding" cut the noise? Gate 3's "how the process went" counts the findings that were DOWNGRADED or left as P3 notes; check whether any of them turned out to matter later. (Added 2026-10-12, after the first trial's plan review ran four rounds and asked for a fifth; see `codex_review_04/`.)
- How long did each gate take you, and was the `dev-status` gate view enough to decide?
- Added 2026-10-14: did the facts list, a `Compare:` line, a hidden-failure finding or "Found outside this change" come up? Did each one catch something, or only add reading?

Afterwards, drop any part that didn't earn its place, before using the skills on a second feature.
